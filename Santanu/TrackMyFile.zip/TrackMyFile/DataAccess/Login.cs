﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace DataAccess
{
    public class Login
    {

        public void SaveDDOUserInfo(Entity.Login LoginEntity)
        {
            using (DataManager oDm = new DataManager())
            {
                oDm.Add("@USER_CD", SqlDbType.NVarChar, 20, LoginEntity.USER_CD);
                oDm.Add("@USER_NM", SqlDbType.NVarChar, 100, LoginEntity.USER_NM);
                oDm.Add("@USER_PWD", SqlDbType.NVarChar, 200, LoginEntity.USER_PWD);
                //oDm.Add("@USER_GRP", SqlDbType.NVarChar, 6, LoginEntity.USER_GRP);
                oDm.Add("@DDO_CD", SqlDbType.NVarChar, 20, LoginEntity.DDO_CD);

                oDm.CommandType = CommandType.StoredProcedure;
                oDm.ExecuteNonQuery("usp_Add_DDOUser");
            }
        }

        public int GetCheckValidUser(Entity.Login LoginEntry)
        {
            int Results = 0;
            try
            {
                using (DataManager oDm = new DataManager())
                {
                    oDm.Add("@USER_CD", SqlDbType.NVarChar, 20, LoginEntry.USER_CD);
                    oDm.Add("@USER_PWD", SqlDbType.NVarChar, 200, LoginEntry.USER_PWD);
                    oDm.Add("@OPPARAM", SqlDbType.Int, 4, ParameterDirection.Output);
                    oDm.CommandType = CommandType.StoredProcedure;
                    oDm.ExecuteNonQuery("usp_CheckValidUser");
                    Results = (int)oDm["@OPPARAM"].Value;
                }
            }
            catch (Exception ex)
            {
                
            }
            return Results;
        }


        public static Entity.Login GetUserDetails(string UserName, string Password)
        {
            using (DataManager oDm = new DataManager())
            {
                oDm.Add("@USER_CD", SqlDbType.NVarChar, 20, UserName);
                oDm.Add("@USER_PWD", SqlDbType.NVarChar, 200, Password);

                oDm.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = oDm.ExecuteReader("usp_GetLoginDetails");
                Entity.Login LoginEntry = new Entity.Login();
                dr.Read();
                if (dr.HasRows)
                {
                    LoginEntry.USER_CD = dr["USER_CD"].ToString();
                    LoginEntry.USER_GRP = dr["USER_GRP"].ToString();
                    LoginEntry.ADMIN_FLG = dr["ADMIN_FLG"].ToString();
                    LoginEntry.USER_NM = dr["USER_NM"].ToString();
                    LoginEntry.DDO_CD = dr["DDO_CD"].ToString();
                }
                return LoginEntry;
            }
        }

        //public static Entity.Login GetAllLogin(string UserName,string Password)
        //{
        //    using (DataManager oDm = new DataManager())
        //    {
        //        oDm.Add("@Username", SqlDbType.VarChar, 50, UserName);
        //        oDm.Add("@Password", SqlDbType.VarChar, 50, Password);

        //        oDm.CommandType = CommandType.StoredProcedure;
        //        SqlDataReader dr= oDm.ExecuteReader("usp_GetAllLogin");
        //        Entity.Login LoginEntry = new Entity.Login();
        //        dr.Read();
        //        if (dr.HasRows)
        //        {
        //            LoginEntry.UserId = Convert.ToInt32(dr["UserId"].ToString());
        //            LoginEntry.UserLoginName = dr["UserName"].ToString();
        //            LoginEntry.UserType = dr["UserType"].ToString();
        //        }
        //        return LoginEntry;
        //    }            
        //}
        public DataTable FillDropDownList(string SqlStr)
        {
            try
            {
                using (DataManager oDm = new DataManager())
                {
                    oDm.CommandType = CommandType.Text;
                    return oDm.ExecuteDataTable(SqlStr);
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public DataTable FillData(string SqlStr)
        {
            try
            {
                using (DataManager oDm = new DataManager())
                {
                    oDm.CommandType = CommandType.Text;
                    return oDm.ExecuteDataTable(SqlStr);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public void UpdateUsrLoginLogout(Entity.Login LoginEntity)
        {
          using (DataManager oDm = new DataManager())
          {
            oDm.Add("@USER_CD", SqlDbType.NVarChar, 20, LoginEntity.USER_CD);
            oDm.Add("@SESSION_ID", SqlDbType.Int, LoginEntity.SESSION_ID);
            oDm.Add("@CURR_DT", SqlDbType.DateTime, LoginEntity.CURR_DT);

            oDm.CommandType = CommandType.StoredProcedure;
            oDm.ExecuteNonQuery("usp_Upd_UserLoginLogOut");
          }
        }
      
      //public void SaveLoginLog(Entity.Login Login)
        //{
        //    using (DataManager oDm = new DataManager())
        //    {
        //        oDm.Add("@pUserId", SqlDbType.Int, 4, Login.UserId);
        //        oDm.Add("@pUserName", SqlDbType.VarChar, 200, Login.UserName);
        //        oDm.Add("@pUserType", SqlDbType.VarChar, 50, Login.UserType);
        //        oDm.CommandType = CommandType.StoredProcedure;
        //        oDm.ExecuteNonQuery("usp_SaveUserLoginLog");
        //    }
        //}

    }
}
