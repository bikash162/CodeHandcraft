﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
  public class FileNumPrefixSetup
  {
    public void SaveFileNumPrefixSetup(Entity.FileNumPrefixSetup FileNumPrefixSetupEntity)
    {
	    try
	    {
		    using (DataManager oDm = new DataManager())
		    {
          oDm.Add("@BranchID", SqlDbType.BigInt, FileNumPrefixSetupEntity.BranchID);
          oDm.Add("@FileNumPrefix", SqlDbType.VarChar, 50, FileNumPrefixSetupEntity.FileNumPrefix);
          oDm.Add("@CreatedBy", SqlDbType.VarChar, 50, FileNumPrefixSetupEntity.CreatedBy);
          oDm.CommandType = CommandType.StoredProcedure;
          oDm.ExecuteNonQuery("usp_Save_FileNumPrefixSetup");
		    }
	    }
	    catch(Exception ex)
	    {
		    throw new Exception(ex.Message);
	    }
    }

   public DataTable FillData(string SqlStr)
   {
       try
       {
           using (DataManager oDm = new DataManager())
           {
               oDm.CommandType = CommandType.Text;
               return oDm.ExecuteDataTable(SqlStr);
           }
       }
       catch (Exception ex)
       {
           return null;
       }
   }

  }
}
