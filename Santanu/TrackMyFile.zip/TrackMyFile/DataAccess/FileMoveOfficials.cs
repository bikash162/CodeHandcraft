﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
  public class FileMoveOfficials
  {
    public void SaveFileMoveOfficials(Entity.FileMoveOfficials FileMoveOfficialsEntity)
    {
      try
      {
        using (DataManager oDm = new DataManager())
        {
          oDm.Add("@UsrID", SqlDbType.BigInt, FileMoveOfficialsEntity.UsrID);
          oDm.Add("@CreatedByID", SqlDbType.BigInt, FileMoveOfficialsEntity.CreatedByID);
          oDm.CommandType = CommandType.StoredProcedure;
          oDm.ExecuteNonQuery("usp_Save_FileMoveOfficials");
        }
      }
      catch (Exception ex)
      {
        throw new Exception(ex.Message);
      }
    }

    public void DelFileMoveOfficials(Entity.FileMoveOfficials FileMoveOfficialsEntity)
    {
      try
      {
        using (DataManager oDm = new DataManager())
        {
          oDm.Add("@UsrMappID", SqlDbType.BigInt, FileMoveOfficialsEntity.UsrMappID);
          oDm.CommandType = CommandType.StoredProcedure;
          oDm.ExecuteNonQuery("usp_Del_FileMoveOfficials");
        }
      }
      catch (Exception ex)
      {
        throw new Exception(ex.Message);
      }
    }


    public DataTable FillData(string SqlStr)
    {
      try
      {
        using (DataManager oDm = new DataManager())
        {
          oDm.CommandType = CommandType.Text;
          return oDm.ExecuteDataTable(SqlStr);
        }
      }
      catch (Exception ex)
      {
        return null;
      }
    }

  }
}
