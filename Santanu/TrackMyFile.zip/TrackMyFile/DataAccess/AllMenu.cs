﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
   public class AllMenu
    {
        public DataTable LoadDataTable(string SqlStr)
        {
            using (DataManager oDm = new DataManager())
            {
                oDm.CommandType = CommandType.Text;
                return oDm.ExecuteDataTable(SqlStr);
            }

        }

    }
}
