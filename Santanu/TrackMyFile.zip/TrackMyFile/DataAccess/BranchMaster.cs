﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
 public class BranchMaster
  {

     public void SaveBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         try
         {
             using (DataManager oDm = new DataManager())
             {
                 oDm.Add("@BranchNm", SqlDbType.VarChar, 100, BranchMasterEntity.BranchNm);
                 oDm.Add("@BranchDesc", SqlDbType.VarChar, 100, BranchMasterEntity.BranchDesc);
                 oDm.CommandType = CommandType.StoredProcedure;
                 oDm.ExecuteNonQuery("usp_Add_BranchMaster");
             }
         }
         catch (Exception ex)
         {
             throw new Exception(ex.Message);
         }
     }


     public void UpdateBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         try
         {
             using (DataManager oDm = new DataManager())
             {
                 oDm.Add("@BranchID", SqlDbType.BigInt, BranchMasterEntity.BranchID);
                 oDm.Add("@BranchNm", SqlDbType.VarChar, 100, BranchMasterEntity.BranchNm);
                 oDm.Add("@BranchDesc", SqlDbType.VarChar, 100, BranchMasterEntity.BranchDesc);
                 oDm.CommandType = CommandType.StoredProcedure;
                 oDm.ExecuteNonQuery("usp_Upd_BranchMaster");
             }
         }
         catch (Exception ex)
         {
             throw new Exception(ex.Message);
         }
     }

     public void DeleteBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         try
         {
             using (DataManager oDm = new DataManager())
             {
                 oDm.Add("@BranchID", SqlDbType.BigInt, BranchMasterEntity.BranchID);
                 oDm.CommandType = CommandType.StoredProcedure;
                 oDm.ExecuteNonQuery("usp_Del_BranchMaster");
             }
         }
         catch (Exception ex)
         {
             throw new Exception(ex.Message);
         }
     }

   public DataTable FillData(string SqlStr)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.CommandType = CommandType.Text;
         return oDm.ExecuteDataTable(SqlStr);
       }
     }
     catch (Exception ex)
     {
       return null;
     }
   }

  }
}
