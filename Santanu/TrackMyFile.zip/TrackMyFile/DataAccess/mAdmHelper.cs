﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace DataAccess
{
    public class mAdmHelper
    {
        public mAdmHelper()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string ToChar(string csString, bool blUseSingleChar)
        {
            //blUseSingleChar = true;
            return (blUseSingleChar ? "'" + csString + "'" : "\"" + csString + "\"");
        }

        public string SpecialToChar(string csInput)
        {
            return ToChar(csInput.Replace("'", "''"),true);
        }

        public string FormatNumber(double csInput)
        {
            return csInput.ToString("#,##0.00");
        }

    }
}
