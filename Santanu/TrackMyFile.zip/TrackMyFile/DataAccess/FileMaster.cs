﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
 public class FileMaster
  {

   public void SaveFileMaster(Entity.FileMaster FileMasterEntity)
  {
	  try
	  {
		  using (DataManager oDm = new DataManager())
		  {

        oDm.Add("@DeptID", SqlDbType.BigInt, FileMasterEntity.DeptID);
			  oDm.Add("@FileNum",SqlDbType.VarChar,250,FileMasterEntity.FileNum);
			  oDm.Add("@SubMatter",SqlDbType.VarChar,500,FileMasterEntity.SubMatter);
			  oDm.Add("@FileOpenYr",SqlDbType.VarChar,6,FileMasterEntity.FileOpenYr);
			  oDm.Add("@InitialOfficer",SqlDbType.VarChar,200,FileMasterEntity.InitialOfficer);
			  oDm.Add("@PhoneNo",SqlDbType.VarChar,20,FileMasterEntity.PhoneNo);
			  oDm.Add("@Remarks",SqlDbType.VarChar,500,FileMasterEntity.Remarks);
			  oDm.Add("@CreatedBy",SqlDbType.VarChar,50,FileMasterEntity.CreatedBy);
        oDm.Add("@FileFollowUp", SqlDbType.Char, 1, FileMasterEntity.FileFollowUp);
        oDm.Add("@UsrID", SqlDbType.BigInt, FileMasterEntity.UsrID);
        oDm.CommandType = CommandType.StoredProcedure;
			  oDm.ExecuteNonQuery("usp_Add_FileMaster");
		  }
	  }
	  catch(Exception ex)
	  {
		  throw new Exception(ex.Message);
	  }
  }

   public void UpdateFileMaster(Entity.FileMaster FileMasterEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {

         oDm.Add("@FileID", SqlDbType.BigInt, FileMasterEntity.FileID);
         oDm.Add("@SubMatter", SqlDbType.VarChar, 500, FileMasterEntity.SubMatter);
         oDm.Add("@FileOpenYr", SqlDbType.VarChar, 6, FileMasterEntity.FileOpenYr);
         oDm.Add("@InitialOfficer", SqlDbType.VarChar, 200, FileMasterEntity.InitialOfficer);
         oDm.Add("@PhoneNo", SqlDbType.VarChar, 20, FileMasterEntity.PhoneNo);
         oDm.Add("@Remarks", SqlDbType.VarChar, 500, FileMasterEntity.Remarks);
         oDm.Add("@LastModBy", SqlDbType.VarChar, 50, FileMasterEntity.LastModBy);
         oDm.Add("@FileFollowUp", SqlDbType.Char, 1, FileMasterEntity.FileFollowUp);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Upd_FileMaster");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

   public void DeleteFileMaster(Entity.FileMaster FileMasterEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {

         oDm.Add("@FileID", SqlDbType.BigInt, FileMasterEntity.FileID);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Del_FileMaster");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

   public void UpdateFileArchiveState(Entity.FileMaster FileMasterEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@FileID", SqlDbType.BigInt, FileMasterEntity.FileID);
         oDm.Add("@FileFollowUp", SqlDbType.Char, 1, FileMasterEntity.FileFollowUp);
         oDm.Add("@LastFollowupBy", SqlDbType.VarChar, 50, FileMasterEntity.LastFollowupBy);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Upd_FileArchiveState");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }



   public DataTable FillData(string SqlStr)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.CommandType = CommandType.Text;
         return oDm.ExecuteDataTable(SqlStr);
       }
     }
     catch (Exception ex)
     {
       return null;
     }
   }

  }
}
