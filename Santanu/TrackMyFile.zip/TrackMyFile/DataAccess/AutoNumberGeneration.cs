﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class AutoNumberGeneration
    {
        public static Entity.AutoNumnerGeneration GetAutoNumber(string SQLSTR)
        {

            using (DataManager oDm = new DataManager())
            {

                SqlDataReader dr = oDm.ExecuteReader(SQLSTR);

                Entity.AutoNumnerGeneration AutoNumnerGenerationEntity = new Entity.AutoNumnerGeneration();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        AutoNumnerGenerationEntity.AutoNo = (dr[0] == DBNull.Value) ? "" : dr[0].ToString();
                        
                    }
                }
                return AutoNumnerGenerationEntity;
            }

        }
        public string GetSystemDt()
        {
            DataTable Dt = new DataTable();
            using (DataManager oDm = new DataManager())
            {
                SqlDataReader dr = oDm.ExecuteReader("select getdate() SystemDt");
                Entity.AutoNumnerGeneration AutoNumnerGenerationEntity = new Entity.AutoNumnerGeneration();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        AutoNumnerGenerationEntity.Systemdt = Convert.ToDateTime(dr[0].ToString()).Month + "/" + Convert.ToDateTime(dr[0].ToString()).Day + "/" + Convert.ToDateTime(dr[0].ToString()).Year;
                    }
                }
                return AutoNumnerGenerationEntity.Systemdt;
            }
        }
        public string PagePermission(int PageId, string UserType)
        {
            DataTable Dt = new DataTable();
            using (DataManager oDm = new DataManager())
            {
                Entity.AutoNumnerGeneration AutoNumnerGenerationEntity = new Entity.AutoNumnerGeneration();
                SqlDataReader dr = oDm.ExecuteReader("select Permission from UnitWisePagePermission where UserType='" + UserType + "' and PageId =" + PageId + "");
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        AutoNumnerGenerationEntity.PagePermission = dr[0].ToString();
                    }
                }
                return AutoNumnerGenerationEntity.PagePermission;
            }
           
        }
    }
}
