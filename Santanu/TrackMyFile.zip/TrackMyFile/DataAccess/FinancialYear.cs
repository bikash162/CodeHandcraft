﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace DataAccess
{
   public class FinancialYear
    {
       public DataTable FillDropDownList(string SqlStr)
       {
           try
           {
               using (DataManager oDm = new DataManager())
               {
                   oDm.CommandType = CommandType.Text;
                   return oDm.ExecuteDataTable(SqlStr);
               }
           }
           catch (Exception ex)
           {
               return null;
           }

       }
    }
}
