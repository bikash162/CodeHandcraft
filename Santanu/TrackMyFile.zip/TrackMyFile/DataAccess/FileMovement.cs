﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
 public class FileMovement
  {

   public void SaveFileMovement(Entity.FileMovement FileMovementEntity)
  {
	  try
	  {
		  using (DataManager oDm = new DataManager())
		  {
			  oDm.Add("@FileID",SqlDbType.BigInt,FileMovementEntity.FileID);
			  oDm.Add("@FileMoveType",SqlDbType.VarChar,10,FileMovementEntity.FileMoveType);
			  oDm.Add("@DeptID",SqlDbType.BigInt,FileMovementEntity.DeptID);
			  oDm.Add("@MoveDt",SqlDbType.DateTime,FileMovementEntity.MoveDt);
			  oDm.Add("@Remarks",SqlDbType.VarChar,500,FileMovementEntity.Remarks);
			  oDm.Add("@CreatedBy",SqlDbType.VarChar,50,FileMovementEntity.CreatedBy);
        oDm.Add("@FileMoveTo_UsrID", SqlDbType.BigInt, FileMovementEntity.FileMoveTo_UsrID);
        oDm.CommandType = CommandType.StoredProcedure;
			  oDm.ExecuteNonQuery("usp_Add_FileMovement");
		  }
	  }
	  catch(Exception ex)
	  {
		  throw new Exception(ex.Message);
	  }
  }

   public void SaveFileMoveOutIn(Entity.FileMovement FileMovementEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@FileID", SqlDbType.BigInt, FileMovementEntity.FileID);
         oDm.Add("@DeptID", SqlDbType.BigInt, FileMovementEntity.DeptID);
         //oDm.Add("@MoveDt", SqlDbType.DateTime, FileMovementEntity.MoveDt);
         oDm.Add("@Remarks", SqlDbType.VarChar, 500, FileMovementEntity.Remarks);
         oDm.Add("@CreatedBy", SqlDbType.VarChar, 50, FileMovementEntity.CreatedBy);
         oDm.Add("@FileMoveTo_UsrID", SqlDbType.BigInt, FileMovementEntity.FileMoveTo_UsrID);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Manage_FileMove_OutIn");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

   public void UpdFileMovementFileViewedInfo(Entity.FileMovement FileMovementEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@FileMovementID", SqlDbType.BigInt, FileMovementEntity.FileMovementID);
         oDm.Add("@FileViewedBy", SqlDbType.VarChar, 50, FileMovementEntity.FileViewedBy);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Upd_FileMovement_FileViewedInfo");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

   public DataTable FillData(string SqlStr)
   {
       try
       {
           using (DataManager oDm = new DataManager())
           {
               oDm.CommandType = CommandType.Text;
               return oDm.ExecuteDataTable(SqlStr);
           }
       }
       catch (Exception ex)
       {
           return null;
       }
   }

   public DataTable GetFileInfoDeptWise(long DeptID, string CreatedBy)
   {
     
     using (DataManager oDm = new DataManager())
     {
       oDm.CommandType = CommandType.StoredProcedure;
       oDm.Add("@DeptID", SqlDbType.BigInt, ParameterDirection.Input,DeptID);
       oDm.Add("@CreatedBy", SqlDbType.VarChar, 50, ParameterDirection.Input,CreatedBy);
       DataTable dt = new DataTable();
       dt = oDm.ExecuteDataTable("usp_GetFilesInfoDeptWise");
       return dt;
     }

   }

   public void SaveADMFileMovement(Entity.FileMovement FileMovementEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@FileID", SqlDbType.BigInt, FileMovementEntity.FileID);
         oDm.Add("@DeptID", SqlDbType.BigInt, FileMovementEntity.DeptID);
         oDm.Add("@Remarks", SqlDbType.VarChar, 500, FileMovementEntity.Remarks);
         oDm.Add("@FileMoveTo_UsrID", SqlDbType.BigInt, FileMovementEntity.FileMoveTo_UsrID);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Add_ADM_FileMovement");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

  }
}
