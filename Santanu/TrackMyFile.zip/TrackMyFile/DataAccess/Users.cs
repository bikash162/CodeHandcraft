﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
 public class Users
  {

   public void SaveUsers(Entity.Users UsersEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@DeptID", SqlDbType.BigInt, UsersEntity.DeptID);
         oDm.Add("@UsrNm", SqlDbType.VarChar, 200, UsersEntity.UsrNm);
         oDm.Add("@UsrLoginNm", SqlDbType.VarChar, 50, UsersEntity.UsrLoginNm);
         oDm.Add("@UsrPwd", SqlDbType.VarChar, 20, UsersEntity.UsrPwd);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Add_Users");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }

   public void UpdUsrPassword(Entity.Users UsersEntity)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.Add("@UsrID", SqlDbType.BigInt, UsersEntity.UsrID);
         oDm.Add("@UsrPwd", SqlDbType.VarChar, 20, UsersEntity.UsrPwd);
         oDm.Add("@UsrNewPwd", SqlDbType.VarChar, 20, UsersEntity.UsrNewPwd);
         oDm.CommandType = CommandType.StoredProcedure;
         oDm.ExecuteNonQuery("usp_Upd_UsrPassword");
       }
     }
     catch (Exception ex)
     {
       throw new Exception(ex.Message);
     }
   }


   public DataTable FillData(string SqlStr)
   {
     try
     {
       using (DataManager oDm = new DataManager())
       {
         oDm.CommandType = CommandType.Text;
         return oDm.ExecuteDataTable(SqlStr);
       }
     }
     catch (Exception ex)
     {
       return null;
     }
   }

  }
}
