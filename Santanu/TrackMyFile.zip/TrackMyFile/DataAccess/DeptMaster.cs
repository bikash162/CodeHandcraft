﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
  public  class DeptMaster
    {
      public void SaveDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          try
          {
              using (DataManager oDm = new DataManager())
              {
                oDm.Add("@BranchID", SqlDbType.BigInt, DeptMasterEntity.BranchID);
                oDm.Add("@DeptNm", SqlDbType.VarChar, 100, DeptMasterEntity.DeptNm);
                oDm.Add("@DeptDesc", SqlDbType.VarChar, 100, DeptMasterEntity.DeptDesc);
                oDm.CommandType = CommandType.StoredProcedure;
                oDm.ExecuteNonQuery("usp_Add_DeptMaster");
              }
          }
          catch (Exception ex)
          {
              throw new Exception(ex.Message);
          }
      }

      public void UpdateDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          try
          {
              using (DataManager oDm = new DataManager())
              {
                  oDm.Add("@DeptID", SqlDbType.BigInt, DeptMasterEntity.DeptID);
                  oDm.Add("@DeptNm", SqlDbType.VarChar, 100, DeptMasterEntity.DeptNm);
                  oDm.Add("@DeptDesc", SqlDbType.VarChar, 100, DeptMasterEntity.DeptDesc);
                  oDm.CommandType = CommandType.StoredProcedure;
                  oDm.ExecuteNonQuery("usp_Upd_DeptMaster");
              }
          }
          catch (Exception ex)
          {
              throw new Exception(ex.Message);
          }
      }

      public void DeleteDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          try
          {
              using (DataManager oDm = new DataManager())
              {
                  oDm.Add("@DeptID", SqlDbType.BigInt, DeptMasterEntity.DeptID);
                  oDm.CommandType = CommandType.StoredProcedure;
                  oDm.ExecuteNonQuery("usp_Del_DeptMaster");
              }
          }
          catch (Exception ex)
          {
              throw new Exception(ex.Message);
          }
      }

      public DataTable FillData(string SqlStr)
      {
          try
          {
              using (DataManager oDm = new DataManager())
              {
                  oDm.CommandType = CommandType.Text;
                  return oDm.ExecuteDataTable(SqlStr);
              }
          }
          catch (Exception ex)
          {
              return null;
          }
      }

    }
}
