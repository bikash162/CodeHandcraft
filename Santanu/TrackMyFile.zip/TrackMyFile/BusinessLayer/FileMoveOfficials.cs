﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
  public class FileMoveOfficials
  {
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

    public void SaveFileMoveOfficials(Entity.FileMoveOfficials FileMoveOfficialsEntity)
    {
      DataAccess.FileMoveOfficials FileMoveOfficialsDataAccess = new DataAccess.FileMoveOfficials();
      FileMoveOfficialsDataAccess.SaveFileMoveOfficials(FileMoveOfficialsEntity);
    }

    public void DelFileMoveOfficials(Entity.FileMoveOfficials FileMoveOfficialsEntity)
    {
      DataAccess.FileMoveOfficials FileMoveOfficialsDataAccess = new DataAccess.FileMoveOfficials();
      FileMoveOfficialsDataAccess.DelFileMoveOfficials(FileMoveOfficialsEntity);
    }

    public DataTable fn_GetFileMoveOfficialsList(long iCreatedByID)
    {
      string SQLSTR = "";

      DataAccess.FileMoveOfficials FileMoveOfficialsDataAccess = new DataAccess.FileMoveOfficials();

      SQLSTR = " SELECT UM.DeptNm, UM.DeptID, UM.UsrNm, Usr = UM.UsrNm +  ' [' + UM.DeptNm + ']',FO.* FROM FileMoveOfficials FO " + Environment.NewLine;
      SQLSTR += " INNER JOIN [vw_Users] UM ON UM.UsrID = FO.UsrID " + Environment.NewLine;
      SQLSTR += " WHERE CreatedByID = " + iCreatedByID + Environment.NewLine;
      return FileMoveOfficialsDataAccess.FillData(SQLSTR);
    }

    public DataTable fn_GetOfficialList(long iCreatedByID)
    {
      string SQLSTR = "";
      DataAccess.FileMoveOfficials FileMoveOfficialsDataAccess = new DataAccess.FileMoveOfficials();
      SQLSTR = " SELECT Usr = UsrNm + ' [' + DeptNm + ']', * FROM [vw_Users] " + Environment.NewLine;
      SQLSTR += " WHERE UsrID NOT IN ( SELECT UsrID FROM FileMoveOfficials WHERE CreatedByID = " + iCreatedByID + " ) " + Environment.NewLine;
      SQLSTR += " AND (UsrID <> 1 AND UsrID <> " + iCreatedByID + ") " + Environment.NewLine;
      SQLSTR += " ORDER BY UsrNm " + Environment.NewLine;
      return FileMoveOfficialsDataAccess.FillData(SQLSTR);  
    }

  }
}
