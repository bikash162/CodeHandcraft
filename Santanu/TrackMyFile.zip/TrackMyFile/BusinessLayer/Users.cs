﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
 public class Users
  {
   DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

   public void SaveUsers(Entity.Users UsersEntity)
   {
     DataAccess.Users UsersDataAccess = new DataAccess.Users();
     UsersDataAccess.SaveUsers(UsersEntity);
   }

   public void UpdUsrPassword(Entity.Users UsersEntity)
   {
     DataAccess.Users UsersDataAccess = new DataAccess.Users();
     UsersDataAccess.UpdUsrPassword(UsersEntity);
   }

   public DataTable fn_GetUsrDetail(string UsrLoginNm, string UsrPwd)
   {
     string SQLSTR = "";
     DataAccess.Users UsersDataAccess = new DataAccess.Users();

     SQLSTR = " SELECT * FROM [vw_Users] WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " AND UsrLoginNm = " + mAdmHlp.SpecialToChar(UsrLoginNm) + Environment.NewLine;
     SQLSTR += " AND UsrPwd = " + mAdmHlp.SpecialToChar(UsrPwd) + Environment.NewLine;

     return UsersDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetAllUsers()
   {
     string SQLSTR = "";
     DataAccess.Users UsersDataAccess = new DataAccess.Users();

     SQLSTR = " SELECT * FROM [vw_Users] WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " ORDER BY DeptID, UsrNm " + Environment.NewLine;

     return UsersDataAccess.FillData(SQLSTR);
   }


   public DataTable fn_GetDeptwiseUsers(long DeptID)
   {
       string SQLSTR = "";
       DataAccess.Users UsersDataAccess = new DataAccess.Users();

       SQLSTR = " SELECT * FROM [vw_Users] WHERE 1 = 1 " + Environment.NewLine;
       SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
       SQLSTR += " AND DeptID <> 0 " + Environment.NewLine;

       return UsersDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetDept(long UsrID)
   {
     string SQLSTR = "";
     DataAccess.Users UsersDataAccess = new DataAccess.Users();

     SQLSTR = " SELECT * FROM [vw_Users] WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " AND UsrID = " + UsrID + Environment.NewLine;

     return UsersDataAccess.FillData(SQLSTR);
   }

  }
}
