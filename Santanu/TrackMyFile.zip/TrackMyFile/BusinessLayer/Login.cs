﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
    public class Login
    {
      DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

      public void SaveDDOUserInfo(Entity.Login LoginEntity)
      {
          DataAccess.Login LoginDataAccess = new DataAccess.Login();
          LoginDataAccess.SaveDDOUserInfo(LoginEntity);
      }

      public void UpdateUsrLoginLogout(Entity.Login LoginEntity)
      {
        DataAccess.Login LoginDataAccess = new DataAccess.Login();
        LoginDataAccess.UpdateUsrLoginLogout(LoginEntity);
      }

        public int GetValidUser(Entity.Login LoginEntry)
        {
            DataAccess.Login LoginDataaccess = new DataAccess.Login();
            return LoginDataaccess.GetCheckValidUser(LoginEntry);
        }
        public Entity.Login GetUserDetails(string UserName, string Password)
        {
            return DataAccess.Login.GetUserDetails(UserName, Password);
        }
        public DataTable LoadDropDown(string SQLSTR)
        {
            DataAccess.Login LoginDataaccess = new DataAccess.Login();
            return LoginDataaccess.FillDropDownList(SQLSTR);
        }

        public DataTable fn_GetLoginDetail(string USER_CD, int SESSION_ID, DateTime CURR_DT)
        {
            string SQLSTR = "";
            DataAccess.Login LoginDataAccess = new DataAccess.Login();

            SQLSTR = " SELECT * FROM BGT_USER_LOGIN_HDR WHERE 1 = 1 " + Environment.NewLine;
            SQLSTR += " AND USER_CD = " + mAdmHlp.SpecialToChar(USER_CD) + Environment.NewLine;
            SQLSTR += " AND SESSION_ID = " + Convert.ToInt32(SESSION_ID) + Environment.NewLine;
            SQLSTR += " AND CURR_DT = '" + CURR_DT + "'" + Environment.NewLine;

            return LoginDataAccess.FillData(SQLSTR);
        }

        public DataTable fn_GetSessionInfo(Int32 SESSION_ID, string USER_CD)
        {
          string SQLSTR = "";
          DataAccess.Login LoginDataAccess = new DataAccess.Login();

          SQLSTR = " SELECT * FROM BGT_USER_LOGIN_HDR WHERE 1 = 1 AND USER_CD = @USER_CD AND SESSION_ID = @SESSION_ID " + Environment.NewLine;

          return LoginDataAccess.FillDropDownList(SQLSTR);

        }

        public DataTable fn_GetDDOUserList(string DDO_CD)
        {
            string SQLSTR = "";
            DataAccess.Login LoginDataAccess = new DataAccess.Login();

            SQLSTR = " SELECT * FROM vw_UsrDetail WHERE 1 = 1 " + Environment.NewLine;
            SQLSTR += " AND DDO_CD = " + mAdmHlp.SpecialToChar(DDO_CD) + Environment.NewLine;
            SQLSTR += " ORDER BY USER_NM " + Environment.NewLine;

            return LoginDataAccess.FillData(SQLSTR);
        }


    }
}
