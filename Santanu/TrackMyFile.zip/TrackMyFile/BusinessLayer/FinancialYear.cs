﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
    public class FinancialYear
    {
        DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

        public DataTable LoadDropDown(string SQLSTR)
        {
            DataAccess.FinancialYear FinancialYrData = new DataAccess.FinancialYear();
            return FinancialYrData.FillDropDownList(SQLSTR);
        }

        public DataTable fn_PopulateFinYrList()
        {
            string SQLSTR = "";

            DataAccess.FinancialYear FinancialYrData = new DataAccess.FinancialYear();
            
            SQLSTR = " SELECT * FROM BGT_FIN_YR_MST WHERE 1 = 1 AND IS_ACTIVE = 'Y' ORDER BY ST_DT DESC " + Environment.NewLine;
            return FinancialYrData.FillDropDownList(SQLSTR);
        }

        public DataTable fn_PopulateMonthList()
        {
            string SQLSTR = "";

            DataAccess.FinancialYear FinancialYrData = new DataAccess.FinancialYear();

            SQLSTR = " SELECT * FROM BGT_MONTH_MST WHERE 1 = 1 " + Environment.NewLine;

            return FinancialYrData.FillDropDownList(SQLSTR);
        }
    }
}
