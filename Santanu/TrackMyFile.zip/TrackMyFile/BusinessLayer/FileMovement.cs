﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
 public class FileMovement
  {
   DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

   public void SaveFileMovement(Entity.FileMovement FileMovementEntity)
   {
     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();
     FileMovementDataAccess.SaveFileMovement(FileMovementEntity);
   }

   public void SaveADMFileMovement(Entity.FileMovement FileMovementEntity)
   {
     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();
     FileMovementDataAccess.SaveADMFileMovement(FileMovementEntity);
   }

   public void SaveFileMoveOutIn(Entity.FileMovement FileMovementEntity)
   {
     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();
     FileMovementDataAccess.SaveFileMoveOutIn(FileMovementEntity);
   }

   public void UpdFileMovementFileViewedInfo(Entity.FileMovement FileMovementEntity)
   {
     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();
     FileMovementDataAccess.UpdFileMovementFileViewedInfo(FileMovementEntity);
   }

   public DataTable GetFileInfoDeptWise(long DeptID, string CreatedBy)
   {
     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();
     return FileMovementDataAccess.GetFileInfoDeptWise(DeptID,CreatedBy);
   }

   public DataTable fn_GetFileMovementDetail(long FileID)
   {
       string SQLSTR = "";

       DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

       SQLSTR = " SELECT U.UsrNm, DM.DeptNm, FM.* FROM FileMovement FM " + Environment.NewLine;
       SQLSTR += " INNER JOIN DeptMaster DM ON DM.DeptID = FM.DeptID " + Environment.NewLine;
       SQLSTR += " INNER JOIN FileMaster F ON F.FileID = FM.FileID " + Environment.NewLine;
       SQLSTR += " LEFT OUTER JOIN vw_Users U ON FM.FileMoveTo_UsrID = U.UsrID " + Environment.NewLine;
       SQLSTR += " WHERE FM.FileID = " + FileID + Environment.NewLine;
       SQLSTR += " ORDER BY FM.FileMovementID Desc " + Environment.NewLine;

       return FileMasterDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetAcceptableFileListToDept(long DeptID, long FileMoveTo_UsrID)
   {
     string SQLSTR = "";

     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();

     SQLSTR = " SELECT BranchDept = BranchNm + '....' + DeptNm ,* FROM [vw_FileMovement] WHERE FileMovementID IN ( " + Environment.NewLine;
     SQLSTR += " SELECT MAX(FileMovementID) FROM vw_FileMovement GROUP BY FileID) " + Environment.NewLine;
     SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     SQLSTR += " AND (ISNULL(FileMoveTo_UsrID,0) = 0  OR ISNULL(FileMoveTo_UsrID,0) = " + FileMoveTo_UsrID + ")" + Environment.NewLine;
     SQLSTR += " AND FileMoveType = 'O' " + Environment.NewLine;
     SQLSTR += " ORDER BY IsFileViewed, FileMovementId " + Environment.NewLine;
     return FileMovementDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetFilesListDeptWise(long DeptID, long FileMoveTo_UsrID)
   {
     string SQLSTR = "";

     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();

     SQLSTR = " SELECT * FROM [vw_FileMovement] WHERE FileMovementID IN ( " + Environment.NewLine;
     SQLSTR += " SELECT MAX(FileMovementId) FROM [vw_FileMovement] GROUP BY FileID) " + Environment.NewLine;
     SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     SQLSTR += " AND ISNULL(FileMoveTo_UsrID,0) = " + FileMoveTo_UsrID + Environment.NewLine;
     SQLSTR += " AND FileMoveType = 'I' " + Environment.NewLine;
     SQLSTR += " AND FileCreatedDept <> " + DeptID + Environment.NewLine;
     SQLSTR += " ORDER BY FileID " + Environment.NewLine;
     return FileMovementDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetCurrentFileListToUsr(long DeptID, long FileMoveTo_UsrID)
   {
     string SQLSTR = "";

     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();

     SQLSTR = " SELECT BranchDept = BranchNm + '....' + DeptNm ,* FROM [vw_FileMovement] WHERE FileMovementID IN ( " + Environment.NewLine;
     SQLSTR += " SELECT MAX(FileMovementID) FROM vw_FileMovement GROUP BY FileID) " + Environment.NewLine;
     SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     SQLSTR += " AND (ISNULL(FileMoveTo_UsrID,0) = 0  OR ISNULL(FileMoveTo_UsrID,0) = " + FileMoveTo_UsrID + ")" + Environment.NewLine;
     SQLSTR += " ORDER BY FileMovementID Desc " + Environment.NewLine;
     return FileMovementDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetArchiveFileStatus(long FileID)
   {
     string SQLSTR = "";

     DataAccess.FileMovement FileMovementDataAccess = new DataAccess.FileMovement();

     SQLSTR = " SELECT * FROM FileMaster WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " AND FileID = " + FileID + Environment.NewLine;
     return FileMovementDataAccess.FillData(SQLSTR);
   }
   



  }
}
