﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
  public class FileNumPrefixSetup
  {
   DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

   public void SaveFileNumPrefixSetup(Entity.FileNumPrefixSetup FileNumPrefixSetupEntity)
   {
     DataAccess.FileNumPrefixSetup FileNumPrefixSetupDataAccess = new DataAccess.FileNumPrefixSetup();
     FileNumPrefixSetupDataAccess.SaveFileNumPrefixSetup(FileNumPrefixSetupEntity);
   }


   public DataTable fn_GetFileNumPrefixData(long BranchID)
   {
     string SQLSTR = "";
     DataAccess.FileNumPrefixSetup FileNumPrefixSetupDataAccess = new DataAccess.FileNumPrefixSetup();

     SQLSTR = " SELECT * FROM FileNumPrefixSetup WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " AND BranchID = " + BranchID + Environment.NewLine;

     return FileNumPrefixSetupDataAccess.FillData(SQLSTR);
   }
  }
}
