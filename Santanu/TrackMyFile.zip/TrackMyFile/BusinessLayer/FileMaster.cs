﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
 public class FileMaster
  {
   DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

   public void SaveFileMaster(Entity.FileMaster FileMasterEntity)
   {
     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();
     FileMasterDataAccess.SaveFileMaster(FileMasterEntity);
   }

   public void UpdateFileMaster(Entity.FileMaster FileMasterEntity)
   {
     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();
     FileMasterDataAccess.UpdateFileMaster(FileMasterEntity);
   }

   public void DeleteFileMaster(Entity.FileMaster FileMasterEntity)
   {
     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();
     FileMasterDataAccess.DeleteFileMaster(FileMasterEntity);
   }

   public void UpdateFileArchiveState(Entity.FileMaster FileMasterEntity)
   {
     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();
     FileMasterDataAccess.UpdateFileArchiveState(FileMasterEntity);
   }


   public DataTable fn_GetFileMasterDetail(long FileID, long DeptID)
   {
     string SQLSTR = "";

     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

     SQLSTR = " SELECT * FROM [vw_FileMaster] WHERE 1 = 1 " + Environment.NewLine;
     if (FileID > 0)
     {
       SQLSTR += " AND FileID = " + FileID + Environment.NewLine;
     }
     if (DeptID > 0)
     {
       SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     }

     SQLSTR += " ORDER BY FileID " + Environment.NewLine;

     return FileMasterDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetAccountFilesList(long DeptID, string csUsrLoginNm)
   {
     string SQLSTR = "";

     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

     SQLSTR = " SELECT * FROM [vw_FileMaster] WHERE 1 = 1 " + Environment.NewLine;
     SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     SQLSTR += " AND CreatedBy = " + mAdmHlp.SpecialToChar(csUsrLoginNm) + Environment.NewLine;
     SQLSTR += " ORDER BY FileID " + Environment.NewLine;

     return FileMasterDataAccess.FillData(SQLSTR);
   }

   //public DataTable fn_GetAccountFilesList(long iFileMoveTo_UsrID)
   //{
   //  string SQLSTR = "";

   //  DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

   //  SQLSTR = " SELECT * FROM [vw_FileMovement] " + Environment.NewLine;
   //  SQLSTR += " WHERE FileMovementID IN (SELECT MAX(FileMovementID) FROM vw_FileMovement WHERE FileMoveTo_UsrID = " + iFileMoveTo_UsrID + " GROUP BY FileID)" + Environment.NewLine;
   //  SQLSTR += " AND FileMoveTo_UsrID = " + iFileMoveTo_UsrID + Environment.NewLine;

   //  SQLSTR += " ORDER BY FileID " + Environment.NewLine;

   //  return FileMasterDataAccess.FillData(SQLSTR);
   //}


   public DataTable fn_SearchFileList(string FileStatus, string FileNum, long DeptID, char FileFollowUp)
   {
     string SQLSTR = "";

     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

     SQLSTR = " SELECT * FROM [vw_FileMaster] WHERE 1 = 1 " + Environment.NewLine;
     if (!string.IsNullOrEmpty(FileStatus))
     {
       SQLSTR += " AND FileStatus = " + mAdmHlp.SpecialToChar(FileStatus) + Environment.NewLine;
     }
     if (!string.IsNullOrEmpty(FileNum))
     {
       SQLSTR += " AND FileNum LIKE " + mAdmHlp.SpecialToChar(FileNum) + Environment.NewLine;
     }
     if (DeptID > 0)
     {
       SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
     }

     if (FileFollowUp!=null)
     {
       SQLSTR += " AND FileFollowUp = '" + FileFollowUp + "'" + Environment.NewLine;
     }
     return FileMasterDataAccess.FillData(SQLSTR);
   }

   public DataTable fn_GetADMFileListAll(string csFileNum)
   {
     string SQLSTR = "";

     DataAccess.FileMaster FileMasterDataAccess = new DataAccess.FileMaster();

     SQLSTR = " SELECT * FROM [vw_FileMaster] WHERE 1 = 1 " + Environment.NewLine;
     if (!string.IsNullOrEmpty(csFileNum))
     {
       csFileNum = '%' + csFileNum + '%';
       SQLSTR += " AND FileNum LIKE " + mAdmHlp.SpecialToChar(csFileNum) + Environment.NewLine;
     }
     SQLSTR += " ORDER BY FileID " + Environment.NewLine;

     return FileMasterDataAccess.FillData(SQLSTR);
   }



  }
}
