﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
  public class AllMenu
    {
        public DataTable LoadDataTable(string SQLSTR)
        {
            DataAccess.AllMenu ReportDataAcces = new DataAccess.AllMenu();
            return ReportDataAcces.LoadDataTable(SQLSTR);
        }

    }
}
