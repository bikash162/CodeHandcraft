﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
 public class BranchMaster
  {
     DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

     public void SaveBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         DataAccess.BranchMaster BranchMasterDataAccess = new DataAccess.BranchMaster();
         BranchMasterDataAccess.SaveBranchMaster(BranchMasterEntity);
     }

     public void UpdateBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         DataAccess.BranchMaster BranchMasterDataAccess = new DataAccess.BranchMaster();
         BranchMasterDataAccess.UpdateBranchMaster(BranchMasterEntity);
     }

     public void DeleteBranchMaster(Entity.BranchMaster BranchMasterEntity)
     {
         DataAccess.BranchMaster BranchMasterDataAccess = new DataAccess.BranchMaster();
         BranchMasterDataAccess.DeleteBranchMaster(BranchMasterEntity);
     }

   public DataTable fn_GetBranchMasterList(long BranchID)
   {
     string SQLSTR = "";

     DataAccess.BranchMaster BranchMasterDataAccess = new DataAccess.BranchMaster();

     SQLSTR = " SELECT * FROM BranchMaster WHERE 1 = 1 " + Environment.NewLine;

    if (BranchID > 0)
     {
         SQLSTR += " AND BranchID = " + BranchID + Environment.NewLine;
     }

     SQLSTR += " ORDER BY BranchNm " + Environment.NewLine;

     return BranchMasterDataAccess.FillData(SQLSTR);
   }

  }
}
