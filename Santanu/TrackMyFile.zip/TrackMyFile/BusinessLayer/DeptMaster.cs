﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
  public class DeptMaster
    {
      DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();

      public void SaveDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          DataAccess.DeptMaster DeptMasterDataAccess = new DataAccess.DeptMaster();
          DeptMasterDataAccess.SaveDeptMaster(DeptMasterEntity);
      }

      public void UpdateDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          DataAccess.DeptMaster DeptMasterDataAccess = new DataAccess.DeptMaster();
          DeptMasterDataAccess.UpdateDeptMaster(DeptMasterEntity);
      }

      public void DeleteDeptMaster(Entity.DeptMaster DeptMasterEntity)
      {
          DataAccess.DeptMaster DeptMasterDataAccess = new DataAccess.DeptMaster();
          DeptMasterDataAccess.DeleteDeptMaster(DeptMasterEntity);
      }

      public DataTable fn_GetDeptMasterList(long DeptID)
      {
          string SQLSTR = "";

          DataAccess.DeptMaster DeptMasterDataAccess = new DataAccess.DeptMaster();

          SQLSTR = " SELECT BranchDept = BranchNm + '....' + DeptNm, * FROM [vw_BranchWiseDept] WHERE 1 = 1 " + Environment.NewLine;

          if (DeptID > 0)
          {
              SQLSTR += " AND DeptID = " + DeptID + Environment.NewLine;
          }

          SQLSTR += " ORDER BY BranchNm, DeptNm " + Environment.NewLine;

          return DeptMasterDataAccess.FillData(SQLSTR);
      }

    }
}
