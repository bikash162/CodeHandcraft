﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayer
{
    public class AutoNumberGeneration
    {
        public Entity.AutoNumnerGeneration GetAutoNumber(string SQLSTR)
        {
            return DataAccess.AutoNumberGeneration.GetAutoNumber(SQLSTR);
        }
        public string GetSystemDt()
        {
            DataAccess.AutoNumberGeneration AutoNumnerGenerationDataAcces = new DataAccess.AutoNumberGeneration();
            return AutoNumnerGenerationDataAcces.GetSystemDt();
        }
        public string PagePermission(int PageId, string UserType)
        {
            DataAccess.AutoNumberGeneration AutoNumnerGenerationDataAcces = new DataAccess.AutoNumberGeneration();
            return AutoNumnerGenerationDataAcces.PagePermission(PageId, UserType);
        }
    }
}
