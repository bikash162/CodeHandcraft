﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Xml.Linq;

    public class mEnum
    {

        public mEnum()
        { 
        }

        public enum eAddEdit
        {
            Add,
            Edit,
            List,
        };
    }
