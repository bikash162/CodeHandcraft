﻿using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TrackMyFile
{
    public class SysInfo
    {
        static protected string TodayDt;
        static protected string FinYr;
        //
        SqlConnection SqlCnn = new SqlConnection(ConfigurationSettings.AppSettings["CONN"]);
        SqlDataAdapter SqlAdpt;
        DataSet DataSt;
        DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
        string StrSql;

        public SysInfo()
        {
            //
            // TODO: Add constructor logic here
            //

        }
        public void SetInfo()
        {
            _SetDate();
            _SetFinYr();
        }

        public string getDate()
        {
            return TodayDt;
        }

        public string getFinYear()
        {
            return FinYr;
        }

        private void _SetDate()
        {
            myDTFI.ShortDatePattern = "dd-MMM-yyyy";
            TodayDt = Convert.ToString(DateTime.Now.ToString("d", myDTFI));
        }

        private void _SetFinYr()
        {
            StrSql = "Select * From BGT_FIN_YR_MST " +
                     "Where '" + TodayDt + "' >= ST_DT " +
                     "And '" + TodayDt + "' <= END_DT ";
            
            SqlAdpt = new SqlDataAdapter(StrSql, SqlCnn);
            DataSt = new DataSet();
            SqlAdpt.Fill(DataSt);
            FinYr = "";
            if (DataSt.Tables[0].DefaultView.Count > 0)
            {
                FinYr = DataSt.Tables[0].DefaultView[0]["FIN_YR_CD"].ToString();
            }


        }







    }
}
