﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

public partial class AddEditDeptMaster : System.Web.UI.Page
{
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
        MSession.fn_CheckAdmSession();
        if (!Page.IsPostBack)
        {
            s_InitializeData();
            s_PopulateBranch();
            s_BindData();
        }
    }

    private void s_InitializeData()
    {
        lblDeptID.Text = "";
        txtDeptNm.Text = "";
        txtDescr.Text = "";
    }

    private void s_PopulateBranch()
    {
      try
      {
        DataTable dt;
        BusinessLayer.BranchMaster BranchMasterList = new BusinessLayer.BranchMaster();
        dt = BranchMasterList.fn_GetBranchMasterList(0);
        if (dt != null)
        {
          ddlBranch.DataSource = dt;
          ddlBranch.DataBind();
        }

        ddlBranch.Items.Insert(0, new ListItem("--Select Branch--", "0"));
        
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_BindData()
    {
        try
        {
            DataTable dt;
            BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
            dt = DeptMasterList.fn_GetDeptMasterList(0);
            if (dt != null)
            {
                MyGV.DataSource = dt;
                MyGV.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }


    private void s_PopulateDeptInfo(Int64 DeptID)
    {
        try
        {
            DataTable dt;
            BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
            dt = DeptMasterList.fn_GetDeptMasterList(Convert.ToInt64(DeptID));
            if (dt != null && dt.Rows.Count > 0)
            {
              try
              {
                ddlBranch.SelectedIndex = -1;
                ddlBranch.Items.FindByValue(dt.Rows[0]["BranchID"].ToString()).Selected = true;
              }
              catch (Exception ex)
              {
                ddlBranch.SelectedIndex = -1;
              }
                lblDeptID.Text = dt.Rows[0]["DeptID"].ToString();
                txtDeptNm.Text = dt.Rows[0]["DeptNm"].ToString();
                txtDescr.Text = dt.Rows[0]["DeptDesc"].ToString();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    private bool fn_ValidateData()
    {
      if (ddlBranch.SelectedItem.Value == "0")
      {
        ShowMessage("Branch is Required !!");
        return false;
      }

      if (txtDeptNm.Text == "")
      {
          ShowMessage("Department Name is Required !!");
          return false;
      }
      return true;
    }

    private void s_SaveDeptMaster()
    {
        try
        {
            if (fn_ValidateData() == false)
            {
                return;
            }

            long DeptID;
            try
            {
                DeptID = Convert.ToInt64(lblDeptID.Text);
            }
            catch 
            {
                DeptID = 0;
            }

            long BranchID;
            try
            {
              BranchID = Convert.ToInt64(ddlBranch.SelectedItem.Value);
            }
            catch
            {
              BranchID = 0;
            }

            BusinessLayer.DeptMaster DeptMasterLogic = new BusinessLayer.DeptMaster();
            Entity.DeptMaster DeptMasterEntity = new Entity.DeptMaster();
            DeptMasterEntity.DeptID = DeptID;
            DeptMasterEntity.DeptNm = txtDeptNm.Text + "";
            DeptMasterEntity.DeptDesc = txtDescr.Text + "";
            if (DeptID > 0)
            {
                DeptMasterLogic.UpdateDeptMaster(DeptMasterEntity);
            }
            else
            {
              DeptMasterEntity.BranchID = BranchID;
              DeptMasterLogic.SaveDeptMaster(DeptMasterEntity);
            }
            s_InitializeData();
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("btnEdit"))
        {
            Int64 DeptID = Convert.ToInt64(e.CommandArgument.ToString());
            s_PopulateDeptInfo(DeptID);
        }
        else if (e.CommandName.Equals("btnDelete"))
        {
            try
            {
                Int64 DeptID = Convert.ToInt64(e.CommandArgument.ToString());
                BusinessLayer.DeptMaster DeptMasterLogic = new BusinessLayer.DeptMaster();
                Entity.DeptMaster DeptMasterEntity = new Entity.DeptMaster();
                DeptMasterEntity.DeptID = DeptID;
                DeptMasterLogic.DeleteDeptMaster(DeptMasterEntity);
                s_BindData();
                s_InitializeData();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MyGV.PageIndex = e.NewPageIndex;
        s_BindData();
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        s_InitializeData();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        s_SaveDeptMaster();
        s_BindData();
    }

    protected void ShowMessage(string message)
    {
        string script = "<script language='JavaScript'>alert('" + message + "')</script>";
        Page.RegisterStartupScript("PopUp", script);
    }


}

