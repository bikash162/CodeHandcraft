﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

  public partial class AddEditFileMaster : System.Web.UI.Page
  {
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();
    protected mQueryString mQueryString = new mQueryString();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!Page.IsPostBack)
      {
        lblMode.Text = mQueryString.qs_AddEdit;
        lblFileID.Text = mQueryString.qs_FileID;

        if (lblMode.Text == mEnum.eAddEdit.Edit.ToString())
        {
          s_PopulateData();
        }
        else if (lblMode.Text == mEnum.eAddEdit.Add.ToString())
        {
          s_PopulateFileNumPrefixData();
        }
      }
    }

    private void s_PopulateFileNumPrefixData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileNumPrefixSetup FileNumPrefixSetupData = new BusinessLayer.FileNumPrefixSetup();
        dt = FileNumPrefixSetupData.fn_GetFileNumPrefixData(Convert.ToInt64(Session["BranchID"].ToString()));
        if (dt != null && dt.Rows.Count > 0)
        {
          txtFileNo.Text = dt.Rows[0]["FileNumPrefix"].ToString();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_PopulateData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMaster FileMasterData = new BusinessLayer.FileMaster();
        dt = FileMasterData.fn_GetFileMasterDetail(Convert.ToInt64(lblFileID.Text),0);
        if (dt != null && dt.Rows.Count > 0)
        {

          txtFileNo.Text = dt.Rows[0]["FileNum"].ToString();
          txtSubject.Text = dt.Rows[0]["SubMatter"].ToString();

          try
          {
            dropYear.SelectedIndex = -1;
            dropYear.Items.FindByValue(dt.Rows[0]["FileOpenYr"].ToString()).Selected = true;
          }
          catch
          {
            dropYear.SelectedIndex = -1;
          }
          txtOfficer.Text = dt.Rows[0]["InitialOfficer"].ToString();
          txtPhoneNo.Text = dt.Rows[0]["PhoneNo"].ToString();
          txtRemarks.Text = dt.Rows[0]["Remarks"].ToString();

          if (dt.Rows[0]["FileFollowUp"].ToString() == "Y")
          {
            chkFollowUp.Checked = true;
          }
          else
          {
            chkFollowUp.Checked = false;
          }

        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private bool fn_ValidateData()
    {

      if (txtFileNo.Text == "")
      {
        ShowMessage("File Number is Required");
        return false;
      }

      if (txtSubject.Text == "")
      {
        ShowMessage("Subject is Required");
        return false;
      }

      if (dropYear.SelectedItem.Value + "" == "")
      {
        ShowMessage("Year is required");
        return false;
      }

      return true;

    }

    private void s_SaveData()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }

        char FileFollowUp;
        if (chkFollowUp.Checked == true)
        {
          FileFollowUp = Convert.ToChar("Y");
        }
        else
        {
          FileFollowUp = Convert.ToChar("N");
        }

        BusinessLayer.FileMaster FileMasterLogic = new BusinessLayer.FileMaster();
        Entity.FileMaster FileMasterEntity = new Entity.FileMaster();

        FileMasterEntity.DeptID =Convert.ToInt64(Session["DeptID"]);
        FileMasterEntity.FileNum = txtFileNo.Text + "";
        FileMasterEntity.SubMatter = txtSubject.Text + "";
        FileMasterEntity.FileOpenYr = dropYear.SelectedItem.Value + "";
        FileMasterEntity.InitialOfficer = txtOfficer.Text + "";
        FileMasterEntity.PhoneNo= txtPhoneNo.Text + "";
        FileMasterEntity.Remarks = txtRemarks.Text + "";
        FileMasterEntity.FileFollowUp = FileFollowUp;

        if (lblMode.Text == mEnum.eAddEdit.Add.ToString())
        {
          FileMasterEntity.CreatedBy = Convert.ToString(Session["UsrLoginNm"]);
          FileMasterEntity.UsrID = Convert.ToInt64(Session["UsrID"]);
          FileMasterLogic.SaveFileMaster(FileMasterEntity);
        }
        else if (lblMode.Text == mEnum.eAddEdit.Edit.ToString())
        {
          FileMasterEntity.FileID = Convert.ToInt64(lblFileID.Text);
          FileMasterEntity.LastModBy = Convert.ToString(Session["UsrLoginNm"]);
          FileMasterLogic.UpdateFileMaster(FileMasterEntity);
        }

      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
      Response.Redirect("/Webforms/FileMasterList.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
      Response.Redirect("/Webforms/FileMasterList.aspx");
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);
    }

  }
