﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;


  public partial class ChangePassword : System.Web.UI.Page
  {
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
    }

    private bool fn_ValidateData()
    {
      if (txtOldPwd.Text == "")
      {
        ShowMessage("Old Password is Required");
        return false;
      }

      if (txtNewPwd.Text == "")
      {
        ShowMessage("New Password is Required");
        return false;
      }

      if (txtConfirmPwd.Text == "")
      {
        ShowMessage("Confirm Password is Required");
        return false;
      }

      if (txtConfirmPwd.Text != txtNewPwd.Text)
      {
        ShowMessage("Confirm Password and New Password Not Matched !!!");
        return false;
      }
      return true;
    }

    private void s_SaveData()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }

        BusinessLayer.Users UsersLogic = new BusinessLayer.Users();
        Entity.Users UsersEntity = new Entity.Users();

        UsersEntity.UsrID = Convert.ToInt64(Session["UsrID"]);
        UsersEntity.UsrPwd = txtOldPwd.Text + "";
        UsersEntity.UsrNewPwd = txtNewPwd.Text + "";
        UsersLogic.UpdUsrPassword(UsersEntity);
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_InitializeData()
    { 
      txtOldPwd.Text="";
      txtNewPwd.Text = "";
      txtConfirmPwd.Text = "";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
      s_InitializeData();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

  }
