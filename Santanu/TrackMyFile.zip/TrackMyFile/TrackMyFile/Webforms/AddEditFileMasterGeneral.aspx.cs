﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;

  public partial class AddEditFileMasterGeneral : System.Web.UI.Page
  {
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSplFileEntrySession();
      if (!Page.IsPostBack)
      {
        s_PopulateDept();
        s_PopulatePersons();
        s_PopulateFileNumPrefixData();
        s_BindGrid();
      }
    }

    private void s_PopulateFileNumPrefixData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileNumPrefixSetup FileNumPrefixSetupData = new BusinessLayer.FileNumPrefixSetup();
        dt = FileNumPrefixSetupData.fn_GetFileNumPrefixData(Convert.ToInt64(Session["BranchID"].ToString()));
        if (dt != null && dt.Rows.Count > 0)
        {
          txtFileNo.Text = dt.Rows[0]["FileNumPrefix"].ToString();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_PopulateDept()
    {
      try
      {
        DataTable dt;
        BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
        dt = DeptMasterList.fn_GetDeptMasterList(0);
        if (dt != null)
        {
          dropDept.DataSource = dt;
          dropDept.DataBind();

          ListItem list = new ListItem("-- Select Department --", "");
          dropDept.Items.Insert(0, list);
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_InitializeData()
    {
      s_PopulateFileNumPrefixData();
      txtSubject.Text = "";
      dropYear.SelectedIndex = -1;
      s_PopulateDept();
      s_PopulatePersons();
      //dropDept.SelectedIndex = -1;
      //ddlFileMoveTo_UsrID.SelectedIndex = -1;
      txtOfficer.Text = "";
      txtPhoneNo.Text = "";
      txtRemarks.Text = "";
      chkFollowUp.Checked = true;
    }

    protected void dropDept_SelectedIndexChanged(object sender, EventArgs e)
    {
      s_PopulatePersons();
    }

    private void s_PopulatePersons()
    {
      try
      {
        long DeptID;

        try
        {
          DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        }
        catch (Exception ex)
        {
          DeptID = 0;
        }

        ddlFileMoveTo_UsrID.Items.Clear();
        DataTable dt;
        BusinessLayer.Users UsersList = new BusinessLayer.Users();
        dt = UsersList.fn_GetDeptwiseUsers(DeptID);
        if (dt != null)
        {
          ddlFileMoveTo_UsrID.DataSource = dt;
          ddlFileMoveTo_UsrID.DataBind();
        }

        ddlFileMoveTo_UsrID.Items.Insert(0, new ListItem("--Select Person--", "0"));

      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private string fn_GetUsrLoginNm(long UsrID)
    {
      string GetUsrLoginNm = "";

      try
      {
        DataTable dt;
        BusinessLayer.Users UsersList = new BusinessLayer.Users();
        dt = UsersList.fn_GetDept(UsrID);
        if (dt != null && dt.Rows.Count > 0)
        {
          GetUsrLoginNm = dt.Rows[0]["UsrLoginNm"].ToString();
        }
      }
      catch (Exception ex)
      {
        GetUsrLoginNm = "";
        ShowMessage(ex.Message);
      }
      return GetUsrLoginNm;

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
      s_BindGrid();
      s_InitializeData();
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
      s_InitializeData();
    }

    private bool fn_ValidateData()
    {

      if (txtFileNo.Text == "")
      {
        ShowMessage("File Number is Required");
        return false;
      }

      if (txtSubject.Text == "")
      {
        ShowMessage("Subject is Required");
        return false;
      }

      if (dropYear.SelectedItem.Value + "" == "")
      {
        ShowMessage("Year is required");
        return false;
      }

      if (dropDept.SelectedItem.Value + "" == "0" || dropDept.SelectedItem.Value + "" == "")
      {
        ShowMessage("Dept. is required");
        return false;
      }

      if (ddlFileMoveTo_UsrID.SelectedItem.Value + "" == "0" || ddlFileMoveTo_UsrID.SelectedItem.Value + "" == "")
      {
        ShowMessage("Person is required");
        return false;
      }

      return true;

    }

    private void s_SaveData()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }

        char FileFollowUp;
        if (chkFollowUp.Checked == true)
        {
          FileFollowUp = Convert.ToChar("Y");
        }
        else
        {
          FileFollowUp = Convert.ToChar("N");
        }

        string csUsrLoginNm = "";
        try
        {
          csUsrLoginNm = fn_GetUsrLoginNm(Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value));
        }
        catch (Exception ex)
        {
          csUsrLoginNm = "";
        }

        if (csUsrLoginNm == "")
        {
          return;
        }

        BusinessLayer.FileMaster FileMasterLogic = new BusinessLayer.FileMaster();
        Entity.FileMaster FileMasterEntity = new Entity.FileMaster();

        FileMasterEntity.DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        FileMasterEntity.FileNum = txtFileNo.Text + "";
        FileMasterEntity.SubMatter = txtSubject.Text + "";
        FileMasterEntity.FileOpenYr = dropYear.SelectedItem.Value + "";
        FileMasterEntity.InitialOfficer = txtOfficer.Text + "";
        FileMasterEntity.PhoneNo = txtPhoneNo.Text + "";
        FileMasterEntity.Remarks = txtRemarks.Text + "";
        FileMasterEntity.FileFollowUp = FileFollowUp;

        FileMasterEntity.CreatedBy = csUsrLoginNm + "";
        FileMasterEntity.UsrID = Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value);
        FileMasterLogic.SaveFileMaster(FileMasterEntity);
        ShowMessage("File Saved Successfully.");
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_BindGrid()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMaster FileMasterList = new BusinessLayer.FileMaster();
        dt = FileMasterList.fn_GetADMFileListAll(txtFileNum.Text + "");
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      s_BindGrid();
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindGrid();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);
    }


  }

