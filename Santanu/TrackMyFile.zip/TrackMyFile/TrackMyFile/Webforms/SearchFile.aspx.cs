﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;
using AjaxControlToolkit;

public partial class SearchFile : System.Web.UI.Page
  {
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!Page.IsPostBack)
      {
        s_PopulateBranch();
        s_BindData();
      }
      tblHeader.Visible = false;
      btnCancel.Visible = false;
    }

    private void s_PopulateBranch()
    {
      try
      {
        DataTable dt;
        BusinessLayer.BranchMaster BranchMasterList = new BusinessLayer.BranchMaster();
        dt = BranchMasterList.fn_GetBranchMasterList(0);
        if (dt != null)
        {
          dropBranch.DataSource = dt;
          dropBranch.DataBind();

          ListItem list = new ListItem("-- Select Branch --", "");
          dropBranch.Items.Insert(0, list);

          //Branch Selection from Session
          try
          {
            if (Convert.ToInt64(Session["BranchID"]) > 0)
            {
              dropBranch.SelectedIndex = -1;
              dropBranch.Items.FindByValue(Convert.ToString(Session["BranchID"])).Selected = true;
              dropBranch.Enabled = false;
            }
          }
          catch (Exception ex)
          {
            dropBranch.SelectedIndex = -1;
            dropBranch.Enabled = true;
          }
          //Branch Selection from Session
        
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      s_BindData();
    }

    private void s_BindData()
    {
      try
      {
        long branchID =0;
        try
        {
          branchID=Convert.ToInt64(dropBranch.SelectedItem.Value);
        }
        catch
        {
          branchID=0;
        }
        

        char fileFollowUp = Convert.ToChar("N");
        if (chkFileFollowUp.Checked == true)
        {
          fileFollowUp = Convert.ToChar("Y");
        }
        else if (chkFileFollowUp.Checked == false)
        {
          fileFollowUp = Convert.ToChar("N");
        }

        string csFileNo="";
        if (txtFileNo.Text != "")
        {
          csFileNo = "%" + txtFileNo.Text.Trim() + "%";
        }

        DataTable dt;
        BusinessLayer.FileMaster FileMasterList = new BusinessLayer.FileMaster();
        dt = FileMasterList.fn_SearchFileList("", csFileNo + "", 0, fileFollowUp);
        if (dt != null)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindData();
    }

    protected void MyGV_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        //Label lblStatus = e.Row.FindControl("lblStatus") as Label;
        //if (Convert.ToString(dr["FileStatus"]) == "I")
        //{
        //  lblStatus.Text = "Moved IN";
        //}
        //else if (Convert.ToString(dr["FileStatus"]) == "O")
        //{
        //    lblStatus.Text = "Moved Out";
        //}
        //else
        //{
        //  lblStatus.Text = "Not Moved";
        //}
      }
    }

    private void s_BindDataMyGVM(long FileID)
    {
      try
      {
        DataTable dtM;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dtM = FileMovementList.fn_GetFileMovementDetail(Convert.ToInt64(FileID));
        if (dtM != null)
        {
          MyGVM.DataSource = dtM;
          MyGVM.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGVM_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        Label lblMoveDt = e.Row.FindControl("lblMoveDt") as Label;
        Label lblActivity = e.Row.FindControl("lblActivity") as Label;
        myDTFI.ShortDatePattern = "dd-MM-yyyy";
        lblMoveDt.Text = Convert.ToDateTime(dr["MoveDt"]).ToString("d", myDTFI);

        if (Convert.ToString(dr["FileMoveType"]) == "I")
        {
          lblActivity.Text = "File Moved In " + dr["DeptNm"] + " by " + dr["UsrNm"];
        }
        else if (Convert.ToString(dr["FileMoveType"]) == "O")
        {
          lblActivity.Text = "File Moved Out For " + dr["DeptNm"] + ", " + dr["UsrNm"];
        }
      }
    }

    protected void lnkView_Click(object sender, EventArgs e)
    {
      LinkButton btndetails = sender as LinkButton;
      GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
      s_BindDataMyGVM(Convert.ToInt64(MyGV.DataKeys[gvrow.RowIndex].Value.ToString()));
      btnCancel.Visible = true;
      tblHeader.Visible = true;
      this.ModalPopupExtender1.Show();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

  }
