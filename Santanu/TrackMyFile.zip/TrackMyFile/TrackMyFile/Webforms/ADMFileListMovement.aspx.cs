﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;
using System.Globalization;



public partial class ADMFileListMovement : System.Web.UI.Page
  {
    protected mSession MSession = new mSession();
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckAdmSession();
      if (!IsPostBack)
      {
        s_BindData();
      }
    }

    private void s_BindData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMaster FileMasterList = new BusinessLayer.FileMaster();
        dt = FileMasterList.fn_GetADMFileListAll(txtFileSearch.Text + "");
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      s_BindData();
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindData();
    }

    protected void MyGV_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        System.Web.UI.WebControls.Image imgArchive = e.Row.FindControl("imgArchive") as System.Web.UI.WebControls.Image;

        //Archive
        if (Convert.ToString(dr["FileFollowUp"]) == "N")
        {
          imgArchive.Visible = true;
        }
        else
        {
          imgArchive.Visible = false;
        }

      }
    }

    protected void btnManageMovements_Click(object sender, ImageClickEventArgs e)
    {
      ImageButton btndetails = sender as ImageButton;
      GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
      lblFileID.Text = MyGV.DataKeys[gvrow.RowIndex].Value.ToString();
      s_PopulateDept();
      btnCancel.Visible = true;
      tblHeader.Visible = true;
      
      this.ModalPopupExtender1.Show();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
    }
  
    private bool fn_ValidateData()
    {
      if (Convert.ToInt64(dropDept.SelectedItem.Value) <= 0)
      {
        ShowMessage("Department is Required.");
        return false;
      }

      if (Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value) <= 0)
      {
        ShowMessage("Person is Required.");
        return false;
      }

      return true;
    }

    private void s_SaveData()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }

        long iFileMoveTo_UsrID;
        try
        {
          iFileMoveTo_UsrID = Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value);
        }
        catch (Exception ex)
        {
          iFileMoveTo_UsrID = 0;
        }
        BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
        Entity.FileMovement FileMovementEntity = new Entity.FileMovement();

        FileMovementEntity.FileID = Convert.ToInt64(lblFileID.Text);
        FileMovementEntity.DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        FileMovementEntity.Remarks = txtRemarks.Text + "";
        FileMovementEntity.FileMoveTo_UsrID = iFileMoveTo_UsrID;
        FileMovementLogic.SaveADMFileMovement(FileMovementEntity);
        lblFileID.Text = "";
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_PopulateDept()
    {
      try
      {
        DataTable dt;
        BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
        dt = DeptMasterList.fn_GetDeptMasterList(0);
        if (dt != null)
        {
          dropDept.DataSource = dt;
          dropDept.DataBind();

          ListItem list = new ListItem("-- Select Department --", "");
          dropDept.Items.Insert(0, list);
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_PopulatePersons()
    {
      try
      {
        long DeptID;

        try
        {
          DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        }
        catch (Exception ex)
        {
          DeptID = 0;
        }

        ddlFileMoveTo_UsrID.Items.Clear();
        DataTable dt;
        BusinessLayer.Users UsersList = new BusinessLayer.Users();
        dt = UsersList.fn_GetDeptwiseUsers(DeptID);
        if (dt != null)
        {
          ddlFileMoveTo_UsrID.DataSource = dt;
          ddlFileMoveTo_UsrID.DataBind();
        }

        ddlFileMoveTo_UsrID.Items.Insert(0, new ListItem("--Select Person--", "0"));

      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void dropDept_SelectedIndexChanged(object sender, EventArgs e)
    {
      s_PopulatePersons();
      this.ModalPopupExtender1.Show();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

    #region Popup

    private void s_BindData(long iFileID)
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dt = FileMovementList.fn_GetFileMovementDetail(Convert.ToInt64(iFileID));
        if (dt != null)
        {
          MyGV2.DataSource = dt;
          MyGV2.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      if (e.CommandName.Equals("ViewDetail"))
      {
        try
        {
          long FileID = Convert.ToInt64(e.CommandArgument.ToString());
          s_BindData(FileID);
          divGrid.Visible = true;
          this.ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
          ShowMessage(ex.Message);
        }
      }
    }

    protected void MyGV2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        Label lblMoveDt = e.Row.FindControl("lblMoveDt") as Label;
        Label lblActivity = e.Row.FindControl("lblActivity") as Label;
        myDTFI.ShortDatePattern = "dd-MM-yyyy";
        lblMoveDt.Text = Convert.ToDateTime(dr["MoveDt"]).ToString("d", myDTFI);

        if (Convert.ToString(dr["FileMoveType"]) == "I")
        {
          lblActivity.Text = "File Moved In " + dr["DeptNm"] + " by " + dr["UsrNm"];
        }
        else if (Convert.ToString(dr["FileMoveType"]) == "O")
        {
          lblActivity.Text = "File Moved Out For " + dr["DeptNm"] + ", " + dr["UsrNm"];
        }
      }
    }

    #endregion

  }
