﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;


public partial class FileMoveOfficials : System.Web.UI.Page
  {
  protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!IsPostBack)
      {
        s_BindList();
        s_BindGrid();
      }
    }

    private void s_BindList()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMoveOfficials FileMoveOfficialsList = new BusinessLayer.FileMoveOfficials();
        dt = FileMoveOfficialsList.fn_GetOfficialList(Convert.ToInt64(Session["UsrID"]));
        if (dt != null && dt.Rows.Count > 0)
        {
          chkOfficials.DataSource = dt;
          chkOfficials.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_BindGrid()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMoveOfficials FileMoveOfficialsList = new BusinessLayer.FileMoveOfficials();
        dt = FileMoveOfficialsList.fn_GetFileMoveOfficialsList(Convert.ToInt64(Session["UsrID"]));
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
      s_BindList();
      s_BindGrid();
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      if (e.CommandName.Equals("btnDelete"))
      {
        Int64 UsrMappID = Convert.ToInt64(e.CommandArgument.ToString());
        BusinessLayer.FileMoveOfficials FileMoveOfficialsLogic = new BusinessLayer.FileMoveOfficials();
        Entity.FileMoveOfficials FileMoveOfficialsEntity = new Entity.FileMoveOfficials();
        FileMoveOfficialsEntity.UsrMappID = UsrMappID;
        FileMoveOfficialsLogic.DelFileMoveOfficials(FileMoveOfficialsEntity);
        s_BindList();
        s_BindGrid();
      }
    }

    private void s_SaveData()
    {
      try
      {
        BusinessLayer.FileMoveOfficials FileMoveOfficialsLogic = new BusinessLayer.FileMoveOfficials();
        Entity.FileMoveOfficials FileMoveOfficialsEntity = new Entity.FileMoveOfficials();

        foreach (ListItem li in chkOfficials.Items)
        {
          if (li.Selected == true)
          {
            FileMoveOfficialsEntity.UsrID = Convert.ToInt64(li.Value);
            FileMoveOfficialsEntity.CreatedByID = Convert.ToInt64(Session["UsrID"]);
            FileMoveOfficialsLogic.SaveFileMoveOfficials(FileMoveOfficialsEntity);
          }
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }

    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindGrid();
    }

  }
