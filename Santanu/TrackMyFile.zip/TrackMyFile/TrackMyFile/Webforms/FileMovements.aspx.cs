﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;
using System.Drawing;
using System.Globalization;

  public partial class FileMovements : System.Web.UI.Page
  {
    protected mSession MSession = new mSession();
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!IsPostBack)
      {
        s_BindFileMoveOfficials();
        s_BindUsrCurrentFileList();
      }

    }

    private void s_BindUsrCurrentFileList()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dt = FileMovementList.fn_GetCurrentFileListToUsr(Convert.ToInt64(Session["DeptID"]), Convert.ToInt64(Session["UsrID"]));
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_BindFileMoveOfficials()
    {
      try
      {
        ddlOfficialsNm.Items.Clear();
        DataTable dt;
        BusinessLayer.FileMoveOfficials FileMoveOfficialsList = new BusinessLayer.FileMoveOfficials();
        dt = FileMoveOfficialsList.fn_GetFileMoveOfficialsList(Convert.ToInt64(Session["UsrID"]));
        if (dt != null && dt.Rows.Count > 0)
        {
          ddlOfficialsNm.DataSource = dt;
          ddlOfficialsNm.DataBind();
        }

        ddlOfficialsNm.Items.Insert(0, new ListItem("--Select Officials--", "0"));
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private bool fn_ValidateData()
    {
      if (ddlOfficialsNm.SelectedItem.Value == "0")
      {
        ShowMessage("Official Person is Required");
        return false;
      }
      return true;
    }

    protected void btnSendFiles_Click(object sender, EventArgs e)
    {
      try
      {
        string csSendTo;
        csSendTo = "";
        int iCountChkFiles;
        iCountChkFiles = 0;
        try
        {
          foreach (GridViewRow GVRow in MyGV.Rows)
          {
            CheckBox chkFile = (CheckBox)GVRow.FindControl("chkFile");
            System.Web.UI.WebControls.Image imgArchive = (System.Web.UI.WebControls.Image)GVRow.FindControl("imgArchive");
            if (chkFile.Checked == true && imgArchive.Visible == false)
            {
              iCountChkFiles = iCountChkFiles + 1;
            }
          }
        }
        catch (Exception ex)
        {
          ShowMessage(ex.Message);
        }

        if (ddlOfficialsNm.SelectedIndex > 0)
        {
          csSendTo = ddlOfficialsNm.SelectedItem.Text.Trim();
        }

        lblHeader.Text = "Sure to send " + Convert.ToString(iCountChkFiles) + " file(s) " + "to " + csSendTo + "";

        btnCancel.Visible = true;
        btnYes.Visible = true;
        tblHeader.Visible = true;
        this.ModalPopupExtender1.Show();
        }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }

    }

    protected void btnYes_Click(object sender, EventArgs e)
    {
      s_SendFilestoOfficials();
    }

    private void s_SendFilestoOfficials()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }
        int iCount = 0;

        BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
        Entity.FileMovement FileMovementEntity = new Entity.FileMovement();
        foreach (GridViewRow GVRow in MyGV.Rows)
        {
          Label lblFileID = (Label)GVRow.FindControl("lblFileID");
          CheckBox chkFile = (CheckBox)GVRow.FindControl("chkFile");
          System.Web.UI.WebControls.Image imgArchive = (System.Web.UI.WebControls.Image)GVRow.FindControl("imgArchive");

          if (chkFile.Checked == true && imgArchive.Visible==false)
          {
            FileMovementEntity.FileID = Convert.ToInt64(lblFileID.Text);
            FileMovementEntity.DeptID = Convert.ToInt64(fn_GetDept(Convert.ToInt64(ddlOfficialsNm.SelectedItem.Value)));
            FileMovementEntity.Remarks = "";
            FileMovementEntity.CreatedBy = Convert.ToString(Session["UsrLoginNm"]);
            FileMovementEntity.FileMoveTo_UsrID = Convert.ToInt64(ddlOfficialsNm.SelectedItem.Value);
            FileMovementLogic.SaveFileMoveOutIn(FileMovementEntity);
            
            iCount = iCount + 1;
          }
        }

        //if (iCount > 0)
        //{
          //s_BindFileMoveOfficials();
          //s_BindUsrCurrentFileList();
          
          Response.Redirect("~/WebForms/FileMovements.aspx");
          //ShowMessage(Convert.ToString(iCount) + " File(s) sent");
        //}
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }

    }

    private long fn_GetDept(long iUsrID)
    {
      long iDeptID = 0;
      try
      {
        DataTable dt;
        BusinessLayer.Users UsersList = new BusinessLayer.Users();
        dt = UsersList.fn_GetDept(Convert.ToInt64(iUsrID));
        if (dt != null && dt.Rows.Count > 0)
        {
          iDeptID = Convert.ToInt64(dt.Rows[0]["DeptID"]);
        }
      }
      catch (Exception ex)
      {
        iDeptID = 0;
      }
      return iDeptID; 
    }

    protected void MyGV_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        
        DateTime TodayDt = DateTime.Now;
        DateTime MoveDt = Convert.ToDateTime(dr["MoveDt"]);
        TimeSpan Ts = TodayDt - MoveDt;

        double NrOfDays = Ts.TotalDays;

        LinkButton btnFileNum = e.Row.FindControl("btnFileNum") as LinkButton;
        System.Web.UI.WebControls.Image imgArchive = e.Row.FindControl("imgArchive") as System.Web.UI.WebControls.Image;
        //System.Drawing.Image image = ((System.Drawing.Image)row.FindControl("img"));

        if (Convert.ToString(dr["IsFileViewed"]) == "N")
        {
          btnFileNum.Text = "<b>" + Convert.ToString(dr["FileNum"]) + "</b>";
        }
        else
        {
          btnFileNum.Text = Convert.ToString(dr["FileNum"]);
        }

        if (NrOfDays > 1 && NrOfDays <= 3)
        {
          btnFileNum.ForeColor = Color.Green;
        }
        else if (NrOfDays > 3 && NrOfDays <= 7)
        {
          btnFileNum.ForeColor = Color.Orange;
        }
        else if (NrOfDays > 7)
        {
          btnFileNum.ForeColor = Color.Red;
        }
        //Archive

        if (Convert.ToString(dr["FileFollowUp"]) == "N")
        {
          imgArchive.Visible = true;
        }
        else
        {
          imgArchive.Visible = false;
        }

      }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindUsrCurrentFileList();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

#region Popup

    private void s_BindData(long iFileID)
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dt = FileMovementList.fn_GetFileMovementDetail(Convert.ToInt64(iFileID));
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV2.DataSource = dt;
          MyGV2.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_BindtoChkArchive(long iFileID)
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dt = FileMovementList.fn_GetArchiveFileStatus(Convert.ToInt64(iFileID));
        if (dt != null && dt.Rows.Count > 0)
        {
          lblFileIDForArchive.Text = Convert.ToString(iFileID);

          if (dt.Rows[0]["FileFollowup"].ToString() == "N")
          {
            chkArchive.Checked = true;
          }
          else
          {
            chkArchive.Checked = false;
          }
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      if (e.CommandName.Equals("ViewDetail"))
      {
        try
        {
          long FileID = Convert.ToInt64(e.CommandArgument.ToString());
          s_BindData(FileID);
          divGrid.Visible = true;
          this.ModalPopupExtender2.Show();
        }
        catch (Exception ex)
        {
          ShowMessage(ex.Message);
        }
      }

      if (e.CommandName.Equals("Archive"))
      {
        try
        {
          long FileID = Convert.ToInt64(e.CommandArgument.ToString());
          s_BindtoChkArchive(FileID);
          btnCloseArchive.Visible = true;
          btnSaveArchive.Visible = true;
          divArchive.Visible = true;
          this.ModalPopupExtender3.Show();
        }
        catch (Exception ex)
        {
          ShowMessage(ex.Message);
        }
      }
    }

    protected void MyGV2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        Label lblMoveDt = e.Row.FindControl("lblMoveDt") as Label;
        Label lblActivity = e.Row.FindControl("lblActivity") as Label;
        myDTFI.ShortDatePattern = "dd-MM-yyyy";
        lblMoveDt.Text = Convert.ToDateTime(dr["MoveDt"]).ToString("d", myDTFI);

        if (Convert.ToString(dr["FileMoveType"]) == "I")
        {
          lblActivity.Text = "File Moved In " + dr["DeptNm"] + " by " + dr["UsrNm"];
        }
        else if (Convert.ToString(dr["FileMoveType"]) == "O")
        {
          lblActivity.Text = "File Moved Out For " + dr["DeptNm"] + ", " + dr["UsrNm"];
        }
      }
    }

    protected void btnSaveArchive_Click(object sender, EventArgs e)
    {
      try
      {
        char cschkArchive;
        try
        {
          if (chkArchive.Checked == true)
          {
            cschkArchive = Convert.ToChar("N");
          }
          else
          {
            cschkArchive = Convert.ToChar("Y");
          }
        }
        catch (Exception ex)
        {
          cschkArchive = Convert.ToChar("Y");
        }

        BusinessLayer.FileMaster FileMasterLogic = new BusinessLayer.FileMaster();
        Entity.FileMaster FileMasterEntity = new Entity.FileMaster();

        FileMasterEntity.FileID = Convert.ToInt64(lblFileIDForArchive.Text);
        FileMasterEntity.FileFollowUp = Convert.ToChar(cschkArchive);
        FileMasterEntity.LastFollowupBy = Convert.ToString(Session["UsrLoginNm"]);
        FileMasterLogic.UpdateFileArchiveState(FileMasterEntity);
        lblFileIDForArchive.Text = "";

        s_BindFileMoveOfficials();
        s_BindUsrCurrentFileList();
      }
      catch (Exception ex)
      {
        lblFileIDForArchive.Text = "";
        ShowMessage(ex.Message);
      }
    }

#endregion


  }

