﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

  public partial class ManageFileMovements : System.Web.UI.Page
  {
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();
    protected mQueryString mQueryString = new mQueryString();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!Page.IsPostBack)
      {
        lblFileID.Text = mQueryString.qs_FileID;
        s_PopulateFileInfo();
        s_PopulateDept();
        s_PopulatePersons();
        s_BindData();
        //txtDt.Attributes.Add("readonly", "true");

      }
    }

    //private void s_ChangeOnMove()
    //{
    //  if (dropType.SelectedItem.Value == "I")
    //  {
    //    lblMovement.Text = "Moved In Date *";
    //    lblWhom.Text = "From Whom *";
    //  }
    //  else if (dropType.SelectedItem.Value == "O")
    //  {
    //      lblMovement.Text = "Moved Out Date *";
    //      lblWhom.Text = "TO Whom *";
    //  }
    //  //else if (dropType.SelectedItem.Value == "U")
    //  //{
    //  //  lblMovement.Text = "Moved Up Date *";
    //  //  lblWhom.Text = "TO Whom *";
    //  //}
    //  //else if (dropType.SelectedItem.Value == "D")
    //  //{
    //  //  lblMovement.Text = "Moved Down Date *";
    //  //  lblWhom.Text = "From Whom *";
    //  //}
    //  //else if (dropType.SelectedItem.Value == "B")
    //  //{
    //  //  lblMovement.Text = "Moved Back Date *";
    //  //  lblWhom.Text = "To Whom *";
    //  //}
    //  //else if (dropType.SelectedItem.Value == "E")
    //  //{
    //  //    lblMovement.Text = "Dispose Date *";
    //  //    lblWhom.Text = "By Whom *";
    //  //}
    //  else
    //  {
    //    lblMovement.Text = "";
    //    lblWhom.Text = "";
    //  }
    //}

    private void s_PopulateDept()
    {
        try
        {
            DataTable dt;
            BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
            dt = DeptMasterList.fn_GetDeptMasterList(0);
            if (dt != null)
            {
                dropDept.DataSource = dt;
                dropDept.DataBind();

                ListItem list = new ListItem("-- Select Department --", "");
                dropDept.Items.Insert(0, list);
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    private bool fn_ValidateData()
    {
        if (Convert.ToInt64(dropDept.SelectedItem.Value) <= 0)
        {
          ShowMessage("Department is Required.");
          return false;
        }

        if (Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value) <= 0)
        {
          ShowMessage("Person is Required.");
          return false;
        }

        return true;
    }


    private void s_SaveData()
    {
      try
      {
        if (fn_ValidateData() == false)
        {
          return;
        }

        long iFileMoveTo_UsrID;
        try
        {
            iFileMoveTo_UsrID =Convert.ToInt64(ddlFileMoveTo_UsrID.SelectedItem.Value);
        }
        catch (Exception ex)
        {
            iFileMoveTo_UsrID = 0;
        }
        BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
        Entity.FileMovement FileMovementEntity = new Entity.FileMovement();

        FileMovementEntity.FileID = Convert.ToInt64(lblFileID.Text);
        FileMovementEntity.DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        FileMovementEntity.Remarks = txtRemarks.Text + "";
        FileMovementEntity.CreatedBy = Convert.ToString(Session["UsrLoginNm"]);
        FileMovementEntity.FileMoveTo_UsrID = iFileMoveTo_UsrID;
        FileMovementLogic.SaveFileMoveOutIn(FileMovementEntity);
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private void s_InitializeData()
    {
      dropDept.SelectedIndex = -1;
      ddlFileMoveTo_UsrID.SelectedIndex = -1;
      txtRemarks.Text = "";
    }

    private void s_BindData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dt = FileMovementList.fn_GetFileMovementDetail(Convert.ToInt64(lblFileID.Text));
        if (dt != null)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindData();
    }

    protected void MyGV_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        Label lblMoveDt = e.Row.FindControl("lblMoveDt") as Label;
        Label lblActivity = e.Row.FindControl("lblActivity") as Label;
        myDTFI.ShortDatePattern = "dd-MM-yyyy";
        lblMoveDt.Text = Convert.ToDateTime(dr["MoveDt"]).ToString("d", myDTFI);

        if (Convert.ToString(dr["FileMoveType"]) == "I")
        {
          lblActivity.Text = "File Moved In " + dr["DeptNm"] + " by " + dr["UsrNm"];
        }
        else if (Convert.ToString(dr["FileMoveType"]) == "O")
        {
          lblActivity.Text = "File Moved Out For " + dr["DeptNm"] + ", " + dr["UsrNm"];
        }
      }
    }

    private void s_PopulateFileInfo()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMaster FileMasterData = new BusinessLayer.FileMaster();
        dt = FileMasterData.fn_GetFileMasterDetail(Convert.ToInt64(lblFileID.Text),0);
        if (dt != null && dt.Rows.Count > 0)
        {
          lblBranch.Text = dt.Rows[0]["BranchNm"].ToString();
          lblDeptNm.Text = dt.Rows[0]["DeptNm"].ToString();

          lblFileNo.Text = dt.Rows[0]["FileNum"].ToString();
          lblSubMatter.Text = dt.Rows[0]["SubMatter"].ToString();
          lblOpenedYr.Text = dt.Rows[0]["FileOpenYr"].ToString();
          lblInitialOfficer.Text = dt.Rows[0]["InitialOfficer"].ToString();
          lblPhoneNo.Text = dt.Rows[0]["PhoneNo"].ToString();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    //protected void dropType_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //  s_ChangeOnMove();
    //}

    protected void dropDept_SelectedIndexChanged(object sender, EventArgs e)
    {
      s_PopulatePersons();
    }

    private void s_PopulatePersons()
    {
      try
      {
        long DeptID;

        try
        {
          DeptID = Convert.ToInt64(dropDept.SelectedItem.Value);
        }
        catch (Exception ex)
        {
          DeptID = 0;
        }

        ddlFileMoveTo_UsrID.Items.Clear();
        DataTable dt;
        BusinessLayer.Users UsersList = new BusinessLayer.Users();
        dt = UsersList.fn_GetDeptwiseUsers(DeptID);
        if (dt != null)
        {
          ddlFileMoveTo_UsrID.DataSource = dt;
          ddlFileMoveTo_UsrID.DataBind();
        }

        ddlFileMoveTo_UsrID.Items.Insert(0, new ListItem("--Select Person--", "0"));

      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveData();
      s_BindData();
      s_InitializeData();
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
      Response.Redirect("/Webforms/FileMovements.aspx");
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);
    }

  }
