﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using TrackMyFile;
using System.Data.SqlClient;
using System.Globalization;

  public partial class BackUpDB : System.Web.UI.Page
  {
    protected mSession MSession = new mSession();
    string CONNStr = ConfigurationSettings.AppSettings["CONN"].ToString();
    string DBBKDrive = ConfigurationSettings.AppSettings["DBBKDrive"].ToString();
    SqlConnectionStringBuilder DBBuilder = new SqlConnectionStringBuilder(ConfigurationSettings.AppSettings["CONN"].ToString());
    //string csPath = "";

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckAdmSession();
      if (!IsPostBack)
      {
        //s_PopulateDrives();
      }
    }

    protected void btnBackup_Click(object sender, EventArgs e)
    {
      //csPath = DBBKDrive + ":/DB_BACKUP/";

      try
      {
        GenerateBackup(DBBuilder.InitialCatalog, DBBKDrive);
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
        lblMsg.Text = ex.Message;
      }
    }

    private void GenerateBackup(string DBName, string Location)
    {
      if (CONNStr.Length > 0)
      {
        System.Data.SqlClient.SqlConnection dbConn = null;
        try
        {
          string s = Convert.ToString(DateTime.Now.ToString(), CultureInfo.InvariantCulture);
          s = s.Replace("/", "-");
          s = s.Replace(":", ".");
          string Query = "BACKUP DATABASE " + DBName + "  TO DISK = '" + Location + DBBuilder.InitialCatalog + "_" + s + ".bak'";
          dbConn = new System.Data.SqlClient.SqlConnection(CONNStr);
          dbConn.Open();
          System.Data.SqlClient.SqlCommand dbCmd = new System.Data.SqlClient.SqlCommand(Query, dbConn);
          dbCmd.ExecuteNonQuery();
          lblMsg.Text = "Backup Completed Successfully";
        }
        catch (Exception ex)
        {
          ShowMessage(ex.Message);
          lblMsg.Text = ex.Message;
        }
        finally
        {
          dbConn.Close();
          dbConn.Dispose();
        }
      }
    }

    public void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);
    }

    //private void s_PopulateDrives()
    //{
    //  ddlDrives.Items.Clear();
    //  ddlDrives.Items.Add("-Select-");
    //  foreach (string objDrive in Directory.GetLogicalDrives())
    //  {
    //    ddlDrives.Items.Add(objDrive);
    //  }
    //}

  }

