﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;
using AjaxControlToolkit;

public partial class SearchFileByDept : System.Web.UI.Page
  {
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!Page.IsPostBack)
      {
        s_BindData();
      }
      tblHeader.Visible = false;
      btnCancel.Visible = false;
    }

   

   

    private void s_BindData()
    {
      try
      {
        Entity.FileMovement FileMovementEntity = new Entity.FileMovement();
        BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
        DataTable dt = new DataTable();

        dt = FileMovementLogic.GetFileInfoDeptWise(DeptID, Session["UsrCode"].ToString());
        if (dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindData();
    }

    private void s_BindDataMyGVM(long FileID)
    {
      try
      {
        DataTable dtM;
        BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
        dtM = FileMovementList.fn_GetFileMovementDetail(Convert.ToInt64(FileID));
        if (dtM != null)
        {
          MyGVM.DataSource = dtM;
          MyGVM.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    protected void MyGVM_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView drM = (DataRowView)e.Row.DataItem;
        Label lblMoveDt = e.Row.FindControl("lblMoveDt") as Label;
        Label lblActivity = e.Row.FindControl("lblActivity") as Label;
        myDTFI.ShortDatePattern = "dd-MM-yyyy";
        lblMoveDt.Text = Convert.ToDateTime(drM["MoveDt"]).ToString("d", myDTFI);

        if (Convert.ToString(drM["FileMoveType"]) == "I")
        {
          lblActivity.Text = "File Moved In From " + drM["DeptNm"];
        }
        else if (Convert.ToString(drM["FileMoveType"]) == "O")
        {
          lblActivity.Text = "File Moved Out To " + drM["DeptNm"];
        }
        //else if (Convert.ToString(drM["FileMoveType"]) == "U")
        //{
        //  lblActivity.Text = "File Moved Up To " + drM["DeptCode"];
        //}
        //else if (Convert.ToString(drM["FileMoveType"]) == "D")
        //{
        //  lblActivity.Text = "File Moved Down From " + drM["DeptCode"];
        //}
        //else if (Convert.ToString(drM["FileMoveType"]) == "B")
        //{
        //  lblActivity.Text = "File Moved Back To " + drM["DeptCode"];
        //}
        //else if (Convert.ToString(drM["FileMoveType"]) == "E")
        //{
        //    lblActivity.Text = "Disposed By " + drM["DeptCode"];
        //}
      }
    }

    protected void lnkView_Click(object sender, EventArgs e)
    {
      LinkButton btndetails = sender as LinkButton;
      GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
      s_BindDataMyGVM(Convert.ToInt64(MyGV.DataKeys[gvrow.RowIndex].Value.ToString()));
      btnCancel.Visible = true;
      tblHeader.Visible = true;
      this.ModalPopupExtender1.Show();
    }

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

  }
