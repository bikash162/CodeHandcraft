﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

public partial class AddEditBranchMaster : System.Web.UI.Page
{
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
        MSession.fn_CheckAdmSession();
        if (!Page.IsPostBack)
        {
            s_InitializeData();
            s_BindData();
        }
    }

    private void s_InitializeData()
    {
        lblBranchID.Text = "";
        txtBranchNm.Text = "";
        txtDescr.Text = "";
    }

    private void s_BindData()
    {
        try
        {
            DataTable dt;
            BusinessLayer.BranchMaster BranchMasterList = new BusinessLayer.BranchMaster();
            dt = BranchMasterList.fn_GetBranchMasterList(0);
            if (dt != null)
            {
                MyGV.DataSource = dt;
                MyGV.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }


    private void s_PopulateBranchInfo(Int64 BranchID)
    {
        try
        {
            DataTable dt;
            BusinessLayer.BranchMaster BranchMasterList = new BusinessLayer.BranchMaster();
            dt = BranchMasterList.fn_GetBranchMasterList(Convert.ToInt64(BranchID));
            if (dt != null && dt.Rows.Count > 0)
            {
                lblBranchID.Text = dt.Rows[0]["BranchID"].ToString();
                txtBranchNm.Text = dt.Rows[0]["BranchNm"].ToString();
                txtDescr.Text = dt.Rows[0]["BranchDesc"].ToString();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    private bool fn_ValidateData()
    {
        if (txtBranchNm.Text == "")
        {
            ShowMessage("Branch Name is Required");
            return false;
        }
        return true;
    }

    private void s_SaveBranchMaster()
    {
        try
        {
            if (fn_ValidateData() == false)
            {
                return;
            }

            Int64 BranchID;

            try
            {
                BranchID = Convert.ToInt64(lblBranchID.Text);
            }
            catch 
            {
                BranchID = 0;
            }
            BusinessLayer.BranchMaster BranchMasterLogic = new BusinessLayer.BranchMaster();
            Entity.BranchMaster BranchMasterEntity = new Entity.BranchMaster();
            BranchMasterEntity.BranchID = BranchID;
            BranchMasterEntity.BranchNm = txtBranchNm.Text + "";
            BranchMasterEntity.BranchDesc = txtDescr.Text + "";
            if (BranchID > 0)
            {
                BranchMasterLogic.UpdateBranchMaster(BranchMasterEntity);
            }
            else
            {
                BranchMasterLogic.SaveBranchMaster(BranchMasterEntity);
            }
            s_InitializeData();
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("btnEdit"))
        {
            Int64 BranchID = Convert.ToInt64(e.CommandArgument.ToString());
            s_PopulateBranchInfo(BranchID);
        }
        else if (e.CommandName.Equals("btnDelete"))
        {
            try
            {
                Int64 BranchID = Convert.ToInt64(e.CommandArgument.ToString());
                BusinessLayer.BranchMaster BranchMasterLogic = new BusinessLayer.BranchMaster();
                Entity.BranchMaster BranchMasterEntity = new Entity.BranchMaster();
                BranchMasterEntity.BranchID = BranchID;
                BranchMasterLogic.DeleteBranchMaster(BranchMasterEntity);
                s_BindData();
                s_InitializeData();
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MyGV.PageIndex = e.NewPageIndex;
        s_BindData();
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        s_InitializeData();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        s_SaveBranchMaster();
        s_BindData();
    }

    protected void ShowMessage(string message)
    {
        string script = "<script language='JavaScript'>alert('" + message + "')</script>";
        Page.RegisterStartupScript("PopUp", script);

    }


}

