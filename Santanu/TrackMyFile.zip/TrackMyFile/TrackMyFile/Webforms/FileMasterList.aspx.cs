﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

  public partial class FileMasterList : System.Web.UI.Page
  {
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
      MSession.fn_CheckSession();
      if (!Page.IsPostBack)
      {
        s_BindData();
        //s_BindInboxData();
        //s_BindDeptFilesData();
      }

    }

    private void s_BindData()
    {
      try
      {
        DataTable dt;
        BusinessLayer.FileMaster FileMasterList = new BusinessLayer.FileMaster();
        //dt = FileMasterList.fn_GetFileMasterDetail(0, Convert.ToInt64(Session["DeptID"]));
        dt = FileMasterList.fn_GetAccountFilesList(Convert.ToInt64(Session["DeptID"]), Convert.ToString(Session["UsrLoginNm"]));
        if (dt != null && dt.Rows.Count > 0)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
          divGrid.Visible = true;
        }
        else
        {
          divGrid.Visible = false;
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    //private void s_BindInboxData()
    //{
    //  try
    //  {
    //    DataTable dt;
    //    BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
    //    dt = FileMovementList.fn_GetAcceptableFileListToDept(Convert.ToInt64(Session["DeptID"]), Convert.ToInt64(Session["UsrID"]));
    //    if (dt != null && dt.Rows.Count > 0)
    //    {
    //      MyGVInbox.DataSource = dt;
    //      MyGVInbox.DataBind();
    //      divInBox.Visible = true;
    //    }
    //    else
    //    {
    //      divInBox.Visible = false;
    //    }
    //  }
    //  catch (Exception ex)
    //  {
    //    ShowMessage(ex.Message);
    //  }
    //}

    //private void s_BindDeptFilesData()
    //{
    //  try
    //  {
    //    DataTable dt;
    //    BusinessLayer.FileMovement FileMovementList = new BusinessLayer.FileMovement();
    //    dt = FileMovementList.fn_GetFilesListDeptWise(Convert.ToInt64(Session["DeptID"]), Convert.ToInt64(Session["UsrID"]));
    //    if (dt != null && dt.Rows.Count > 0)
    //    {
    //      MyGVDeptFiles.DataSource = dt;
    //      MyGVDeptFiles.DataBind();
    //      divAcceptedFileList.Visible = true;
    //    }
    //    else
    //    {
    //      divAcceptedFileList.Visible = false;
    //    }
    //  }
    //  catch (Exception ex)
    //  {
    //    ShowMessage(ex.Message);
    //  }
    //}

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
      MyGV.PageIndex = e.NewPageIndex;
      s_BindData();
    }

    //protected void MyGVInbox_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //  MyGVInbox.PageIndex = e.NewPageIndex;
    //  s_BindInboxData();
    //}

    //protected void MyGVDeptFiles_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //  MyGVDeptFiles.PageIndex = e.NewPageIndex;
    //  s_BindDeptFilesData();
    //}

    protected void MyGV_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      if (e.Row.RowType == DataControlRowType.DataRow)
      {
        DataRowView dr = (DataRowView)e.Row.DataItem;
        HyperLink lnkEdit = e.Row.FindControl("lnkEdit") as HyperLink;
        lnkEdit.NavigateUrl = "~/Webforms/AddEditFileMaster.aspx?&AddEdit=Edit&FileID=" + Convert.ToInt64(dr["FileID"]) + "";

        //HyperLink lnkManageMovement = e.Row.FindControl("lnkManageMovement") as HyperLink;
        //lnkManageMovement.NavigateUrl = "~/Webforms/ManageFileMovements.aspx?&FileID=" + Convert.ToInt64(dr["FileID"]) + "";

        //Label lblStatus = e.Row.FindControl("lblStatus") as Label;
        //if (Convert.ToString(dr["FileStatus"]) == "I")
        //{
        //  lblStatus.Text = "Moved In";
        //}
        //else if (Convert.ToString(dr["FileStatus"]) == "O")
        //{
        //    lblStatus.Text = "Moved Out";
        //}

        //else
        //{
        //  lblStatus.Text = "Not Moved";
        //}
      }
    }

    //protected void MyGVInbox_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //  if (e.Row.RowType == DataControlRowType.DataRow)
    //  {
    //    DataRowView dr = (DataRowView)e.Row.DataItem;
    //    Label lblFileNum = e.Row.FindControl("lblFileNum") as Label;
    //    if (Convert.ToString(dr["IsFileViewed"]) == "N")
    //    {
    //      lblFileNum.Text = "<b>" + Convert.ToString(dr["FileNum"]) + "</b>";
    //    }
    //    else
    //    {
    //      lblFileNum.Text = Convert.ToString(dr["FileNum"]);
    //    }
    //  }
    //}

    //protected void MyGVDeptFiles_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //  if (e.Row.RowType == DataControlRowType.DataRow)
    //  {
    //    DataRowView dr = (DataRowView)e.Row.DataItem;

    //    //HyperLink lnkManageMovement = e.Row.FindControl("lnkManageMovement") as HyperLink;
    //    //lnkManageMovement.NavigateUrl = "~/Webforms/ManageFileMovements.aspx?&FileID=" + Convert.ToInt64(dr["FileID"]) + "";

    //    Label lblMoveType = e.Row.FindControl("lblMoveType") as Label;
    //    if (Convert.ToString(dr["FileMoveType"]) == "I")
    //    {
    //      lblMoveType.Text = "Moved In";
    //    }
    //    else if (Convert.ToString(dr["FileMoveType"]) == "O")
    //    {
    //      lblMoveType.Text = "Moved Out";
    //    }
    //    else
    //    {
    //      lblMoveType.Text = "Not Moved";
    //    }
    //  }
    //}

    //protected void MyGVInbox_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //  if (e.CommandName.Equals("ViewDetail"))
    //  {
    //    try
    //    {
    //      Int64 FileMovementID = Convert.ToInt64(e.CommandArgument.ToString());
    //      BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
    //      Entity.FileMovement FileMovementEntity = new Entity.FileMovement();
    //      FileMovementEntity.FileMovementID = FileMovementID;
    //      FileMovementEntity.FileViewedBy = Convert.ToString(Session["UsrLoginNm"]);
    //      FileMovementLogic.UpdFileMovementFileViewedInfo(FileMovementEntity);
    //      s_BindInboxData();
    //    }
    //    catch (Exception ex)
    //    { 

    //    }
    //  }
    //  else if (e.CommandName.Equals("Accept"))
    //  {
    //    try
    //    {
    //      Int64 FileID = Convert.ToInt64(e.CommandArgument.ToString());
    //      BusinessLayer.FileMovement FileMovementLogic = new BusinessLayer.FileMovement();
    //      Entity.FileMovement FileMovementEntity = new Entity.FileMovement();

    //      FileMovementEntity.FileID = FileID;
    //      FileMovementEntity.FileMoveType = "I";
    //      FileMovementEntity.DeptID = Convert.ToInt64(Session["DeptID"]);
    //      FileMovementEntity.MoveDt = Convert.ToDateTime(DateTime.Now.ToShortDateString());
    //      FileMovementEntity.Remarks = "";
    //      FileMovementEntity.CreatedBy = Convert.ToString(Session["UsrLoginNm"]);
    //      FileMovementEntity.FileMoveTo_UsrID = Convert.ToInt64(Session["UsrID"]);
    //      FileMovementLogic.SaveFileMovement(FileMovementEntity);
    //      s_BindDeptFilesData();
    //      s_BindInboxData();
    //    }
    //    catch (Exception ex)
    //    { 

    //    }
    //  }
    //}

    //protected void btnViewDetail_Click(object sender, ImageClickEventArgs e)
    //{
    //  ImageButton btndetails = sender as ImageButton;
    //  GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
    //  s_PopulateFileInfo(Convert.ToInt64(MyGVInbox.DataKeys[gvrow.RowIndex].Value.ToString()));
    //  btnCancel.Visible = true;
    //  tblHeader.Visible = true;
    //  this.ModalPopupExtender1.Show();
    //}

    //protected void btnViewFile_Click(object sender, ImageClickEventArgs e)
    //{
    //  ImageButton btndetails = sender as ImageButton;
    //  GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
    //  s_PopulateFileInfo(Convert.ToInt64(MyGVDeptFiles.DataKeys[gvrow.RowIndex].Value.ToString()));
    //  btnCancel.Visible = true;
    //  tblHeader.Visible = true;
    //  this.ModalPopupExtender1.Show();
    //}

    //private void s_PopulateFileInfo(long FileID)
    //{
    //  try
    //  {
    //    DataTable dt;
    //    BusinessLayer.FileMaster FileMasterData = new BusinessLayer.FileMaster();
    //    dt = FileMasterData.fn_GetFileMasterDetail(Convert.ToInt64(FileID), 0);
    //    if (dt != null && dt.Rows.Count > 0)
    //    {
    //      lblBranch.Text = dt.Rows[0]["BranchNm"].ToString();
    //      lblDeptNm.Text = dt.Rows[0]["DeptNm"].ToString();

    //      lblFileNo.Text = dt.Rows[0]["FileNum"].ToString();
    //      lblSubMatter.Text = dt.Rows[0]["SubMatter"].ToString();
    //      lblOpenedYr.Text = dt.Rows[0]["FileOpenYr"].ToString();
    //      lblInitialOfficer.Text = dt.Rows[0]["InitialOfficer"].ToString();
    //      lblPhoneNo.Text = dt.Rows[0]["PhoneNo"].ToString();
    //    }
    //  }
    //  catch (Exception ex)
    //  {
    //    ShowMessage(ex.Message);
    //  }
    //}

    protected void ShowMessage(string message)
    {
      string script = "<script language='JavaScript'>alert('" + message + "')</script>";
      Page.RegisterStartupScript("PopUp", script);

    }

    protected void btnAddFile_Click(object sender, EventArgs e)
    {
      Response.Redirect("~/Webforms/AddEditFileMaster.aspx?&AddEdit=" + mEnum.eAddEdit.Add.ToString());
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      s_BindSearchedData();
    }

    private void s_BindSearchedData()
    {
      try
      {
        long DeptID = 0;
        try
        {
          DeptID = Convert.ToInt32(Session["DeptID"].ToString());
        }
        catch
        {
          DeptID = 0;
        }


        string csFileNo = "";
        if (txtFileNo.Text != "")
        {
          csFileNo = "%" + txtFileNo.Text.Trim() + "%";
        }

        DataTable dt;
        BusinessLayer.FileMaster FileMasterList = new BusinessLayer.FileMaster();
        dt = FileMasterList.fn_SearchFileList("", csFileNo + "", DeptID, Convert.ToChar("Y"));
        if (dt != null)
        {
          MyGV.DataSource = dt;
          MyGV.DataBind();
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    
  }
