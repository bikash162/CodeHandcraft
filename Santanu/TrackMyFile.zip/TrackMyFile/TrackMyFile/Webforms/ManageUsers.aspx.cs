﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

public partial class ManageUsers : System.Web.UI.Page
{
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
        MSession.fn_CheckAdmSession();
        if (!Page.IsPostBack)
        {
            s_InitializeData();
            s_PopulateDept();
            s_BindData();
        }
    }

    private void s_InitializeData()
    {
        lblUsrID.Text = "";
        txtUsrNm.Text = "";
        txtUsrLoginNm.Text = "";
        txtUsrPwd1.Text = "";
        txtUsrPwd2.Text = "";
    }

    private void s_BindData()
    {
        try
        {
            DataTable dt;
            BusinessLayer.Users UsersList = new BusinessLayer.Users();
            dt = UsersList.fn_GetAllUsers();
            if (dt != null)
            {
                MyGV.DataSource = dt;
                MyGV.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }


    private void s_PopulateDept()
    {
      try
      {
        DataTable dt;
        BusinessLayer.DeptMaster DeptMasterList = new BusinessLayer.DeptMaster();
        dt = DeptMasterList.fn_GetDeptMasterList(0);
        if (dt != null)
        {
          ddlDept.DataSource = dt;
          ddlDept.DataBind();

          ListItem list = new ListItem("-- Select Department --", "");
          ddlDept.Items.Insert(0, list);
        }
      }
      catch (Exception ex)
      {
        ShowMessage(ex.Message);
      }
    }

    private bool fn_ValidateData()
    {
        if (ddlDept.SelectedItem.Value == "0")
        {
          ShowMessage("Department is Required");
          return false;
        }
        if (txtUsrNm.Text == "")
        {
            ShowMessage("User Name is Required");
            return false;
        }
        if (txtUsrLoginNm.Text == "")
        {
          ShowMessage("User Login Name is Required");
          return false;
        }
        if (txtUsrPwd1.Text == "")
        {
          ShowMessage("User Password is Required");
          return false;
        }
        if (txtUsrPwd2.Text == "")
        {
          ShowMessage("User Re-type Password is Required");
          return false;
        }
        if (txtUsrPwd1.Text != txtUsrPwd2.Text)
        {
          ShowMessage("User Password and Re-type Password not matched.");
          return false;
        }

        return true;
    }

    private void s_SaveUsers()
    {
        try
        {
            if (fn_ValidateData() == false)
            {
                return;
            }

            Int64 UsrID;

            try
            {
              UsrID = Convert.ToInt64(lblUsrID.Text);
            }
            catch 
            {
              UsrID = 0;
            }
            BusinessLayer.Users UsersLogic = new BusinessLayer.Users();
            Entity.Users UsersEntity = new Entity.Users();
            UsersEntity.DeptID = Convert.ToInt64(ddlDept.SelectedItem.Value);
            UsersEntity.UsrNm = txtUsrNm.Text + "";
            UsersEntity.UsrLoginNm = txtUsrLoginNm.Text + "";
            UsersEntity.UsrPwd = txtUsrPwd1.Text + "";
            if (UsrID > 0)
            {
              UsersEntity.UsrID = UsrID;
              //UsersLogic.UpdateBranchMaster(BranchMasterEntity);
            }
            else
            {
                UsersLogic.SaveUsers(UsersEntity);
            }
            s_InitializeData();
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    protected void MyGV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //if (e.CommandName.Equals("btnEdit"))
        //{
        //    Int64 UsrID = Convert.ToInt64(e.CommandArgument.ToString());
        //    s_PopulateBranchInfo(BranchID);
        //}
        
    }

    protected void MyGV_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MyGV.PageIndex = e.NewPageIndex;
        s_BindData();
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        s_InitializeData();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        s_SaveUsers();
        s_BindData();
    }

    protected void ShowMessage(string message)
    {
        string script = "<script language='JavaScript'>alert('" + message + "')</script>";
        Page.RegisterStartupScript("PopUp", script);

    }


}

