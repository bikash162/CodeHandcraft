﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TrackMyFile;
using System.Globalization;

public partial class ManageFileNumPrefixSetup : System.Web.UI.Page
{
    DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;
    DataAccess.mAdmHelper mAdmHlp = new DataAccess.mAdmHelper();
    protected mSession MSession = new mSession();

    protected void Page_Load(object sender, EventArgs e)
    {
        MSession.fn_CheckSession();
        if (!Page.IsPostBack)
        {
          lblBranchID.Text = Session["BranchID"].ToString();
          s_InitializeData();
          s_PopulateData();
        }
    }

    private void s_InitializeData()
    {
      txtFileNumPrefix.Text = "";
    }

    private void s_PopulateData()
    {
        try
        {
            DataTable dt;
            BusinessLayer.FileNumPrefixSetup FileNumPrefixSetupList = new BusinessLayer.FileNumPrefixSetup();
            dt = FileNumPrefixSetupList.fn_GetFileNumPrefixData(Convert.ToInt64(lblBranchID.Text));
            if (dt != null && dt.Rows.Count > 0)
            {
              txtFileNumPrefix.Text = dt.Rows[0]["FileNumPrefix"].ToString();
            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    private bool fn_ValidateData()
    {
        if (txtFileNumPrefix.Text == "")
        {
            ShowMessage("File Number Prefix is Required");
            return false;
        }
        return true;
    }

    private void s_SaveFileNumPrefix()
    {
        try
        {
            if (fn_ValidateData() == false)
            {
                return;
            }

            BusinessLayer.FileNumPrefixSetup FileNumPrefixSetupLogic = new BusinessLayer.FileNumPrefixSetup();
            Entity.FileNumPrefixSetup FileNumPrefixSetupEntity = new Entity.FileNumPrefixSetup();
            FileNumPrefixSetupEntity.BranchID =Convert.ToInt64(lblBranchID.Text);
            FileNumPrefixSetupEntity.FileNumPrefix = txtFileNumPrefix.Text + "";
            FileNumPrefixSetupEntity.CreatedBy = Session["UsrLoginNm"].ToString() + "";
            FileNumPrefixSetupLogic.SaveFileNumPrefixSetup(FileNumPrefixSetupEntity);
            s_InitializeData();
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
      s_SaveFileNumPrefix();
      s_PopulateData();
    }

    protected void ShowMessage(string message)
    {
        string script = "<script language='JavaScript'>alert('" + message + "')</script>";
        Page.RegisterStartupScript("PopUp", script);
    }
}

