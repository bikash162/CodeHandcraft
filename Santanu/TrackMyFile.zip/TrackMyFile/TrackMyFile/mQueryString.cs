﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace TrackMyFile
{
    public class mQueryString
    {
        public mQueryString()
        { 

        }

        public string qs_AddEdit
        {
            get
            {
                return (System.Web.HttpContext.Current.Request.QueryString["AddEdit"]);
            }
        }


        public string qs_FIN_YR_CD
        { 
            get
            {
                return (System.Web.HttpContext.Current.Request.QueryString["FIN_YR_CD"]);
            }
        }

        public string qs_SCHM_CD
        {
            get
            {
                return (System.Web.HttpContext.Current.Request.QueryString["SCHM_CD"]);
            }
        }

        public string qs_DDO_CD
        {
            get
            {
                return (System.Web.HttpContext.Current.Request.QueryString["DDO_CD"]);
            }
        }

        public string qs_FileID
        {
          get
          {
            return (System.Web.HttpContext.Current.Request.QueryString["FileID"]);
          }
        }


        public string qs_SignOut
        {
            get
            {
                return (System.Web.HttpContext.Current.Request.QueryString["SignOut"]);
            }
        }

    }
}
