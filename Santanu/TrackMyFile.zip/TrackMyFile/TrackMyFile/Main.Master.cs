﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Globalization;


    public partial class Main : System.Web.UI.MasterPage
    {
        protected mSession MSession = new mSession();
        DateTimeFormatInfo myDTFI = new CultureInfo("en-US", false).DateTimeFormat;

        public string pBackUrl
        {
            set
            {
                lblBackUrl.Text = value;
                if (lblBackUrl.Text != "")
                {
                    lnkBack.NavigateUrl = lblBackUrl.Text;
                    divBack.Visible = true;
                }
                else
                {
                    divBack.Visible = false;
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            MSession.fn_CheckSession();


            if (!IsPostBack)
            {
                if (Session["UsrLoginNm"] != null)
                {
                  ctrUsrInfo.pUsrNm = Session["UsrNm"].ToString();
                  ctrUsrInfo.pUsrLoginNm = Session["UsrLoginNm"].ToString();
                  ctrUsrInfo.pBranch = Session["BranchNm"].ToString();
                  ctrUsrInfo.pDept = Session["DeptNm"].ToString();
                  //s_GetUserDetail();
                }
            }
        }


        //private void CheckSessionTimeout()
        //{
        //    string msgSession = "Warning: Within next 3 minutes, if you do not do anything, " +
        //        " our system will redirect to the login page. Please save changed data.";

        //    //time to remind, 3 minutes before session ends
        //    int int_MilliSecondsTimeReminder = (this.Session.Timeout * 200000);

        //    //time to redirect, 5 milliseconds before session ends
        //    int int_MilliSecondsTimeOut = (this.Session.Timeout * 200000) - 5;

        //    string str_Script = @" var myTimeReminder, myTimeOut; " +
        //        " clearTimeout(myTimeReminder); " +
        //        " clearTimeout(myTimeOut); " +
        //        "var sessionTimeReminder = " + int_MilliSecondsTimeReminder.ToString() + "; " +
        //        "var sessionTimeout = " + int_MilliSecondsTimeOut.ToString() + ";" +
        //        "function doReminder(){ alert('" + msgSession + "'); }" +
        //        "function doRedirect(){ window.location.href='../Login.aspx'; }" +
        //        " myTimeReminder=setTimeout('doReminder()', sessionTimeReminder); myTimeOut=setTimeout('doRedirect()',sessionTimeout); ";

        //    ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "CheckSessionOut", str_Script, true);
        //}                        
    }
