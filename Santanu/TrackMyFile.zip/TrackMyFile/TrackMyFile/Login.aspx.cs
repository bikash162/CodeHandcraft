﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using TrackMyFile;


    public partial class Login : System.Web.UI.Page
    {
      protected UserInfo ui = new TrackMyFile.UserInfo();
      protected SysInfo si = new TrackMyFile.SysInfo();
        protected mSession MSession = new mSession();
        protected mQueryString mQueryString = new mQueryString();

        
        protected void Page_Load(object sender, EventArgs e)
        {
          if (!Page.IsPostBack)
          {
            MSession.s_ClearSessionValue();
            System.Web.Security.FormsAuthentication.SetAuthCookie("", true);
          }
        }

  

        protected void btnLogin_Click(object sender, EventArgs e)
        {
          if (txtUserID.Text == "")
          {
            ShowMessage("User Login can not be left blank");
            return;
          }
          if (txtUserPwd.Text == "")
          {
            ShowMessage("User Password can not be left blank");
            return;
          }

          try
            {
              DataTable dt;
              BusinessLayer.Users UsersData = new BusinessLayer.Users();
              dt = UsersData.fn_GetUsrDetail(txtUserID.Text + "",txtUserPwd.Text + "");
              if (dt != null && dt.Rows.Count > 0)
              {
                Session["UsrID"] = dt.Rows[0]["UsrID"].ToString();
                Session["UsrNm"] = dt.Rows[0]["UsrNm"].ToString();
                Session["UsrLoginNm"] = dt.Rows[0]["UsrLoginNm"].ToString();
                Session["UsrType"] = dt.Rows[0]["UsrType"].ToString();
                Session["DeptID"] = dt.Rows[0]["DeptID"].ToString();
                Session["DeptNm"] = dt.Rows[0]["DeptNm"].ToString();
                Session["BranchID"] = dt.Rows[0]["BranchID"].ToString();
                Session["BranchNm"] = dt.Rows[0]["BranchNm"].ToString();
                Response.Redirect("Home.aspx", false);
              }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
                divMsg.Visible = true;
            }
        }



        public void ShowMessage(string message)
        {
            string script = "<script language='JavaScript'>alert('" + message + "')</script>";
            Page.RegisterStartupScript("PopUp", script);

        }


    }
