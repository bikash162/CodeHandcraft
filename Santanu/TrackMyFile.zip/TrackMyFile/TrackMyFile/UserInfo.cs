﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TrackMyFile
{
    public class UserInfo
    {
        SqlConnection SqlCnn = new SqlConnection(ConfigurationSettings.AppSettings["CONN"]);
        string StrSql = "";
        protected static string UsrId;
        protected static string UsrPwd;
        protected static string UsrGrp;
        protected static string AdminFlg;
        protected SysInfo si = new SysInfo();
        int SessionID;
        SqlDataAdapter SqlAdpt;
        DataSet DataSt;

        public UserInfo()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public void setUserInfo(string UserId, string UserPwd, string UserGrp, string AdmStat)
        {
            UsrId = UserId;
            UsrPwd = UserPwd;
            UsrGrp = UserGrp;
            AdminFlg = AdmStat;
            UpdateInfo();
        }

        public string getUserId()
        {
            return UsrId;
        }
        public string getUserGrp()
        {
            return UsrGrp;
        }
        public string getAdminStatus()
        {
            return AdminFlg;
        }

        private void UpdateInfo()
        {

            StrSql = "Select max(SESSION_ID) As SESSION_ID From BGT_USER_LOGIN_HDR " +
                     "Where DEPT_CD = 'HF' " +
                     "And CURR_DT = '" + si.getDate() + "' " +
                     "And USER_CD = '" + getUserId() + "' ";

            SqlAdpt = new SqlDataAdapter(StrSql, SqlCnn);
            DataSt = new DataSet();
            SqlAdpt.Fill(DataSt);
            SessionID = 0;
            if (DataSt.Tables[0].DefaultView.Count > 0)
            {
                if (DataSt.Tables[0].DefaultView[0]["SESSION_ID"].ToString() != "")
                {
                    SessionID = Convert.ToInt32(DataSt.Tables[0].DefaultView[0]["SESSION_ID"].ToString());
                }
            }
            SessionID = SessionID + 1;
            StrSql = "Insert into BGT_USER_LOGIN_HDR(DEPT_CD,CURR_DT,USER_CD,SESSION_ID,LOGIN_TM,LOGOUT_TM) Values " +
                     "('HF','" + si.getDate() + "','" + getUserId() + "'," + SessionID + ", CONVERT(TIME,GETDATE(),108), null )";
            SqlCnn.Open();
            SqlCommand SqlCmd = new SqlCommand(StrSql, SqlCnn);
            SqlCmd.ExecuteNonQuery();
            SqlCnn.Close();
           
            HttpContext.Current.Session["SESSION_ID"] = SessionID;

        }

    }
}
