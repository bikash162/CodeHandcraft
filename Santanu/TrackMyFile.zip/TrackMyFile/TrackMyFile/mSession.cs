﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;
using System.Xml.Linq;

public class mSession
{
  //protected UserInfo ui = new UserInfo();

  public mSession()
  {
    //
    // TODO: Add constructor logic here
    //
  }

  public bool fn_CheckSplFileEntrySession()
  {
    bool CheckSplFileEntrySession = false;
    string cExtPgVar = "&SESSIONEXPIRE=YES";
    string UsrLoginNm = Convert.ToString(HttpContext.Current.Session["UsrLoginNm"]);
    if (UsrLoginNm != "GENERAL_FILE")
    {
      HttpContext.Current.Response.Redirect("/Login.aspx?" + cExtPgVar);
      CheckSplFileEntrySession = false;
    }
    else
    {
      CheckSplFileEntrySession = true;
    }
    return CheckSplFileEntrySession;
  }

  public bool fn_CheckSession()
  {
    bool Check_Session = false;
    string cExtPgVar = "&SESSIONEXPIRE=YES";
    if (HttpContext.Current.Session["UsrLoginNm"] == null || HttpContext.Current.Session["UsrLoginNm"] == "")
    {
      HttpContext.Current.Response.Redirect("/Login.aspx?" + cExtPgVar);
      Check_Session = false;
    }
    else
    {
      Check_Session = true;
    }

    return Check_Session;
  }

  public bool fn_CheckAdmSession()
  {
    bool CheckAdmSession = false;
    string cExtPgVar = "&SESSIONEXPIRE=YES";
    string UsrLoginNm = Convert.ToString(HttpContext.Current.Session["UsrLoginNm"]);
    if (UsrLoginNm != "ADMIN")
    {
      HttpContext.Current.Response.Redirect("/Login.aspx?" + cExtPgVar);
      CheckAdmSession = false;
    }
    else
    {
      CheckAdmSession = true;
    }
    return CheckAdmSession;
  }

  public string fn_GetUsrLoginNm
  {
    get
    {
      return Convert.ToString(HttpContext.Current.Session["UsrLoginNm"]);
    }
  }

  public void s_ClearSessionValue()
  {
    HttpContext.Current.Session["UsrID"] = "";
    HttpContext.Current.Session["UsrLoginNm"] = "";
    HttpContext.Current.Session["UsrNm"] = "";
    HttpContext.Current.Session["UsrType"] = "";
    HttpContext.Current.Session["DeptID"] = "";
    HttpContext.Current.Session["DeptNm"] = "";
    HttpContext.Current.Session["BranchID"] = "";
    HttpContext.Current.Session["BranchNm"] = "";
  }
}

