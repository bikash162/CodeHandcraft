﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TrackMyFile;

public partial class ctrUsrInfo : System.Web.UI.UserControl
  {

  public string pUsrNm
  {
    set
    {
      if (value != "")
      {
        lblUsrNm.Text = "Welcome " + value;
      }
    }
  }

  public string pBranch
  {
    set
    {
      if (value != "")
      {
        lblBranch.Text = "Branch: " + value;
      }
    }
  }

  public string pUsrLoginNm
  {
    set
    {
      if (value != "")
      {
        lblUsrLoginNm.Text = "Login: " + value;
      }
    }
  }

  public string pDept
  {
    set
    {
      if (value != "")
      {
        lblDept.Text ="Dept.: " + value;
      }
    }
  }

  protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
