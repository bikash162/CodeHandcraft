﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public  class FileMovement
  {
   
   public FileMovement()
   {

   }

   public long FileID { get; set; }
   public long FileMovementID { get; set; }
   public string FileMoveType { get; set; }
   public long DeptID { get; set; }
   public DateTime? MoveDt { get; set; }
   public string Remarks { get; set; }
   public DateTime? CreatedDt { get; set; }
   public string CreatedBy { get; set; }
   public DateTime? LastModDt { get; set; }
   public string LastModBy { get; set; }

   public char IsFileViewed { get; set; }
   public DateTime? FileViewedDt { get; set; }
   public string FileViewedBy { get; set; }
   public long FileMoveTo_UsrID { get; set; }

  }
}
