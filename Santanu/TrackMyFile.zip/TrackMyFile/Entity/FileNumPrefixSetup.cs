﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public  class FileNumPrefixSetup
  {

   public FileNumPrefixSetup()
   {

   }

   public long BranchID { get; set; }
   public string FileNumPrefix { get; set; }
   public string CreatedBy { get; set; }
   public DateTime? CreatedDt { get; set; }
   public string LastModBy { get; set; }
   public DateTime? LastModDt { get; set; }

  }
}
