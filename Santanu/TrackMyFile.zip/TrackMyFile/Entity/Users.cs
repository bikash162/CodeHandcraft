﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public class Users
  {

   public Users()
   { 
   
   }

   public string UsrCode { get; set; }
   public long BranchID { get; set; }

   public string UsrPwd { get; set; }
   public string UsrType { get; set; }
   public string UsrLoginNm { get; set; }
   public long DeptID { get; set; }
   public long UsrID { get; set; }
   public string UsrNm { get; set; }

   public string UsrNewPwd { get; set; }

  }
}
