﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public class FileMaster
  {
   public FileMaster()
   { 
   
   }

   public long FileID { get; set; }
   public long DeptID { get; set; }
   public string FileNum { get; set; }
   public string SubMatter { get; set; }
   public string FileOpenYr { get; set; }
   public string InitialOfficer { get; set; }
   public string PhoneNo { get; set; }
   public string GenFileNo { get; set; }
   public string FileStatus { get; set; }
   public char FileFollowUp { get; set; }
   public string Remarks { get; set; }
   public DateTime? CreatedDt { get; set; }
   public string CreatedBy { get; set; }
   public DateTime? LastModDt { get; set; }
   public string LastModBy { get; set; }

   public long UsrID { get; set; }

   public string LastFollowupBy { get; set; }
   public DateTime LastFollowupDt { get; set; }

  }
}
