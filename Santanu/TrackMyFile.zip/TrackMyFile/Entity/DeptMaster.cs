﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public class DeptMaster
  {

  public DeptMaster()
   { 

   }

   public long DeptID { get; set; }
   public string DeptNm { get; set; }
   public string DeptDesc { get; set; }
   public long BranchID { get; set; }

  }
}
