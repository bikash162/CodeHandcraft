﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class AutoNumnerGeneration
    {
        public AutoNumnerGeneration()
        {

        }
        private int _FinancialId;
        private string _FinancialNm;
        private int _StateLevelId;
        private string _AutoNo;
        private int _MaxId;
        private string _Systemdt;
        private string _PagePermission;

        public int FinancialId
        {
            get { return _FinancialId; }
            set { _FinancialId = value; }
        }
        public int MaxId
        {
            get { return _MaxId; }
            set { _MaxId = value; }
        }
        public string FinancialNm
        {
            get { return _FinancialNm; }
            set { _FinancialNm = value; }
        }
        public string AutoNo
        {
            get { return _AutoNo; }
            set { _AutoNo = value; }
        }
        public int StateLevelId
        {
            get { return _StateLevelId; }
            set { _StateLevelId = value; }
        }
        public string Systemdt
        {
            get { return _Systemdt; }
            set { _Systemdt = value; }
        }
        public string PagePermission
        {
            get { return _PagePermission; }
            set { _PagePermission = value; }
        }
    }
    
}
