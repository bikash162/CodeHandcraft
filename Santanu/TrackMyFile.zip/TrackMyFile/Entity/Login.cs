﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class Login
    {
        public Login()
		{

		}
        private string _USER_CD;
        private string _USER_NM;
        private string _USER_PWD;
        private string _USER_GRP;
        private string _ADMIN_FLG;
        private string _DDO_CD;

        private string _DEPT_CD;
        private DateTime _CURR_DT;
        private Int32 _SESSION_ID;
        private string _LOGIN_TM;
        private string _LOGOUT_TM;


        public string USER_CD
        {
            get { return _USER_CD; }
            set { _USER_CD = value; }
        }

        public string USER_NM
        {
            get { return _USER_NM; }
            set { _USER_NM = value; }
        }

        public string USER_PWD
        {
            get { return _USER_PWD; }
            set { _USER_PWD = value; }
        }
        public string USER_GRP
        {
            get { return _USER_GRP; }
            set { _USER_GRP = value; }
        }
        public string ADMIN_FLG
        {
            get { return _ADMIN_FLG; }
            set { _ADMIN_FLG = value; }
        }

        public string DDO_CD
        {
            get { return _DDO_CD; }
            set { _DDO_CD = value; }
        }

        public string DEPT_CD
        {
          get { return _DEPT_CD; }
          set { _DEPT_CD = value; }
        }

        public DateTime CURR_DT
        {
          get { return _CURR_DT; }
          set { _CURR_DT = value; }
        }

        public Int32 SESSION_ID
        {
          get { return _SESSION_ID; }
          set { _SESSION_ID = value; }
        }

        public string LOGIN_TM
        {
          get { return _LOGIN_TM; }
          set { _LOGIN_TM = value; }
        }

        public string LOGOUT_TM
        {
          get { return _LOGOUT_TM; }
          set { _LOGOUT_TM = value; }
        }



    }
}
