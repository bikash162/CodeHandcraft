﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
 public class BranchMaster
  {

   public BranchMaster()
   { 

   }

   public long BranchID { get; set; }
   public string BranchNm { get; set; }
   public string BranchDesc { get; set; }

  }
}
