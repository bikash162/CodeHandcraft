﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Entity
{
  public class FileMoveOfficials
  {
    public FileMoveOfficials()
    { 

    }

    public long UsrMappID { get; set; }
    public long UsrID { get; set; }
    public long CreatedByID { get; set; }

  }
}
