﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Utitlity;
using ServiceLayer.Entity.Master;
using ServiceLayer.ViewModel.Master;
using ServiceLayer.Repository.Master;

namespace ImpactAdminPanel.Areas.Master.Controllers
{
    public class MenuController : BaseController
    {
        MenuRepository oMenuRepository;
        public MenuController()
        {
            oMenuRepository = new MenuRepository();
        }


        //
        // GET: /Master/Menu/

        public ActionResult Index()
        {
            var result = oMenuRepository.GetMenuList();

            return View(result);
        }

        public ActionResult BindParentMenu(int ModuleId, string Menus)
        {
            var ParentMenu = oMenuRepository.GetParentMenu(ModuleId).ToList();
            return Json(ParentMenu, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindModule()
        {
            var Module = oMenuRepository.GetModule();
            return Json(Module, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult AddEditMenu(Menu oMenu)
        {
            oMenu.CreatedBy = CurrentUser.UserID.ToString().Trim();
            var result = oMenuRepository.AddEditMenu(oMenu);
            //var result = 0;
            //return PartialView("_MenuList", oMenuRepository.GetMenuList());
            if (result.ReturnValue == 0)
            {
                return new HttpStatusCodeResult(911, result.ReturnMessage);
            }
            else
            {
                return PartialView("_MenuList", oMenuRepository.GetMenuList());
            }
        }

        [HttpPost]
        public JsonResult GetMenuInfo(int MenuID)
        {
            var result = oMenuRepository.GetMenuInfo(MenuID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Dispose all object of MenuRepository
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            oMenuRepository.Dispose();
            base.Dispose(disposing);
        }

    }
}
