﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Repository.Master;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;
using ImpactAdminPanel.Areas.Master.Models;
using Newtonsoft.Json;

namespace ImpactAdminPanel.Areas.Master.Controllers
{
    public class FileUploadSettingsController : BaseController
    {
      FileUploadSettingsRepository oFileUploadSettingsRepository;

        public FileUploadSettingsController()
        {
          oFileUploadSettingsRepository = new FileUploadSettingsRepository();
        }


        public ActionResult Index()
        {
          return View(oFileUploadSettingsRepository.GetFileUploadSettingsList());
        }

        public JsonResult ActivateFileUploadSettings(string Id, bool status)
        {
          return Json(oFileUploadSettingsRepository.ActivateFileUploadSettings(Id, status), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetFileUploadSettingsList()
        {
          return PartialView("~/Areas/Master/Views/Shared/_FileUploadSettingsList.cshtml", oFileUploadSettingsRepository.GetFileUploadSettingsList());
        }

        public ActionResult GetFileUploadSettingsById(int Id)
        {
            var result = oFileUploadSettingsRepository.GetFileUploadSettingsById(Id);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AddEdit(FormCollection formCollection)
        {
            var result = FileUploadSettingsValidation.AddEditFileUploadSettings(formCollection, oFileUploadSettingsRepository,CurrentUser.UserID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        


        /// <summary>
        /// Dispose all the oFileUploadSettingsRepository object
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
          oFileUploadSettingsRepository.Dispose();
          base.Dispose(disposing);
        }


    }
}
