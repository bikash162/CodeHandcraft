﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Repository.Master;
using ServiceLayer.Entity.Master;
using ImpactAdminPanel.Areas.Master.Models;
using Newtonsoft.Json;



namespace ImpactAdminPanel.Areas.Master.Controllers
{
    public class EmailSettingsController : BaseController
    {
        EmailSettingsRepository oEmailSettingsRepository;
        public EmailSettingsController()
        {
            oEmailSettingsRepository = new EmailSettingsRepository();
        }

        public ActionResult Index()
        {
            return View(oEmailSettingsRepository.GetEmailSettingsList());
        }

        public JsonResult ActivateEmailSettings(string Id, bool status)
        {
            return Json(oEmailSettingsRepository.ActivateEmailSettings(Id,status), JsonRequestBehavior.AllowGet);
        }

        public ActionResult EmailSettingsList()
        {
            return  PartialView("~/Areas/Master/Views/Shared/_EmailSettingsList.cshtml",oEmailSettingsRepository.GetEmailSettingsList());
        }

        public ActionResult AddEdit(FormCollection formCollection)
        {
            var result = EmailSettingsValidation.AddEditEmailSettings(formCollection, oEmailSettingsRepository);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetEmailSettingsById(int Id)
        {
            var result = oEmailSettingsRepository.GetEmailSettingsById(Id);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult TestMail(FormCollection formCollection)
        {
            var result = EmailSettingsValidation.TestEmailSettings(formCollection, oEmailSettingsRepository);           
            return Json(JsonConvert.SerializeObject(result), JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// Dispose all the oPrivilegeRepository object
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            oEmailSettingsRepository.Dispose();
            base.Dispose(disposing);
        }
    }
}
