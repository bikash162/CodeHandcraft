﻿using ImpactAdminPanel.Controllers;
using ImpactAdminPanel.Helper;
using ServiceLayer.Entity.Master;
using ServiceLayer.Repository.Master;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Master;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ImpactAdminPanel.Areas.Master.Controllers
{
    public class DepartmentController : BaseController
    {
        DepartmentRepository oDepartmentRepository;
        public DepartmentController()
        {
            oDepartmentRepository = new DepartmentRepository();
        }

        //
        // GET: /Master/Department/
        /// <summary>
        /// <Get All Departments List with paging >
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public ActionResult Index(int? page, int? pagesize, string sortBy, bool ascending = true, string SearchDepartmentName = null)
        {
            try
            {
                DepartmentViewModel oDepartmentViewModel = new DepartmentViewModel();
                oDepartmentViewModel = oDepartmentRepository.GetDepartments(page, pagesize, sortBy, ascending, SearchDepartmentName);
                return View(oDepartmentViewModel);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// <Create new Department>
        /// </summary>
        /// <param name="oDepartment"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(DepartmentViewModel departmentViewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {                  
                    departmentViewModel.Department.CreatedBy = CurrentUser.UserID;
                    var result = oDepartmentRepository.InsertDepartment(departmentViewModel);
                    ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
                    ViewBag.Message = result.ReturnMessage;
                }
                catch (Exception ex)
                {
                    ViewBag.MessageType = MessageType.Error;
                    ModelState.AddModelError("", ex.Message);
                }
            }
            else
            {
                ViewBag.MessageType = MessageType.Error;
            }
            return View(departmentViewModel);
        }

        /// <summary>
        /// <populate department information based on DepartmentId>
        /// </summary>
        /// <param name="DepartmentId"></param>
        /// <returns></returns>
        public ActionResult Edit(int DepartmentID)
        {
            DepartmentViewModel departmentViewModal = new DepartmentViewModel();
            departmentViewModal.Department = oDepartmentRepository.GetDepartmentId(DepartmentID);
            return View(departmentViewModal);
        }

        /// <summary>
        /// <update department information based on DepartmentId>
        /// </summary>
        /// <param name="departmentViewModal"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(DepartmentViewModel departmentViewModal)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    departmentViewModal.Department.ModifiedBy = CurrentUser.UserID;
                    var result = oDepartmentRepository.UpdateDepartment(departmentViewModal);
                    ViewBag.MessageType = result.ReturnValue == 2 ? MessageType.Success : MessageType.Error;
                    ViewBag.Message = result.ReturnMessage;
                }
                catch (Exception ex)
                {
                    ViewBag.MessageType = MessageType.Error;
                    ModelState.AddModelError("", ex.Message);
                }
            } 
            else
             {
                ViewBag.MessageType = MessageType.Error;
            }
            return View(departmentViewModal);
        }

        /// <summary>
        /// <Dispose all>
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            oDepartmentRepository.Dispose();
            base.Dispose(disposing);
        }

    }
}
