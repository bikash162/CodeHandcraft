﻿var FileUploadSettingsFormValidation = function (element) {
    var handleFileUploadSettingsFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "ddlType": {
                    required: function() {
                        valueNotEquals: "0";
                    } 
                },
                "txtPath": {
                    required: true
                },
                "txtFolderName": {
                    required: function () {
                        depends: if ($("#ddlType").val() != "1") {
                            return false;
                        };
                    }
                },
                "txtDomain": {
                    required: function () {
                        depends: if ($("#ddlType").val() != "2") {
                            return false;
                        };
                    }
                },
                "txtPort": {
                    required: function () {
                        depends: if ($("#ddlType").val() != "1") {
                            return false;
                        };
                    }
                },
                "txtUsername": {
                    required: function () {
                        depends: if ($("#ddlType").val() == "3"  ) {
                            return false;
                        } 
                    }
                },
                "txtPassword": function () {
                    depends: if ($("#ddlType").val() == "3") {
                        return false;
                    }
                }
            },
            messages: {
                "ddlType": {
                    required: 'Please Select Type'
                },
                "txtPath": {
                    required: 'Enter Path Name'
                },
                "txtFolderName": {
                    required: 'Enter Folder Name'
                },
                "txtDomain": {
                    required: 'Enter Domain'
                },
                "txtPort": {
                    required: 'Enter Port'
                },
                "txtUsername": {
                    required: 'Enter User Name'
                },
                "txtPassword": {
                    required: 'Enter Password'
                }
            },

            submitHandler: function (form) {
                handleFileUploadSettingsAddEditForm($(form));
            }
        });
    }
    var handleFileUploadSettingsAddEditForm = function (form) {

        $.ajax({
            url: window.URL + 'Master/FileUploadSettings/AddEdit',
            data: form.serialize(),
            cache: false,
            type: 'POST',
            dataType: 'json',
            success: function (data) {
                if (data.ReturnValue == "1") {
                    $("#modal-fileuploadsettings-add").modal('hide');
                    $("#alertdiv").removeClass().addClass("alert alert-success");
                    $("#alertstrong").text("Success!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                    myFileUploadSettings.List();
                }
                else {
                    $("#alertdiv").removeClass().addClass("alert alert-danger");
                    $("#alertstrong").text("Error!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                }
                return;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleFileUploadSettingsFormValidation(element);
        }
    };
}();

