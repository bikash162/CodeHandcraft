﻿
var EmailSettings = function () {   
    var handleEmailSettingsActivation = function () {
        $("#button-active-no").on('click', function () {
            var chk = "chk" + $("#hdnSettingsId").val();
            if ($("#" + chk).prop('checked')) {
                $("#" + chk).bootstrapSwitch('state', false);
            }
            else {
                $("#" + chk).bootstrapSwitch('state', true);
            }

        });
        $("#button-active-yes").on('click', function () {
            var chk = "chk" + $("#hdnSettingsId").val();
            var activateObj = {
                Id: $('#hdnSettingsId').val(),
                status: $("#" + chk).prop('checked')
            };
            $.ajax({
                type: "POST",
                url: window.URL + 'Master/EmailSettings/ActivateEmailSettings',
                data: JSON.stringify(activateObj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (result) {
                    if (result.ReturnValue == -1) {
                        if ($("#" + chk).prop('checked')) {
                            $("#" + chk).bootstrapSwitch('state', false);
                        }
                        else {
                            $("#" + chk).bootstrapSwitch('state', true);
                        }
                        $("#alertdiv").removeClass().addClass("alert alert-danger");
                        $("#alertstrong").text("Error!");
                        $("#alertmsg").text('Unable to update, please try again later.');
                        $("#alertModal").modal('show');
                    }
                    else {                       
                        myEmailSettings.List();
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    } else {
                        $("#alertdiv").removeClass().addClass("alert alert-danger");
                        $("#alertstrong").text("Error!");
                        $("#alertmsg").text(xhr.statusText);
                        $("#alertModal").modal('show');
                    }
                }
            });
        });
    }
    var handleEmailSettingsAddEdit = function () {
        $("#btnEmailSettingsAdd").click(function () {
            $("#hdnEmailSettingsId").val("");
            $("#modal-emailsettings-add").modal('show');
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("emailsettings-form-addedit");
        });
    }
    return {
        //main function to initiate the module
        init: function () {          
            myEmailSettings.MakeSwitch();            
            myEmailSettings.List();
            handleEmailSettingsActivation();
            handleEmailSettingsAddEdit();
        }
    };
}();

var myEmailSettings;
myEmailSettings = myEmailSettings || (function () {
    return {
        MakeSwitch: function () {
            $(".make-switch").bootstrapSwitch();
            $('.make-switch').on('switchChange.bootstrapSwitch', function (event, state, data) {
                var parentChk = $(this).attr('id').replace("chk", "");
                //Number check is used to apply checkbox of email list not any thing from the popup
                if ($.isNumeric(parentChk)) {
                    $('#myswitch').bootstrapSwitch('state', state, data);
                    $("#hdnSettingsId").val(parentChk);
                    var msg = "";
                    if (state == true) {
                        msg = "Are you sure you want to activate the setting";
                    } else {
                        msg = "Are you sure you want to de-activate the setting";
                    }
                    $("#lbl-active-setting").text($("#lbl" + parentChk).text());
                    $("#lbl-msg").text(msg);
                    $("#modal-active-settings").modal('show');
                }
                else {
                    $(this).val(state).prop('checked', state);
                }
            });
        },
        List: function () {
            $.ajax({
                contentType: "application/json; charset=utf-8",
                datatype: "html",
                type: "GET",
                url: window.URL + 'Master/EmailSettings/EmailSettingsList',
                success: function (data) {
                    $('#emailsettings-content').html(data);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            }).done(function () {                
                myEmailSettings.MakeSwitch();
            });
        },
        Edit: function (Element) {            
            var editId = $(Element).attr('id').replace("btn-edit", "");
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("emailsettings-form-addedit");
           
            $.ajax({
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                type: "GET",
                data: { Id: editId },
                url: window.URL + 'Master/EmailSettings/GetEmailSettingsById',
                success: function (data) {                    
                    $("#hdnEmailSettingsId").val(editId);
                    $("#txtProviderName").val(data.ProviderName);
                    $("#txtFromEmail").val(data.FromEmail);
                    $("#txtFromDisplayName").val(data.FromDisplayName);
                    $("#txtSmtpHost").val(data.SmtpHost);
                    $("#txtSmtpPort").val(data.SmptPort);
                    $("#txtDefaultUserName").val(data.CredentialUserName);
                    $("#txtDefaultUserPassword").val(data.CredentialPassword);
                    $("#chkDefaultCredentails").val(data.UseDefaultCredentials).prop('checked', data.UseDefaultCredentials).change();
                    $("#chkEnableSSL").val(data.EnableSsl).prop('checked', data.EnableSsl).change();
                    $("#modal-emailsettings-add").modal('show');
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            });
        },
        TestMail: function (Element) {
            var editId = $(Element).attr('id').replace("btn-mail", "");
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("emailsettings-form-testmail");
            $("#hdnTestMailId").val(editId);
            $("#modal-emailsettings-testmail").modal('show');
            $("#lblTestMail").removeClass().text("");
        }

    };
})();