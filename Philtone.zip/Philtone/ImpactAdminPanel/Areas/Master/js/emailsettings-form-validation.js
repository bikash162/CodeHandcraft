﻿var EmailSettingsFormValidation = function (element) {
    var handleEmailSettingsFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "txtProviderName": {
                    required: true
                },
                "txtFromEmail": {
                    required: true
                },
                "txtFromDisplayName": {
                    required: true
                },
                "txtSmtpHost": {
                    required: true
                },
                "txtSmtpPort": {
                    required: true
                },
                "txtDefaultUserName": {
                    required: true
                },
                "txtDefaultUserPassword": {
                    required: true
                }
            },
            messages: {
                "txtProviderName": {
                    required: 'Enter Provider Name'
                },
                "txtFromEmail": {
                    required: 'Enter From Email'
                },
                "txtFromDisplayName": {
                    required: 'Enter From Display Name'
                },
                "txtSmtpHost": {
                    required: 'Enter Smtp Host'
                },
                "txtSmtpPort": {
                    required: 'Enter Smtp Port'
                },
                "txtDefaultUserName": {
                    required: 'Enter Default User Name'
                },
                "txtDefaultUserPassword": {
                    required: 'Enter Default User Password'
                }
            },

            submitHandler: function (form) {
                handleEmailSettingsAddEditForm($(form));                
            }
        });
    }
    var handleEmailSettingsAddEditForm = function (form) {
       
        $.ajax({
            url: window.URL + 'Master/EmailSettings/AddEdit',
            data: form.serialize(),
            cache: false,
            type: 'POST',
            dataType: 'json',
            success: function (data) {
                if (data.ReturnValue == "1") {
                    $("#modal-emailsettings-add").modal('hide');
                    $("#alertdiv").removeClass().addClass("alert alert-success");
                    $("#alertstrong").text("Success!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                    myEmailSettings.List();
                }
                else {
                    $("#alertdiv").removeClass().addClass("alert alert-danger");
                    $("#alertstrong").text("Error!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                }
                return;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleEmailSettingsFormValidation(element);
        }
    };
}();

var TestMailFormValidation = function (element) {
    var handleTestMailFormValidation = function (element) {
        $("#emailsettings-form-testmail").validate({
            rules: {
                "txtToMailAddress": {
                    required: true
                }
            },
            messages: {
                "txtToMailAddress": {
                    required: 'Enter Email Address'
                }
            },

            submitHandler: function (form) {
                handleTestMailForm($(form));
                
            }
        });
    }
    var handleTestMailForm = function (form) {        
        $("#button-testMail-yes").attr("disabled", true);      
        $("#button-testMail-yes").text("In Progress");
        $.ajax({
            url: window.URL + 'Master/EmailSettings/TestMail',
            data: form.serialize(),
            cache: false,
            type: 'POST',
            dataType: 'json',
            success: function (data) {
                var obj=JSON.parse(data);
                
                if (obj.ReturnValue == true) {                   
                    $("#modal-emailsettings-testmail").modal('hide');
                    $("#alertdiv").removeClass().addClass("alert alert-success");
                    $("#alertstrong").text("Success!");
                    $("#alertmsg").text(obj.ReturnMessage);
                    $("#alertModal").modal('show');
                }
                else {
                    $("#lblTestMail").removeClass().addClass("label label-danger");
                    $("#lblTestMail").text(obj.ReturnMessage);
                }
                $("#button-testMail-yes").text("Send Mail");
                $("#button-testMail-yes").attr("disabled", false);
                return;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        }).done(function () {                
            myApp.hidePleaseWait();
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleTestMailFormValidation(element);
        }
    }
    
}();