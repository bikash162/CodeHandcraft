﻿
$(document).delegate(".menuEdit", "click", function (e) {    
        $("#Reset").click();
        var MenuId = $(this).attr('id');
        var selectedParenetId = 0;
        $.ajax({
            url: window.rootUrl + 'Master/Menu/GetMenuInfo',
            type: 'Post',
            async: true,
            dataType: 'json',
            data: { MenuID: MenuId },
            success: function (data) {

                if (data != null) {

                    clearRequiredMessage();
                    $("#chkIsActive").val(data.IsActive).prop('checked', data.IsActive);
                    $("#chkIsActive").prop('checked', data.IsActive).change();
                    if (data.IsModule == true) {
                        $('input[type="radio"]').eq(0).prop('checked', 'checked');
                        RadioAction(0);
                        $("#menu_ModuleName").val(data.MenuName);
                        $("#menu_MenuUrl").val(data.MenuUrl);
                    }
                    else if (data.IsParent == true) {
                        $('input[type="radio"]').eq(1).prop('checked', 'checked');
                        RadioAction(1);
                        $("#menu_MenuID").val(data.ParentMenuID);
                        $("#menu_ParentMenu").val(data.MenuName);
                    }
                    else {
                        $('input[type="radio"]').eq(2).prop('checked', 'checked');
                        RadioAction(2);
                        if (data.ModuleID != 0) {
                            $("#menu_MenuID").val(data.ModuleID);
                            BindParentMenu(data.ParentMenuID);

                        }
                        else {
                            $("#menu_MenuID").val(data.ParentMenuID);
                            $("#menu_ParentMenuID").val("0");
                        }
                        $("#menu_MenuName").val(data.MenuName);
                        $("#menu_MenuUrl").val(data.MenuUrl);
                    }
                    $("#hdnEditID").val(data.MenuID);

                }

            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    });

$(document).ready(function () {  
        BindModule();
        InitialState();
       
        $('input[name="menu.MenuType"]:radio').eq(0).change(function () {
            clearRequiredMessage();
            RadioAction(0);
        });
        $('input[name="menu.MenuType"]:radio').eq(1).change(function () {
            clearRequiredMessage();
            RadioAction(1);
        });
        $('input[name="menu.MenuType"]:radio').eq(2).change(function () {
            clearRequiredMessage();
            RadioAction(2);
        });
        $('input[name="menu.MenuType"]:radio').eq(2).click();
        $('input[name="Url"]:radio').eq(0).change(function () {
            $("#lblsample").text("ex: / Area / ControllerFolder (if any) / Controller ");
        });
        $('input[name="Url"]:radio').eq(1).change(function () {
            $("#lblsample").text("ex: http://www.impactitsolutions.co.uk");
        });

        $("#Reset").on('click', function () {
            $('input[name="menu.MenuType"]:radio').eq(2).prop('checked', 'checked');
            InitialState();
            clearRequiredMessage();
            $("#Submit").prop("disabled", false);
            $("#menuSuccess").removeClass().addClass("alert alert-success display-hide");
            $("#menuError").removeClass().addClass("alert alert-danger display-hide");
            $("#menuSuccess").css('display', 'none')
            $("#menuError").css('display', 'none')
            $("#hdnEditID").val("0");
            BindModule();
            BindParentMenu(0);
        });
        $('#chkIsActive').on('change', function () {
            $('input[name="chkIsActive"]').val($(this).is(':checked') ? 'true' : 'false');
        });
        $("#successClose").on('click', function () {
            $("#Submit").prop("disabled", false);
            $("#menuSuccess").removeClass().addClass("alert alert-success display-hide");
            $("#menuSuccess").removeAttr("style");
            $('input[type="radio"]').eq(2).prop('checked', 'checked');
            InitialState();
            clearRequiredMessage();
            $("#hdnEditID").val("0");
            BindModule();
            BindParentMenu(0);
        });
        $("#errorClose").on('click', function () {
            $("#menuError").removeClass().addClass("alert alert-danger display-hide");
        });

    });
    function InitialState() {
        if ($('input[type="radio"][name=optionsRadios]:selected')) {
            $("#menu_ModuleName").prop("disabled", true).val("");
            $("#menu_MenuID").prop("disabled", false).val("");
            $("#menu_ParentMenu").prop("disabled", true).val("");
            $("#menu_ParentMenuID").prop("disabled", true).val("0");
            $("#menu_MenuName").prop("disabled", false).val("");
            $("#menu_MenuUrl").prop("disabled", false).val("");
            $("#hdnEditID").val("0");
            $('input[name="Url"]:radio').eq(0).prop('checked', true);
        }
    }
    function RadioAction(RadioType) {
        $("#menu_ModuleName").val("");
        $("#menu_MenuID").val("");
        $("#menu_ParentMenu").val("");
        $("#menu_ParentMenuID").val("");
        $("#menu_MenuName").val("");
        $("#menu_MenuUrl").val("");
        $("#hdnEditID").val("0");
        $('input[name="Url"]:radio').eq(0).prop('checked', true);
        if (RadioType == 0) {
            $("#menu_ModuleName").prop("disabled", false);
            $("#menu_MenuID").prop("disabled", true);
            $("#menu_ParentMenu").prop("disabled", true);
            $("#menu_ParentMenuID").prop("disabled", true);
            $("#menu_MenuName").prop("disabled", true);
            $("#menu_MenuUrl").prop("disabled", false);
        }
        if (RadioType == 1) {
            $("#menu_ModuleName").prop("disabled", true);
            $("#menu_MenuID").prop("disabled", false);
            $("#menu_ParentMenu").prop("disabled", false);
            $("#menu_ParentMenuID").prop("disabled", true);
            $("#menu_MenuName").prop("disabled", true);
            $("#menu_MenuUrl").prop("disabled", true);
        }
        if (RadioType == 2) {
            $("#menu_ModuleName").prop("disabled", true);
            $("#menu_MenuID").prop("disabled", false);
            $("#menu_ParentMenu").prop("disabled", true);
            $("#menu_ParentMenuID").prop("disabled", false);
            $("#menu_MenuName").prop("disabled", false);
            $("#menu_MenuUrl").prop("disabled", false);
        }
    }
    function formValidation() {
        var count = 0;
        if ($('input[name="menu.MenuType"]:radio').eq(2).is(":checked")) {
            if ($("#menu_MenuID").val() == "") {
                $("#menu_MenuID").parent().find('span').removeClass().addClass('help-block help-block-error');
                count = 1;
            }
            if ($("#menu_MenuName").val() == "") {
                $("#menu_MenuName").parent().find('span').removeClass().addClass('help-block help-block-error');
                count = 1;
            }
            if ($("#menu_MenuUrl").val() == "") {
                $("#menu_MenuUrl").parent().find('span').removeClass().addClass('help-block help-block-error').text("* required");
                count = 1;
            }
            else {
                if ($('input[name="Url"]:radio').eq(1).is(":checked")) {
                    var myVariable = $("#menu_MenuUrl").val();
                    if (/^(http:\/\/www\.|https:\/\/www\.)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(myVariable) == false) {
                        $("#menu_MenuUrl").parent().find('span').removeClass().addClass('help-block help-block-error').text("* format is not correct");
                        count = 1;
                    }
                }
            }
        }
        if ($('input[name="menu.MenuType"]:radio').eq(1).is(":checked")) {
            if ($("#menu_MenuID").val() == "") {
                $("#menu_MenuID").parent().find('span').removeClass().addClass('help-block help-block-error');
                count = 1;
            }
            if ($("#menu_ParentMenu").val() == "") {
                $("#menu_ParentMenu").parent().find('span').removeClass().addClass('help-block help-block-error');
                count = 1;
            }
        }
        if ($('input[name="menu.MenuType"]:radio').eq(0).is(":checked")) {
            if ($("#menu_ModuleName").val() == "") {
                $("#menu_ModuleName").parent().find('span').removeClass().addClass('help-block help-block-error');
                count = 1;
            }

        }

        if (count == 1) {
            return false;
        }
        else {
            var MenuVal;
            var Type;
            if ($('input[name="menu.MenuType"]:radio').eq(0).is(":checked")) {
                MenuVal = $("#menu_ModuleName").val();
                Type = $('input[name="menu.MenuType"]:radio').eq(0).val();
            }
            else if ($('input[name="menu.MenuType"]:radio').eq(1).is(":checked")) {
                MenuVal = $("#menu_ParentMenu").val();
                Type = $('input[name="menu.MenuType"]:radio').eq(1).val();
            }
            else if ($('input[name="menu.MenuType"]:radio').eq(2).is(":checked")) {
                MenuVal = $("#menu_MenuName").val();
                Type = $('input[name="menu.MenuType"]:radio').eq(2).val();
            }
            var MenuPost = {
                MenuType: Type,
                MenuName: MenuVal,
                IsThirdParty: $('input[name="Url"]:radio').eq(1).is(":checked") ? true : false,
                MenuUrl: $("#menu_MenuUrl").val(),
                MenuID: $("#menu_MenuID").val(),
                ParentMenuID: $("#menu_ParentMenuID").val(),
                IsActive: $("#chkIsActive").val(),
                EditID: $("#hdnEditID").val()
            };

            $.ajax({
                url: window.rootUrl + 'Master/Menu/AddEditMenu',
                type: 'Post',
                dataType: 'text',
                data: MenuPost,
                success: function (data) {

                    clearRequiredMessage();
                    BindModule();
                    BindParentMenu(0);
                    $("#MenuPlaceHolder").html(data);
                    $("#menuSuccess").css('display', 'block')
                    $("#menuSuccess").removeClass().addClass("alert alert-success display-show");
                    $("#Submit").prop("disabled", true);
                    $("#hdnEditID").val("0");
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    $("#menuError").find('label').text(xhr.statusText);
                    $("#menuError").css('display', 'block')
                    $("#menuError").removeClass().addClass("alert alert-danger display-show");

                }
            }).done(function () {
                $('#menuList').treed({ openedClass: 'glyphicon-chevron-right', closedClass: 'glyphicon-chevron-down', initialState: 'expanded' });
            });
            return true;
        }
    }
    function clearRequiredMessage() {
        $(".form-body").find('span').removeClass().addClass('errorHide');
        //$("#formMenu").find('span').each(function () {

        //});
    }
    function BindParentMenu(selectedValue) {
        var ModuleId = $('#menu_MenuID').val();
        if (ModuleId != "") {
            $.ajax({
                url: window.rootUrl + 'Master/Menu/BindParentMenu',
                type: 'Post',
                async: true,
                dataType: 'json',
                data: { ModuleId: ModuleId },
                success: function (data) {

                    if (data.length > 0) {
                        $("#menu_ParentMenuID").prop("disabled", false);
                        $("#menu_ParentMenuID").html(""); // clear before appending new list 
                        $("#menu_ParentMenuID").empty().append('<option value="0">Select Parent Menu</option>');
                        $.each(data, function (i, item) {
                            if (item.MenuID == selectedValue) {
                                if (item.IsActive == true) {
                                    $("#menu_ParentMenuID").append($('<option selected="true"  ></option>').val(item.MenuID).html(item.MenuName));
                                }
                                else {
                                    $("#menu_ParentMenuID").append($('<option selected="true" class="option-red"></option>').val(item.MenuID).html(item.MenuName));
                                }
                            }
                            else {
                                if (item.IsActive == true) {
                                    $("#menu_ParentMenuID").append($('<option></option>').val(item.MenuID).html(item.MenuName));
                                }
                                else {
                                    $("#menu_ParentMenuID").append($('<option class="option-red"></option>').val(item.MenuID).html(item.MenuName));
                                }
                            }
                        });
                        if ($('input[name="menu.MenuType"]:radio').eq(1).is(":checked")) {
                            $("#menu_ParentMenuID").prop("disabled", true);
                        }
                    }
                    else {
                        $("#menu_ParentMenuID").prop("disabled", true);
                    }
                }
            });
        }
    }

    function BindModule() {

        $.ajax({
            url: window.rootUrl +'Master/Menu/BindModule',
            type: 'GET',
            async: true,
            dataType: 'json',
            success: function (data) {
                if (data.length > 0) {
                    $("#menu_MenuID").html(""); // clear before appending new list 
                    $("#menu_MenuID").empty().append('<option selected="selected" value="">Select Module</option>');
                    $.each(data, function (i, item) {
                        if (item.IsActive == true) {
                            $("#menu_MenuID").append($('<option></option>').val(item.MenuID).html(item.MenuName));
                        } else {

                            $("#menu_MenuID").append($('<option class="option-red"></option>').val(item.MenuID).html(item.MenuName));
                        }
                    });

                }
            }
        });
    }
