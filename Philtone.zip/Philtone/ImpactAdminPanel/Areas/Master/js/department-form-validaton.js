﻿var DepartmentFormValidation = function (element) {
    var handleDepartmentFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "Department.DepartmentName": {
                    required: true
                }
            },
            messages: {
                "Department.DepartmentName": {
                    required: 'Enter Department Name'
                }
            },

            submitHandler: function (form) {
                myApp.showPleaseWait();
                form.submit();
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleDepartmentFormValidation(element);
        }
    };
}();