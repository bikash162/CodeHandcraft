﻿
var FileUploadSettings = function () {      
    var handleFileUploadSettingsActivation = function () {
        $("#button-active-no").on('click', function () {
            var chk = "chk" + $("#hdnSettingsId").val();
            if ($("#" + chk).prop('checked')) {
                $("#" + chk).bootstrapSwitch('state', false);
            }
            else {
                $("#" + chk).bootstrapSwitch('state', true);
            }

        });
        $("#button-active-yes").on('click', function () {
            var chk = "chk" + $("#hdnSettingsId").val();
            var activateObj = {
                Id: $('#hdnSettingsId').val(),
                status: $("#" + chk).prop('checked')
            };
            $.ajax({
                type: "POST",
                url: window.URL + 'Master/FileUploadSettings/ActivateFileUploadSettings',
                data: JSON.stringify(activateObj),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (result) {
                    if (result.ReturnValue == -1) {
                        if ($("#" + chk).prop('checked')) {
                            $("#" + chk).bootstrapSwitch('state', false);
                        }
                        else {
                            $("#" + chk).bootstrapSwitch('state', true);
                        }
                        $("#alertdiv").removeClass().addClass("alert alert-danger");
                        $("#alertstrong").text("Error!");
                        $("#alertmsg").text('Unable to update, please try again later.');
                        $("#alertModal").modal('show');
                    }
                    else {
                        myFileUploadSettings.List();
                    }

                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    } else {
                        $("#alertdiv").removeClass().addClass("alert alert-danger");
                        $("#alertstrong").text("Error!");
                        $("#alertmsg").text(xhr.statusText);
                        $("#alertModal").modal('show');
                    }
                }
            });
        });
    }
    var handleFileUploadSettingsAddEdit = function () {
        $("#btnFileUploadSettingsAdd").click(function () {
            myForm.Clear("fileuploadsettings-form-addedit");
            $("#ddlType").val("0");
            $("#hdnFileUploadSettingsId").val("");
            $("#modal-fileuploadsettings-add").modal('show');
        });
    }

    

    return {
        //main function to initiate the module
        init: function () {
            myFileUploadSettings.MakeSwitch();
            myFileUploadSettings.List();
            handleFileUploadSettingsActivation();
            handleFileUploadSettingsAddEdit();
            //handleTypeSelection();
        }
    };
}();

var myFileUploadSettings;
myFileUploadSettings = myFileUploadSettings || (function () {
    return {
        MakeSwitch: function () {
            $(".make-switch").bootstrapSwitch();
            $('.make-switch').on('switchChange.bootstrapSwitch', function (event, state, data) {
                $('#myswitch').bootstrapSwitch('state', state, data);
                var parentChk = $(this).attr('id').replace("chk", "");
                if ($.isNumeric(parentChk)) {
                    $("#hdnSettingsId").val(parentChk);
                    var msg = "";
                    if (state == true) {
                        msg = "Are you sure you want to activate the setting";
                    } else {
                        msg = "Are you sure you want to de-activate the setting";
                    }
                    $("#lbl-active-setting").text($("#lbl" + parentChk).text());
                    $("#lbl-msg").text(msg);
                    $("#modal-active-settings").modal('show');
                } else {
                    $(this).val(state).prop('checked', state);
                }
            });
        },
        List: function () {
            $.ajax({
                contentType: "application/json; charset=utf-8",
                datatype: "html",
                type: "GET",
                url: window.URL + 'Master/FileUploadSettings/GetFileUploadSettingsList',
                success: function (data) {
                    $('#fileuploadsettings-content').html(data);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            }).done(function () {
                myFileUploadSettings.MakeSwitch();
            });
        },
        Edit: function (Element) {
            var editId = $(Element).attr('id').replace("btn-edit", "");
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("fileuploadsettings-form-addedit");

            $.ajax({
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                type: "GET",
                data: { Id: editId },
                url: window.URL + 'Master/FileUploadSettings/GetFileUploadSettingsById',
                success: function (data) {
                    $("#hdnFileUploadSettingsId").val(editId);
                    $("#ddlType").val(data.Type);
                    $("#txtPath").val(data.Path);
                    $("#txtFolderName").val(data.FolderName);
                    $("#txtDomain").val(data.Domain);
                    $("#txtPort").val(data.Port);
                    $("#txtUsername").val(data.Username);
                    $("#txtPassword").val(data.Password);
                    $("#chkSSLEnable").val(data.SSLEnable).prop('checked', data.SSLEnable).change();
                    $("#modal-fileuploadsettings-add").modal('show');
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            });
        }
    };
})();