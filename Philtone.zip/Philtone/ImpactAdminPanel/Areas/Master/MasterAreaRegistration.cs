﻿using System.Web.Mvc;
using System.Web.Http;
using ImpactAdminPanel.Models;

namespace ImpactAdminPanel.Areas.Master
{
    public class MasterAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Master";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
            name: "Master_parent",
            url: "Master/{parent}/{controller}/{action}/{id}",
            defaults: new
            {
                parent = RouteParameter.Optional,
                id = UrlParameter.Optional,
                action = "Index"
            },
            constraints: new { parent = new ControllerNameConstraint() }
           );
            context.MapRoute(
                 name: "Master_default",
                 url: "Master/{controller}/{action}/{id}",
                defaults: new { action = "Index", id = UrlParameter.Optional }

            );
        }
    }
}
