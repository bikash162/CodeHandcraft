﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Entity.Master;
using ServiceLayer.Repository.Master;
using ServiceLayer.Utitlity;
using System.Dynamic;

namespace ImpactAdminPanel.Areas.Master.Models
{
    public static class EmailSettingsValidation 
    {

        public static dynamic AddEditEmailSettings(FormCollection formCollection,EmailSettingsRepository oEmailSettingsRepository)
        {
            EmailSettings oEmailSettings = new EmailSettings();
            oEmailSettings.ID = Convert.ToInt32(formCollection["hdnEmailSettingsId"].ToString().Trim() == "" ? "0" : formCollection["hdnEmailSettingsId"].ToString().Trim());
            oEmailSettings.ProviderName = formCollection["txtProviderName"].ToString().Trim();
            oEmailSettings.FromEmail = formCollection["txtFromEmail"].ToString().Trim();
            oEmailSettings.FromDisplayName = formCollection["txtFromDisplayName"].ToString().Trim();
            oEmailSettings.SmtpHost = formCollection["txtSmtpHost"].ToString().Trim();
            oEmailSettings.SmptPort = Convert.ToInt32(formCollection["txtSmtpPort"].ToString().Trim() == "" ? "0" : formCollection["txtSmtpPort"].ToString().Trim());
            oEmailSettings.CredentialUserName= formCollection["txtDefaultUserName"].ToString().Trim();
            oEmailSettings.CredentialPassword = formCollection["txtDefaultUserPassword"].ToString().Trim();
            if (formCollection["chkDefaultCredentails"] != null)
            {
                oEmailSettings.UseDefaultCredentials = Convert.ToBoolean(formCollection["chkDefaultCredentails"].ToString().Trim());
            }
            if (formCollection["chkEnableSSL"] != null)
            {
                oEmailSettings.EnableSsl = Convert.ToBoolean(formCollection["chkEnableSSL"].ToString().Trim());
            }

            dynamic result = formCollection["hdnEmailSettingsId"].ToString().Trim() == "" ? oEmailSettingsRepository.InsertEmailSettings(oEmailSettings) : oEmailSettingsRepository.UpdateEmailSettings(oEmailSettings);
            return result;
        }

        public static dynamic TestEmailSettings(FormCollection formCollection, EmailSettingsRepository oEmailSettingsRepository)
        {
            var result = oEmailSettingsRepository.GetEmailSettingsById(Convert.ToInt32(formCollection["hdnTestMailId"].ToString().Trim() == "" ? "0" : formCollection["hdnTestMailId"].ToString().Trim()));
            INotificaiton oNotifiation = new Email(result.FromEmail, result.FromDisplayName, formCollection["txtToMailAddress"].ToString().Trim(), "Test Mail", "Test Mail Ignore", result.SmtpHost, result.SmptPort, result.EnableSsl, result.UseDefaultCredentials, result.CredentialUserName, result.CredentialPassword);
            dynamic jsonObject = new ExpandoObject();
            try
            {
                jsonObject.ReturnValue = oNotifiation.SendMessage();
                jsonObject.ReturnMessage = "Mail Send Successfully";
            }
            catch (Exception ex)
            {
                jsonObject.ReturnValue = false;
                jsonObject.ReturnMessage = ex.Message;
                CommonHelper.ExceptionLogger(ex, "EmailSettings", "TestMail");
            }

            return jsonObject;
        }
    }
}