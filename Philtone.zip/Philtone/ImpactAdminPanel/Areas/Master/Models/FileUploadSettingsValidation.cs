﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ServiceLayer.Entity.Master;
using ServiceLayer.Repository.Master;
using ServiceLayer.Utitlity;
using System.Dynamic;


namespace ImpactAdminPanel.Areas.Master.Models
{
    public class FileUploadSettingsValidation
    {
        public static dynamic AddEditFileUploadSettings(FormCollection formCollection, FileUploadSettingsRepository oFileUploadSettingsRepository, int UserId)
        {
            FileUploadSettings oFileUploadSettings = new FileUploadSettings();
            oFileUploadSettings.ID = Convert.ToInt32(formCollection["hdnFileUploadSettingsId"].ToString().Trim() == "" ? "0" : formCollection["hdnFileUploadSettingsId"].ToString().Trim());
            oFileUploadSettings.Path = formCollection["txtPath"].ToString().Trim();
            oFileUploadSettings.FolderName = formCollection["txtFolderName"].ToString().Trim();
            oFileUploadSettings.Domain = formCollection["txtDomain"].ToString().Trim();
            oFileUploadSettings.Port = Convert.ToInt32(formCollection["txtPort"].ToString().Trim() == "" ? "0" : formCollection["txtPort"].ToString().Trim());
            oFileUploadSettings.Type =Convert.ToInt32(formCollection["ddlType"].ToString().Trim());
            oFileUploadSettings.Username = formCollection["txtUsername"].ToString().Trim();
            oFileUploadSettings.Password = oFileUploadSettings.Type < 3 ? CommonHelper.Encode(formCollection["txtPassword"].ToString().Trim()) : formCollection["txtPassword"].ToString().Trim();
            if (formCollection["chkSSLEnable"] != null)
            {
                oFileUploadSettings.SSLEnable = Convert.ToBoolean(formCollection["chkSSLEnable"].ToString().Trim());
            }
            oFileUploadSettings.ModifiedBy = UserId;
            dynamic result = formCollection["hdnFileUploadSettingsId"].ToString().Trim() == "" ? oFileUploadSettingsRepository.InsertFileUploadSettings(oFileUploadSettings) : oFileUploadSettingsRepository.UpdateFileUploadSettings(oFileUploadSettings); 
            return result;
        }
    }
}