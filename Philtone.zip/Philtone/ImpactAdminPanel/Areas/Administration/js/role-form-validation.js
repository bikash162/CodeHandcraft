﻿var RoleFormValidation = function (element) {
    var handleRoleFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "role.DepartmentID": {
                    required: true
                },
                "role.RoleName": {
                    required: true
                }
            },
            messages: {
                "role.DepartmentID": {
                    required: 'Select Department Name'
                },
                "role.RoleName": {
                    required: 'Enter Role Name'
                }
            },

            submitHandler: function (form) {
                myApp.showPleaseWait();
                form.submit();
                //alert("Submitted, thanks!");
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleRoleFormValidation(element);
        }
    };
}();