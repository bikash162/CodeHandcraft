﻿var UserFormValidation = function (element) {
    var handleUserFormValidation = function (element) {
        $("#" + element).validate({           
            rules: {
                "user.Firstname": {
                    required: true
                },
                "user.Lastname": {
                    required: true
                },
                "user.PersonalEmail": {
                    required: true
                },
                "user.PersonalContactNumber": {
                    required: true
                },
                "user.Address": {
                    required: true
                },
                "user.Gender": {
                    required: true
                },
                "user.CountryID": {
                    required: true
                },
                "user.Postcode": {
                    required: true
                },
                "user.DepartmentID": {
                    required: true
                },
                "user.RoleID": {
                    required: true
                },
                "user.LoginName": {
                    required: true
                },
                "user.LoginPassword": {
                    required: true
                },
                "user.EmailAddress": {
                    required: true
                }
            },
            messages: {
                "user.Firstname": {
                    required: 'Enter First Name'
                },
                "user.Lastname": {
                    required: 'Enter Last Name'
                },
                "user.PersonalEmail": {
                    required: 'Enter Personal Name'
                },
                "user.PersonalContactNumber": {
                    required: 'EnterPersonal Contact Number'
                },
                "user.Address": {
                    required: 'Enter Address'
                },
                "user.Gender": {
                    required: 'Select Gender'
                },
                "user.CountryID": {
                    required: 'Select Country'
                },
                "user.Postcode": {
                    required: 'Enter Postcode'
                },
                "user.DepartmentID": {
                    required: 'Select Department'
                },
                "user.RoleID": {
                    required: 'Select Role'
                },
                "user.LoginName": {
                    required: 'Enter Login Name'
                },
                "user.LoginPassword": {
                    required: 'Enter Login Password'
                },
                "user.EmailAddress": {
                    required: 'Enter Email Address'
                }

            },
                  
            submitHandler: function (form) {
                myApp.showPleaseWait();
                form.submit();
                //alert("Submitted, thanks!");

            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleUserFormValidation(element);
        }
    };
}();