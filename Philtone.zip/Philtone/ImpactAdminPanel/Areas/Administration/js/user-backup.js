﻿


//$(function () {
//    $("#user-form").validate({
//        rules: {
//            "user.Firstname": {
//                required: true
//            },
//            "user.Lastname": {
//        required: true
//    }
//        },
//        messages: {
//            "user.Firstname": {
//                required: 'Enter First Name'
//            }, "user.Lastname": {
//                required: 'Enter Last Name'
//            }
//        },        //        submitHandler: function (form) {
//            form.submit();
//        }
//    });
//});
function validateSubmitForm() {
   
    $("#user-form").validate({
        rules: {
            firstname: {
                required: true
            }
        },
        messages: {
            firstname: {
                required: 'Enter First Name'
            }
        }
    });
    //var perinfo=validatePersonalInfomation() ;
    //var orginfo = validateOrgainzationInformation();
    //alert(perinfo + "  " + orginfo);
    //if (result == 0) {
    //    //$("#form-user").submit();
    //    return false;
    //}
    //else {
    //    return false;
    //}
}


function validatePersonalInfomation() {
    var isValid = true;
    if ($('#user_Firstname').val().trim() == "") {
        $('#user_Firstname').css('border-color', 'Red');
        //$('#user_Firstname').closest('.form-group').addClass('has-error');
        isValid = false;
    }
    else {
        $('#user_Firstname').css('border-color', 'lightgrey');
    }

    if ($('#user_Lastname').val().trim() == "") {
        $('#user_Lastname').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Lastname').css('border-color', 'lightgrey');
    }


    if ($('#user_PersonalEmail').val() != "") {
        if (!IsValidEmail($('#user_PersonalEmail').val())) {
            $('#user_PersonalEmail').css('border-color', 'Red');
            isValid = false;
        } else {
            $('#user_PersonalEmail').css('border-color', 'lightgrey');
        }
    }

    if ($('#user_Address').val() == "") {
        $('#user_Address').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Address').css('border-color', 'lightgrey');
    }

    if (document.getElementById("user_CountryID").selectedIndex == 0) {
        $('#user_CountryID').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_CountryID').css('border-color', 'lightgrey');
    }

    if ($('#user_Postcode').val() == "") {
        $('#user_Postcode').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Postcode').css('border-color', 'lightgrey');
    }

    if ($('#user_PersonalContactNumber').val() == "") {
        $('#user_PersonalContactNumber').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_PersonalContactNumber').css('border-color', 'lightgrey');
    }

    if ($('#user_Notes').val() == "") {
        $('#user_Notes').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Notes').css('border-color', 'lightgrey');
    }

    if ($("input[name='user_Gender']:checked").val() == 'undefined') {
        isValid = false;
    }
    if (isValid = false) {
        return 1;
    }
    {
        return 0;
    }
    
}

//validation checking at the time of edit Users Account Settings information
function validateOrgainzationInformation() {
    var isValid = true;


    if ($('#user_EmailAddress').val() == "") {
        $('#user_EmailAddress').css('border-color', 'Red');
        isValid = false;
    }
    else {
        if (!IsValidEmail($('#user_EmailAddress').val())) {
            $('#user_EmailAddress').css('border-color', 'Red');
            isValid = false;
        } else {
            $('#user_EmailAddress').css('border-color', 'lightgrey');
        }
    }

    if ($('#user_Phonenumber').val() == "") {
        $('#user_Phonenumber').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Phonenumber').css('border-color', 'lightgrey');
    }


    if (document.getElementById("user_DepartmentID").selectedIndex == 0) {
        $('#user_DepartmentID').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_DepartmentID').css('border-color', 'lightgrey');
    }

    if (document.getElementById("user_RoleID").selectedIndex == 0) {
        $('#user_RoleID').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#RoleID').css('border-color', 'lightgrey');
    }


    if ($('#user_Skype').val() == "") {
        $('#user_Skype').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_Skype').css('border-color', 'lightgrey');
    }

    if ($('#user_SkypePassword').val() == "") {
        $('#user_SkypePassword').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#user_SkypePassword').css('border-color', 'lightgrey');
    }

    if (isValid = false) {
        return 1;
    }
    {
        return 0;
    }
}


//Validate the Email 
function IsValidEmail(email) {
    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    return expr.test(email);
};



// popluate dropdown of role based on departmentid
function FillRoleBasedonDepartmentID() {
    var DepartmentID = $('#user_DepartmentID').val();
    if (DepartmentID > 0) {
        $.ajax({
            url: window.rootUrl + 'Administration/User/FillRoleBasedOnDepartmentID',
            type: "GET",
            async: true,
            dataType: "json",
            data: { DepartmentID: DepartmentID },
            success: function (data) {
                $("#user_RoleID").html(""); // clear before appending new list 
                $("#user_RoleID").empty().append('<option selected="selected" value="0">Select Role</option>');
                $.each(data, function (i, item) {
                    $("#user_RoleID").append($('<option></option>').val(item.RoleID).html(item.RoleName));
                });
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    else {
        $("#user_RoleID").empty().append('<option selected="selected" value="0">Select Role</option>');
    }
}


//It is return all city list against the country Id, and then filteration for autocomplete search is done using the CityName paramerter
$(function () {
    $('#user_CityName').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetCityListByCountryID',
            data: "{ 'CityName': '" + $('#user_CityName').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="citylist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.CityID + '>' + item.CityName + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocomplete').show();
                $('#divautocomplete').html(val);

                $('#citylist li').click(function () {
                    $('#user_CityName').val($(this).text());
                    $('#user_CityID').val($(this).attr('id'));
                    $('#divautocomplete').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocomplete");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

//It is return all State list against the country Id, and then filteration for autocomplete search is done using the StateName paramerter
$(function () {
    $('#user_StateName').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetStateListByCountryID',
            data: "{ 'StateName': '" + $('#user_StateName').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="Statelist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.StateID + '>' + item.StateName + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocompletestate').show();
                $('#divautocompletestate').html(val);

                $('#Statelist li').click(function () {
                    $('#user_StateName').val($(this).text());
                    $('#user_StateID').val($(this).attr('id'));
                    $('#divautocompletestate').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocompletestate");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

//It is return all Postcode list against the country Id, and then filteration for autocomplete search is done using the PostCode paramerter
$(function () {
    $('#user_Postcode').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetPostCodeListByCountryID',
            data: "{ 'PostCode': '" + $('#user_Postcode').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="Postcodelist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.PostcodeId + '>' + item.Postcode + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocompletepostcode').show();
                $('#divautocompletepostcode').html(val);

                $('#Postcodelist li').click(function () {
                    $('#user_Postcode').val($(this).text());
                    $('#user_PostcodeId').val($(this).attr('id'));
                    $('#divautocompletepostcode').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocompletepostcode");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

function ClearFieldsOnChange() {
    $('#user_CityName').val('');
    $('#user_CityID').val('0');
    $("#divautocomplete").html("");

    $('#user_StateName').val('');
    $('#user_StateID').val('0');
    $("#divautocompletestate").html("");

    $('#user_Postcode').val('');
    $('#user_PostcodeId').val('0');
    $("#divautocompletepostcode").html("");
}