﻿

function BindMapRoleMenu() {
    var roleId = $("#ddlRole").val();   
    $.ajax({
        url: window.rootUrl + 'Administration/Privilege/GetMapMenuRole',
        type: 'Post',
        dataType: 'text',
        data: { RoleID: roleId },
        success: function (data) {
            $("#rolePlaceHolder").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            if (xhr.status == 911) {
                window.location.reload(xhr.statusText);
            } else {
                $("#menuError").find('label').text(xhr.statusText);
                $("#menuError").css('display', 'block')
                $("#menuError").removeClass().addClass("alert alert-danger display-show");
            }

        }
    }).done(function () {
        $('#roleMenuList').treed({ openedClass: 'glyphicon-chevron-right', closedClass: 'glyphicon-chevron-down', initialState: 'expanded' });
        if ($('#roleMenuList').find(':checkbox:checked').length == $('#roleMenuList').find(':checkbox').length) {
            $('#roleCheckAll').prop('checked', true);
        }
        $("#ddlRole").val(roleId);
    });
}



$(document).on('change', '#roleCheckAll', function () {
    $('#roleMenuList').find(':checkbox').prop('checked', this.checked);
});



$(document).on('change', '#roleMenuList :checkbox', function () {
    if (this.checked) {
        $(this).val("True");
        $(this).siblings('ul').find(':checkbox').prop('checked', this.checked);
        if ($(this).closest('ul').find(':checkbox:checked').length == $(this).closest('ul').find(':checkbox').length) {
            $(this).closest('ul').siblings('input:checkbox').prop("indeterminate", false);
            $(this).closest('ul').siblings('input:checkbox').attr('checked', true);
        }
        else {
            /*********** It checks whether there is parent if so then that is also checked and visual only made as intermediate ********/
            if ($(this).closest('ul').find(':checkbox:checked').length > 0) {
                $(this).closest('ul').siblings('input:checkbox').attr('checked', true);
                $(this).closest('ul').siblings('input:checkbox').prop("indeterminate", true);
            }
        }

    } else {
        $(this).val("False");
        $(this).siblings('ul').find(':checkbox').prop('checked', this.checked);
        if ($(this).closest('ul').find(':checkbox:checked').length != $(this).closest('ul').find(':checkbox').length) {
            $(this).closest('ul').siblings('input:checkbox').attr('checked', false);
            /*********** It checks whether there is parent if so if all is unchecked then  visual intermediate is made false ********/
            if ($(this).closest('ul').find(':checkbox:checked').length == 0) {
                $(this).closest('ul').siblings('input:checkbox').prop("indeterminate", false);
            }
        }
    }

    if ($('#roleMenuList').find(':checkbox:checked').length == $('#roleMenuList').find(':checkbox').length) {
        /****As all siblings checkboxes are checked so intermediate state is made false and checked state true****/
        $("#roleCheckAll").prop("indeterminate", false);
        $('#roleCheckAll').prop('checked', true);
    }
    else {
        /****If any checkbox checked then check all goes in intermediate state****/
        if ($('#roleMenuList').find(':checkbox:checked').length > 0) {
            $("#roleCheckAll").prop("indeterminate", true);
        }
        else {
            $("#roleCheckAll").prop("indeterminate", false);
        }
        $('#roleCheckAll').prop('checked', false);
    }
});

$("#btnRoleReset").on('click', function () {
    $("#ddlRole").val("0");
    BindMapRoleMenu();
});



$("#btnRoleSubmit").on('click', function () {
    if ($("#ddlRole").val() == "0") {
        $("#alertdiv").removeClass().addClass("alert alert-danger");
        $("#alertstrong").text("Error!");
        $("#alertmsg").text("Please Select Role");
        $("#alertModal").modal('show');
    }
    else {
        var data = { RoleID: $("#ddlRole").val() };

        $('#roleMenuList').find(':checkbox').each(function (index, item) {
            if ($(this).is(":checked")) {
                data['myDictionary[' + index + '].Key'] = $(this).attr("id").replace("chk", "");
                data['myDictionary[' + index + '].Value'] = true;

            }
            else {
                data['myDictionary[' + index + '].Key'] = $(this).attr("id").replace("chk", "");
                data['myDictionary[' + index + '].Value'] = $(this).val() == "True" ? true : false;
            }
        });
        $.ajax({
            url: window.rootUrl + 'Administration/Privilege/InsertUpdateMapMenuRole', //'@Url.Action("InsertUpdateMapMenuRole", "Privilege")',
            type: 'POST',
            traditional: true,
            dataType: 'text',
            data: data,
            success: function (result) {
                $("#rolePlaceHolder").html(result);
                $("#alertdiv").removeClass().addClass("alert alert-success");
                $("#alertstrong").text("Success!");
                $("#alertmsg").text("Role Privilege Updated");
                $("#alertModal").modal('show');
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                } else {
                    $("#alertdiv").removeClass().addClass("alert alert-danger");
                    $("#alertstrong").text("Error!");
                    $("#alertmsg").text(xhr.statusText);
                    $("#alertModal").modal('show');
                }
            }
        }).done(function () {
            $('#roleMenuList').treed({ openedClass: 'glyphicon-chevron-right', closedClass: 'glyphicon-chevron-down', initialState: 'expanded' });
            if ($('#roleMenuList').find(':checkbox:checked').length == $('#roleMenuList').find(':checkbox').length) {
                $('#roleCheckAll').prop('checked', true);
            }
        });
    }
});




