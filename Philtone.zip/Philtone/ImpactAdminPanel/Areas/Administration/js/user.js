﻿
// popluate dropdown of role based on departmentid
function FillRoleBasedonDepartmentID() {
    var DepartmentID = $('#user_DepartmentID').val();
    if (DepartmentID > 0) {
        $.ajax({
            url: window.rootUrl + 'Administration/User/FillRoleBasedOnDepartmentID',
            type: "GET",
            async: true,
            dataType: "json",
            data: { DepartmentID: DepartmentID },
            success: function (data) {
                $("#user_RoleID").html(""); // clear before appending new list 
                $("#user_RoleID").empty().append('<option selected="selected" value="0">Select Role</option>');
                $.each(data, function (i, item) {
                    $("#user_RoleID").append($('<option></option>').val(item.RoleID).html(item.RoleName));
                });
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    else {
        $("#user_RoleID").empty().append('<option selected="selected" value="0">Select Role</option>');
    }
}


//It is return all city list against the country Id, and then filteration for autocomplete search is done using the CityName paramerter
$(function () {
    $('#user_CityName').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetCityListByCountryID',
            data: "{ 'CityName': '" + $('#user_CityName').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="citylist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.CityID + '>' + item.CityName + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocomplete').show();
                $('#divautocomplete').html(val);

                $('#citylist li').click(function () {
                    $('#user_CityName').val($(this).text());
                    $('#user_CityID').val($(this).attr('id'));
                    $('#divautocomplete').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocomplete");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

//It is return all State list against the country Id, and then filteration for autocomplete search is done using the StateName paramerter
$(function () {
    $('#user_StateName').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetStateListByCountryID',
            data: "{ 'StateName': '" + $('#user_StateName').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="Statelist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.StateID + '>' + item.StateName + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocompletestate').show();
                $('#divautocompletestate').html(val);

                $('#Statelist li').click(function () {
                    $('#user_StateName').val($(this).text());
                    $('#user_StateID').val($(this).attr('id'));
                    $('#divautocompletestate').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocompletestate");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

//It is return all Postcode list against the country Id, and then filteration for autocomplete search is done using the PostCode paramerter
$(function () {
    $('#user_Postcode').keyup(function () {
        $.ajax({
            url: window.rootUrl + 'Administration/User/GetPostCodeListByCountryID',
            data: "{ 'PostCode': '" + $('#user_Postcode').val() + "','CountryID':'" + $('#user_CountryID').val() + "'}",
            dataType: "json",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                var val = '<ul id="Postcodelist" style="list-style: none; margin-left: -19px;font-weight:bold">';
                $.map(data, function (item) {
                    val += '<li id=' + item.PostcodeId + '>' + item.Postcode + '</li>'
                    return item;
                })
                val += '</ul>'
                $('#divautocompletepostcode').show();
                $('#divautocompletepostcode').html(val);

                $('#Postcodelist li').click(function () {
                    $('#user_Postcode').val($(this).text());
                    $('#user_PostcodeId').val($(this).attr('id'));
                    $('#divautocompletepostcode').hide();
                })
            },
            error: function (response) {
                alert(response.responseText);
            }
        });
    })
    $(document).mouseup(function (e) {
        var closediv = $("#divautocompletepostcode");
        if (closediv.has(e.target).length == 0) {
            closediv.hide();
        }
    });
});

function ClearFieldsOnChange() {
    $('#user_CityName').val('');
    $('#user_CityID').val('0');
    $("#divautocomplete").html("");

    $('#user_StateName').val('');
    $('#user_StateID').val('0');
    $("#divautocompletestate").html("");

    $('#user_Postcode').val('');
    $('#user_PostcodeId').val('0');
    $("#divautocompletepostcode").html("");
}