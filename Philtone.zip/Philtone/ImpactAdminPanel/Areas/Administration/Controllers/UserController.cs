﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Entity.Administration;
using ServiceLayer.ViewModel.Administration;
using ServiceLayer.Repository.Administration;
using ImpactAdminPanel.Helper;


namespace ImpactAdminPanel.Areas.Administration.Controllers
{
    public class UserController : BaseController
    {
        UserRepository oUserRepository;

        public UserController()
        {
            oUserRepository = new UserRepository();
        }

        /// <summary>
        /// User Listing Populate with paging and Sorting and Search based on  username, department, role and designation
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <param name="SearchUserName"></param>
        /// <param name="DepartmentID"></param>
        /// <param name="RoleID"></param>
        /// <param name="DesignationID"></param>
        /// <returns></returns>
        public ActionResult Index(int? page, int? pagesize, string sortBy, bool ascending = true, string SearchUserName = null, string DepartmentID = null, string RoleID = null, string DesignationID = null)
        {
            var result = oUserRepository.GetUserList(page, pagesize, sortBy, ascending, SearchUserName, DepartmentID, RoleID, DesignationID);
            return View(result);
        }
        /// <summary>
        /// When click on add new user viewModel fill all the related infomation dropdown in Model
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Create()
        {
            UserViewModel ouser = new UserViewModel();
            ouser.CountryList = oUserRepository.GetCountryList();
            ouser.DepartmentList = oUserRepository.GetDepartmentList();          
            return View(ouser);
        }

        [HttpPost]
        public ActionResult Create(UserViewModel userViewModel)
        {
            userViewModel.CountryList = oUserRepository.GetCountryList();
            userViewModel.DepartmentList = oUserRepository.GetDepartmentList();
            if (ModelState.IsValid)
            {
                // Attempt to register the user
                try
                {
                    //User userDetail = new User();
                    //userDetail.LoginName = userViewModel.user.LoginName;
                    //userDetail.LoginPassword = userViewModel.user.LoginPassword;
                    //userDetail.EmailAddress = userViewModel.user.EmailAddress;
                    //userDetail.DepartmentID = Convert.ToInt32(userViewModel.user.DepartmentID);
                    //userDetail.RoleID = Convert.ToInt32(userViewModel.user.RoleID);
                    //userDetail.Phonenumber = userViewModel.user.Phonenumber;
                    //userDetail.DOJ = userViewModel.user.DOJ;
                    //userDetail.Firstname = userViewModel.user.Firstname;
                    //userDetail.Lastname = userViewModel.user.Lastname;
                    //userDetail.PersonalEmail = userViewModel.user.PersonalEmail;
                    //userDetail.PersonalContactNumber = userViewModel.user.PersonalContactNumber;
                    //userDetail.DOB = userViewModel.user.DOB;
                    //userDetail.GuardianName = userViewModel.user.GuardianName;
                    //userDetail.GuardianContact = userViewModel.user.GuardianContact;
                    //userDetail.EmergencyContact = userViewModel.user.EmergencyContact;
                    //userDetail.Address = userViewModel.user.Address;
                    //userDetail.Gender = userViewModel.user.Gender;
                    //userDetail.CountryID = Convert.ToInt32(userViewModel.user.CountryID);
                    //userDetail.CityName = userViewModel.user.CityName;
                    //userDetail.StateName = userViewModel.user.StateName;
                    //userDetail.Postcode = userViewModel.user.Postcode;
                    //userDetail.Notes = userViewModel.user.Notes;                   
                    var result = oUserRepository.InsertUser(userViewModel, CurrentUser.UserID);
                    ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
                    ViewBag.Message = result.ReturnMessage;

                }
                catch (Exception ex)
                {
                    ViewBag.MessageType = MessageType.Error;
                    ModelState.AddModelError("", ex.Message);
                }
            }
            else
            {
                ViewBag.MessageType = MessageType.Error;               
            }
           
            return View(userViewModel);
        }

        /// <summary>
        /// pouplate role based on departmentId
        /// </summary>
        /// <param name="DepartmentID"></param>
        /// <returns></returns>
        public ActionResult FillRoleBasedOnDepartmentID(int DepartmentID)
        {
          var UserRoles = oUserRepository.GetRoleListByDepartmentId(DepartmentID).ToList();
          return Json(UserRoles, JsonRequestBehavior.AllowGet);
        }

        /// <summary>        
        /// It is return all city list against the country Id, and then filteration for autocomplete search is done using the CityName paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <param name="CityName"></param>
        /// <returns></returns>
        public ActionResult GetCityListByCountryID(string CountryID, string CityName)
        {
          var GetCity = oUserRepository.GetCityListByCountryID(Convert.ToInt32(CountryID), CityName);
          return Json(GetCity, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// It is return all state list against the country Id, and then filteration for autocomplete search is done using the StateName paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <param name="StateName"></param>
        /// <returns></returns>
        public ActionResult GetStateListByCountryID(string CountryID, string StateName)
        {
          var GetState = oUserRepository.GetStateListByCountryID(Convert.ToInt32(CountryID), StateName);
          return Json(GetState, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// It is return all postcode list against the country Id, and then filteration for autocomplete search is done using the Postcode  paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <param name="PostCode"></param>
        /// <returns></returns>
        public ActionResult GetPostCodeListByCountryID(string CountryID, string PostCode)
        {
          var GetPostcode = oUserRepository.GetPostCodeListByCountryID(Convert.ToInt32(CountryID), PostCode);
          return Json(GetPostcode, JsonRequestBehavior.AllowGet);
        }


       
        /// <summary>
        /// Edit the user based on UserID
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public ActionResult Edit(int UserID)
        {         
           UserViewModel ouser = oUserRepository.GetUserById(UserID);           
           return View(ouser);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(UserViewModel users)
        {
            try
            {
                var result = oUserRepository.UpdateUser(users, CurrentUser.UserID);
                ViewBag.MessageType = result.ReturnValue == 2 ? MessageType.Success : MessageType.Error;
                ViewBag.Message = result.ReturnMessage;               
                users = oUserRepository.GetUserById(users.user.UserID);
            }
            catch (Exception ex)
            {
                ViewBag.MessageType = MessageType.Error;
                ModelState.AddModelError("", ex.Message);
            }
            return View(users);
        }

        /// <summary>
        /// Dispose all th object of UserRepository
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            oUserRepository.Dispose();           
            base.Dispose(disposing);
        }
    }
}
