﻿using ImpactAdminPanel.Controllers;
using ImpactAdminPanel.Helper;
using ServiceLayer.Entity.Administration;
using ServiceLayer.Repository.Administration;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ImpactAdminPanel.Areas.Administration.Controllers
{
    public class RoleController : BaseController
    {
        RoleRepository oRoleRepository;
        public RoleController()
        {
            oRoleRepository = new RoleRepository();
        }

        /// <summary>
        /// <Get all Role in List with paging and Search Based on RoleName>
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        ///       
        public ActionResult Index(int? page, int? pagesize, string sortBy, bool ascending = true, string SearchRoleName = null)
        {
            var result = oRoleRepository.GetRoleList(page, pagesize, sortBy, ascending, SearchRoleName);
            return View(result);
        }

        /// <summary>
        /// Action On Create new Button for Creating Role
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            RoleViewModel roleViewModel = new RoleViewModel();
            roleViewModel.DepartmentList = oRoleRepository.GetDepartmentLists();
            return View(roleViewModel);
        }

        /// <summary>
        /// <Create new Role>
        /// </summary>
        /// <param name="oRole"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(RoleViewModel roleViewModel)
        {
            roleViewModel.DepartmentList = oRoleRepository.GetDepartmentLists();
            if (ModelState.IsValid)
            {
                    try
                    {
                        Role oRole = new Role();
                        oRole.DepartmentID = roleViewModel.role.DepartmentID;
                        oRole.RoleName = roleViewModel.role.RoleName;
                        roleViewModel.role.CreatedBy = CurrentUser.UserID;
                        var result = oRoleRepository.InsertRole(roleViewModel);
                        ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
                        ViewBag.Message = result.ReturnMessage;
                    }
                   catch (Exception exc)
                    {
                        ViewBag.MessageType = MessageType.Error;
                        ModelState.AddModelError("", exc.Message);
                    }
             }
             else
             {
                ViewBag.MessageType = MessageType.Error;
             }
            return View(roleViewModel);
         }

        /// <summary>
        /// <populate role information based on RoleID>
        /// </summary>
        /// <param name="RoleId"></param>
        /// <returns></returns>
        /// 
        public ActionResult Edit(int RoleID)
        {
            RoleViewModel roleViewModel = new RoleViewModel();           
            roleViewModel = oRoleRepository.GetRoleDetailByID(RoleID);
            return View(roleViewModel);
        }

        /// <summary>
        /// <update role information based on RoleID>
        /// </summary>
        /// <param name="roleViewModal"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(RoleViewModel roleViewModel)
        {
            roleViewModel.DepartmentList = oRoleRepository.GetDepartmentLists();
            if (ModelState.IsValid)
            {
                try
                {
                    roleViewModel.role.ModifiedBy = CurrentUser.UserID;
                    var result = oRoleRepository.UpdateRole(roleViewModel);
                    ViewBag.MessageType = result.ReturnValue == 2 ? MessageType.Success : MessageType.Error;
                    ViewBag.Message = result.ReturnMessage;
                }
                catch (Exception exc)
                {
                    ViewBag.MessageType = MessageType.Error;
                    ModelState.AddModelError("", exc.Message);
                }

            }
            else
            {
                ViewBag.MessageType = MessageType.Error;
            }
            return View(roleViewModel);
        }


        /// <summary>
        /// <Dispose all>
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            oRoleRepository.Dispose();
            base.Dispose(disposing);
        }
    }
}
