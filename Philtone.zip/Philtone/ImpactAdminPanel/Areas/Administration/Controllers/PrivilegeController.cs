﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Repository.Administration;
using ServiceLayer.ViewModel.Administration;

namespace ImpactAdminPanel.Areas.Administration.Controllers
{
    public class PrivilegeController : BaseController
    {
        
        // GET: /Administration/Privilege/
        PrivilegeRepository oPrivilegeRepository;       
        public PrivilegeController()
        {

            oPrivilegeRepository = new PrivilegeRepository();
        }
        public ActionResult Index()
        {
            PrivilegeViewModel oPrivilegeViewModel = new PrivilegeViewModel();
            oPrivilegeViewModel.MapMenuRoleViewModel = oPrivilegeRepository.GetRoleMenuList(0);
            oPrivilegeViewModel.MapMenuUserViewModel = oPrivilegeRepository.GetUserMenuList(0);
            return View(oPrivilegeViewModel);
        }

        [HttpPost]
        public ActionResult GetMapMenuRole(int RoleID)
        {

            var result = oPrivilegeRepository.GetRoleMenuList(RoleID);
            return PartialView("_MapMenuRole", result);
        }

        [HttpPost]
        public ActionResult InsertUpdateMapMenuRole(Dictionary<int, bool> myDictionary, int RoleID)
        {
            var result = oPrivilegeRepository.InsertUpdateRoleMapMenu(myDictionary, RoleID);
            if (result.ReturnValue == 0)
            {
                return new HttpStatusCodeResult(911, result.ReturnMessage);
            }
            else
            {
                return PartialView("_MapMenuRole", oPrivilegeRepository.GetRoleMenuList(RoleID));
            }
        }

        [HttpPost]
        public ActionResult GetMapMenuUser(int UserID)
        {

            var result = oPrivilegeRepository.GetUserMenuList(UserID);
            return PartialView("_MapMenuUser", result);
        }

        [HttpPost]
        public ActionResult InsertUpdateMapMenuUser(Dictionary<int, bool> myDictionary, int UserID)
        {
            var result = oPrivilegeRepository.InsertUpdateUserMapMenu(myDictionary, UserID);
            if (result.ReturnValue == 0)
            {
                return new HttpStatusCodeResult(911, result.ReturnMessage);
            }
            else
            {
                return PartialView("_MapMenuUser", oPrivilegeRepository.GetUserMenuList(UserID));
            }
        }
        /// <summary>
        /// Dispose all the oPrivilegeRepository object
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {  
            oPrivilegeRepository.Dispose();
            base.Dispose(disposing);
        }

    }
}
