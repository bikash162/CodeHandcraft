﻿using System.Web.Mvc;
using System.Web.Http;
using ImpactAdminPanel.Models;

namespace ImpactAdminPanel.Areas.Administration
{
    public class AdministrationAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Administration";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {

            context.MapRoute(
            name: "Administration_parent",
            url: "Administration/{parent}/{controller}/{action}/{id}",
            defaults: new
            {
                parent = RouteParameter.Optional,
                id = UrlParameter.Optional,
                action = "Index"
            },
            constraints: new { parent = new ControllerNameConstraint() }
           );
            context.MapRoute(
                 name: "Administration_default",
                 url: "Administration/{controller}/{action}/{id}",
                defaults: new { action = "Index", id = UrlParameter.Optional }

            );

        }
    }
}
