﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Web.Services;

namespace ImpactAdminPanel.Helper
{
    public enum MessageType
    {
        Information,
        Warning,
        Error,
        Success,
        Clear
    }


    /// <summary>
    /// Location Root/Controller/RazorHelper
    /// </summary>
    public static class CustomHelper
    {
        /// <summary>
        /// It displays the Alert message based on Enum Type it can raised from both razor and c#
        /// </summary>
        /// <param name="content"></param>
        /// <param name="messageType"></param>
        /// <returns></returns>
        public static MvcHtmlString AlertMessage(string content, MessageType messageType)
        {
            var ulMsg = new TagBuilder("div");
            switch (messageType)
            {
                case MessageType.Information:
                    ulMsg.MergeAttribute("class", "alert alert-info fade in");
                    break;
                case MessageType.Error:
                    ulMsg.MergeAttribute("class", "alert alert-danger fade in");
                    break;
                case MessageType.Warning:
                    ulMsg.MergeAttribute("class", "alert alert-warning fade in");
                    break;
                case MessageType.Success:
                    ulMsg.MergeAttribute("class", "alert alert-success fade in");
                    break;
                case MessageType.Clear:
                    ulMsg.MergeAttribute("class", "");
                    break;
            }
            var sb = new StringBuilder();
            sb.Append("<a id=\"aclose\" class=\"close\" data-dismiss=\"alert\" href=\"#\">×</a>");
            sb.AppendFormat("<p>{0}</p>", content);
            ulMsg.InnerHtml = sb.ToString();
            return MvcHtmlString.Create(ulMsg.ToString(TagRenderMode.Normal));
        }
        /// <summary>
        /// It encodes the Paremeter to custom encryption defined in CommonHelper class
        /// </summary>
        /// <param name="Parameter">it is used dynamic as datatype can be anything</param>
        /// <returns></returns>
        public static string ParamEncode(dynamic Parameter)
        {
            return ServiceLayer.Utitlity.CommonHelper.Encrypt(Convert.ToString(Parameter));
        }
        /// <summary>
        /// It decodes the encrypted parameter value
        /// </summary>
        /// <param name="Parameter"></param>
        /// <returns></returns>
        public static T DecryptParameter<T>(string Parameter)
        {
            return (T)Convert.ChangeType(ServiceLayer.Utitlity.CommonHelper.Decrypt(Parameter), typeof(T));
        }


        /// <summary>
        /// <This method is used to Sort Columns for the tables>
        /// </summary>
        /// <param name="ColumnName"></param>
        /// <param name="TableName"></param>
        /// <param name="FormName"></param>
        /// <param name="ActionName"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="CssClass"></param>
        /// <returns></returns>
        public static MvcHtmlString SortingColumnName(string ColumnName, string TableName, string FormName, string ActionName, string sortBy, string ascending, string page, string pagesize, string DisplayName)
        {
            string strSpan = string.Empty;
            try
            {
                strSpan = "<span id=" + ColumnName + " style=cursor:pointer class=sort onclick=Click_PaginationAjax(" + "'" + TableName + "','" + FormName + "','" + ActionName + "?sortBy=" + sortBy + "&ascending=" + ascending + "&page=" + page + "&pagesize=" + pagesize + "&isColumnClick=true')" + ">" + DisplayName + "</span>";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return MvcHtmlString.Create(strSpan);
        }


        /// <summary>
        /// <Modal popup message will be displayed after actions like Insert update delete operations>
        /// </summary>
        /// <returns></returns>
        public static MvcHtmlString alertModalMessage()
        {
            var ulMsg = new TagBuilder("div");
            ulMsg.MergeAttribute("class", "modal modal-success fade in");
            ulMsg.MergeAttribute("id", "alertModal");
            ulMsg.MergeAttribute("role", "dialog");

            var sb = new StringBuilder();
            sb.Append("<div class='modal-dialog'>");
            sb.Append("<div id='alertdiv' class='alert alert-success' style='margin-top: 40%;'>");
            sb.Append("<a href='#' class='close' data-dismiss='modal' aria-label='close'>&times;</a>");
            sb.Append("<strong id='alertstrong'>Success!</strong>&nbsp;&nbsp;<span id='alertmsg'>Indicates a successful or positive action.</span>");
            sb.Append("</div>");
            sb.Append("</div>");
            sb.Append("</div>");
            ulMsg.InnerHtml = sb.ToString();
            return MvcHtmlString.Create(ulMsg.ToString(TagRenderMode.Normal));
        }
    }
}