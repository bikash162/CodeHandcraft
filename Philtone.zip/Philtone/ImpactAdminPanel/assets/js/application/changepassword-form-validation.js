﻿var ChangePasswordFormValidation = function () {

    var handlePasswordFormValidation = function () {
        $("#password-form-change").validate({
            rules: {
                "txtNewPassword": {
                    required: true,
                    minlength: 5
                }, "txtConfirmPassword": {
                    required: true,
                    minlength: 5,
                    equalTo: "#txtNewPassword"
                }

            },
            messages: {
                "txtNewPassword": {
                    required: 'Enter New Password'
                }, "txtConfirmPassword": {
                    required: 'Enter Confirm Password'
                }
            },

            submitHandler: function () {
                myApp.showPleaseWait();
                handleChangePassword();
            }
        });
    }

    var handleChangePassword = function () {
        $("#button-password-yes").attr("disabled", true);
        $("#button-password-yes").text("In Progress");
        var pwd = $("#txtNewPassword").val();
        $.ajax({
            url: window.rootUrl + 'Home/ChangePassword',
            data: { Password: pwd },
            cache: false,
            type: 'POST',
            dataType: 'json',
            success: function (data) {
                
                if (data.ReturnValue == 1) {
                    $("#modal-change-password").modal('hide');
                    $("#alertdiv").removeClass().addClass("alert alert-success");
                    $("#alertstrong").text("Success!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                }
                else {
                    $("#lblChangePassword").removeClass().addClass("label label-danger");
                    $("#lblChangePassword").text(data.ReturnMessage);
                }
                $("#button-password-yes").text("Submit");
                $("#button-password-yes").attr("disabled", false);
                return;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        }).done(function () {
            myApp.hidePleaseWait();
        });
    }
    var handleOpenPopup = function () {
        $(".menu-password").click(function () {
            myForm.Clear('password-form-change');
            $("#lblChangePassword").removeClass().text("");
        });
    }
    return {
        //main function to initiate the module
        init: function () {
            handlePasswordFormValidation();
            handleOpenPopup();
        }
    }
}();


