﻿
function Click_Pagination(tableid, formid, uri) {

    myApp.showPleaseWait();
    var url = uri;
    $('#' + formid).attr('action', url).submit();
    return false;

}