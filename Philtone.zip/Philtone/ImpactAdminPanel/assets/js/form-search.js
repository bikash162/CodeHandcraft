﻿
// When search button is clicked its corresponding hidden field value is set to true, this function needs to be referred to the search button click,
// In parameter hidden field id should be passed hard coded 
function search_Clicked(hiddenField) {
    $("#" + hiddenField).val("True");
}
// When anything is typed but search button is not clicked it will clear IsSearchClick flag, it is mainly used in onblur function of input box and
// onchange function of combox/dropdownlist etc
function search_NotClicked(hiddenField) {
    $("#" + hiddenField).val("");
}

  
