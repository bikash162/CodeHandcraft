﻿//modal-center.css is used
var myApp;
myApp = myApp || (function () {
    // var pleaseWaitDiv = $('<div class="modal fade" id="myModal" role="dialog"><div class="modal-dialog"><!-- Modal content--><div class="modal-content"><div class="modal-header"><h4 class="modal-title">Processing...</h4></div><div class="modal-body"><div class="progress"><div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:80%"></div></div></div></div></div>');
    var pleaseWaitDiv = $('<div class="modal-center modal fade" id="please-wait-modal" role="dialog" style="z-index: 10000000 !important;"><div class="modal-center-dialog modal-dialog"><!-- Modal content--><div class="loader"></div><br/><span class="loader-text">Please wait...</span></div></div>');
    return {
        showPleaseWait: function() {
            pleaseWaitDiv.modal();
        },
        hidePleaseWait: function () {
            pleaseWaitDiv.modal('hide');
        },

    };
})();