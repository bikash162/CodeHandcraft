﻿using ImpactAdminPanel.Controllers;
using ImpactAdminPanel.Helper;
using ImpactAdminPanel.Models.Customer;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Repository.Customers;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ImpactAdminPanel.Controllers
{
  public class CustomerController : BaseController
    {
      CustomerRepository oCustomerRepository;
      CustomerContactsRepository oCustomerContactsRepository;

      public CustomerController()
      {
        oCustomerRepository = new CustomerRepository();
        oCustomerContactsRepository = new CustomerContactsRepository();
      }

      /// <summary>
      /// <Customer list will populated in grid and sorting in asc and desc order and search based on Customername>
      /// </summary>
      /// <param name="page"></param>
      /// <param name="pagesize"></param>
      /// <param name="sortBy"></param>
      /// <param name="ascending"></param>
      /// <param name="SearchCustomerName"></param>
      /// <returns></returns>
      public ActionResult Index(int? page, int? pagesize, string sortBy, bool ascending = true, string SearchCustomerName = null, string SearchPhoneNumber = null, string SearchEmailAddress = null)
      {
        try
        {
          var result = oCustomerRepository.GetCustomerList(page, pagesize, sortBy, ascending, SearchCustomerName, SearchPhoneNumber, SearchEmailAddress);
          return View(result);
        }
        catch (Exception ex)
        {

          throw ex;
        }
      }

      /// <summary>
      /// 
      /// </summary>
      /// <returns></returns>
      public ActionResult Create()
      {
        CustomerViewModel customerViewModel = new CustomerViewModel();
        customerViewModel.CountryList = oCustomerRepository.GetCountryList();
        return View(customerViewModel);
      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="CountryID"></param>
      /// <returns></returns>
      public ActionResult FillCityBasedOnCountryID(int CountryID)
      {
        var GetCity = oCustomerRepository.GetCityList(CountryID).ToList();
        return Json(GetCity, JsonRequestBehavior.AllowGet);
      }



      /// <summary>
      /// 
      /// </summary>
      /// <param name="customerViewModel"></param>
      /// <returns></returns>
      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Create(CustomerViewModel customerViewModel)
      {
          customerViewModel.CountryList = oCustomerRepository.GetCountryList();
          if (ModelState.IsValid)
          {
              try
              {
                    customerViewModel.Customer.CreatedBy = CurrentUser.UserID;
                    var result = oCustomerRepository.InsertCustomer(customerViewModel);
                     ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
                     ViewBag.Message = result.ReturnMessage;
              }
              catch (Exception exc)
              {
                  ViewBag.MessageType = MessageType.Error;
                  ModelState.AddModelError("", exc.Message);
              }
          }
          else
          {
              ViewBag.MessageType = MessageType.Error;
          }
          return View(customerViewModel);
      }


      /// <summary>
      /// <Get Customer information to populate>
      /// </summary>
      /// <param name="CustomerID"></param>
      /// <param name="page"></param>
      /// <param name="pagesize"></param>
      /// <param name="sortBy"></param>
      /// <param name="ascending"></param>
      /// <returns></returns>
      public ActionResult Edit(string CustomerID, int? page, int? pagesize, string sortBy = null, bool ascending = true)
      {
        try
        {
          
          int CountryID = 0;
          CustomerViewModel CustomerViewModel = new CustomerViewModel();
          CustomerViewModel.Customer = oCustomerRepository.GetCustomerByID(Convert.ToInt64(CustomerID));
          CustomerViewModel.CustomerContactsViewModel = oCustomerContactsRepository.GetCustomerContactList(Convert.ToInt64(CustomerID), page, pagesize, sortBy, ascending);
          ///<Picking country id to populate city based on country id>
          try
          {
            CountryID = Convert.ToInt32(CustomerViewModel.Customer.CountryId);
          }
          catch
          {
            CountryID = 0;
          }
          
          CustomerViewModel.CountryList = oCustomerRepository.GetCountryList();
          CustomerViewModel.CityList = oCustomerRepository.GetCityList(Convert.ToInt32(CountryID)); 

          return View(CustomerViewModel);
        }
        catch (Exception ex)
        {
          throw ex;
        }

      }

      /// <summary>
      /// <this method is used to populate the popup of contacts in customers list contacts icon click>
      /// </summary>
      /// <param name="CustomerID"></param>
      /// <param name="page"></param>
      /// <param name="pagesize"></param>
      /// <param name="sortBy"></param>
      /// <param name="ascending"></param>
      /// <returns></returns>
      public ActionResult GetCustomerContactList(long CustomerID, int? page, int? pagesize, string sortBy, bool ascending = true)
      {
        CustomerViewModel CustomerViewModel = new CustomerViewModel();
        CustomerViewModel.CustomerContactsViewModel = oCustomerContactsRepository.GetCustomerContactList(Convert.ToInt64(CustomerID), page, pagesize, sortBy, ascending);
        //return View(CustomerViewModel);

        return PartialView("~/Views/Shared/Customer/_CustomerContactsList.cshtml", CustomerViewModel);
      }


      /// <summary>
      /// <update Customer informaton>
      /// </summary>
      /// <param name="oCustomer"></param>
      /// <returns></returns>
      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Edit(CustomerViewModel customerViewModel)
      {
        string Returndata = string.Empty;
        int result = 0;
        int CountryID = 0;
        
        try
        {

            customerViewModel.Customer.ModifiedBy = CurrentUser.UserID;
            result = oCustomerRepository.UpdateCustomer(customerViewModel, out Returndata);
            ViewBag.Message = Returndata;
            ViewBag.MessageType = result == 1 ? MessageType.Success : MessageType.Error;

            ///<This viewmodel is used to stay with data on the page after save with customer id>
            CustomerViewModel customerViewModelNew = new CustomerViewModel();

            customerViewModelNew.Customer = oCustomerRepository.GetCustomerByID(Convert.ToInt64(customerViewModel.Customer.CustomerID));
            customerViewModelNew.CustomerContactsViewModel = oCustomerContactsRepository.GetCustomerContactList(Convert.ToInt64(customerViewModel.Customer.CustomerID), null, null, null, true);

            ///<Picking country id to populate city based on country id>
            try
            {
              CountryID = Convert.ToInt32(customerViewModelNew.Customer.CountryId);
            }
            catch
            {
              CountryID = 0;
            }

            customerViewModelNew.CountryList = oCustomerRepository.GetCountryList();
            customerViewModelNew.CityList = oCustomerRepository.GetCityList(Convert.ToInt32(CountryID));

            return View(customerViewModelNew);
        }
        catch (Exception ex)
        {
          throw ex;
        }

      }


      /// <summary>
      /// <Insert new Customer user>
      /// </summary>
      /// <param name="CustomerUser"></param>
      /// <returns></returns>
      //public JsonResult InsertCustomerContact(CustomerContacts CustomerContacts)
      //{
      //  CustomerContacts.CreatedBy = CurrentUser.UserID;
      //  return Json(oCustomerContactsRepository.InsertCustomerContact(CustomerContacts), JsonRequestBehavior.AllowGet);
      //}

      /// <summary>
      /// <Get Customer information based on CustomerUserID>
      /// </summary>
      /// <param name="CustomerUserID"></param>
      /// <returns></returns>
      public ActionResult GetCustomerContactByID(string CustomerContactID)
      {
        var CustomerUser = oCustomerContactsRepository.GetCustomerContactByID(Convert.ToInt64(CustomerContactID));
        return Json(CustomerUser, JsonRequestBehavior.AllowGet);
      }


      /// <summary>
      /// <Update Customer information based on CustomerUserID>
      /// </summary>
      /// <param name="CustomerUser"></param>
      /// <returns></returns>
      //public JsonResult UpdateCustomerContact(CustomerContacts CustomerUser)
      //{
      //  CustomerUser.ModifiedBy = CurrentUser.UserID;
      //  return Json(oCustomerContactsRepository.UpdateCustomerContact(CustomerUser), JsonRequestBehavior.AllowGet);
      //}

      /// <summary>
      /// <Insert and Update Customer Contact Detail>
      /// </summary>
      /// <param name="CustomerUser"></param>
      /// <returns></returns>
      public ActionResult AddEdit(FormCollection formCollection)
      {

        var result = CustomerContactValidation.AddEditCustomerContact(formCollection, oCustomerContactsRepository, CurrentUser.UserID);
        return Json(result, JsonRequestBehavior.AllowGet);
      }

      public JsonResult CheckCustomerContactUserNameExists(string UserName)
      {
        return Json(oCustomerContactsRepository.CheckCustomerContactUserNameExists(UserName), JsonRequestBehavior.AllowGet);
      }


      public JsonResult CreatePassword()
      {
        string allowedChars = "";
        allowedChars = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";
        //allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
        allowedChars += "1,2,3,4,5,6,7,8,9,0,!,@,#,$,%,&,?";
        char[] sep = { ',' };
        string[] arr = allowedChars.Split(sep);
        string passwordString = "";
        string temp = "";
        Random rand = new Random();
        for (int i = 0; i < 6; i++)
        {
          temp = arr[rand.Next(0, arr.Length)];
          passwordString += temp;
        }
        return Json(passwordString, JsonRequestBehavior.AllowGet);
      }


      protected override void Dispose(bool disposing)
      {
        oCustomerRepository.Dispose();
        oCustomerContactsRepository.Dispose();
        base.Dispose(disposing);
      }


    }
}
