﻿using ImpactAdminPanel.Controllers;
using ImpactAdminPanel.Helper;
using ServiceLayer.Entity.Jobs;
using ServiceLayer.Repository.Jobs;
using ServiceLayer.Repository.Customers;
using ServiceLayer.Repository.Administration;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Jobs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace ImpactAdminPanel.Controllers
{
    public class JobController : BaseController
    {
      JobRepository oJobRepository;
      CustomerRepository oCustomerRepository;
      CustomerContactsRepository oCustomerContactsRepository;
      UserRepository oUserRepository;

      public JobController()
      {
        oJobRepository = new JobRepository();
        oCustomerRepository = new CustomerRepository();
        oCustomerContactsRepository = new CustomerContactsRepository();
        oUserRepository = new UserRepository();
      }

      public ActionResult Index(int? page, int? pagesize, string sortBy, bool ascending = false, string CustomerName = null, int Status = 0, string JobTitle = null, string JobCode = null)
      {
        try
        {
          var result = oJobRepository.GetJobsList(page, pagesize, sortBy, ascending, CustomerName, Status, JobTitle, JobCode);
          return View(result);
        }
        catch (Exception ex)
        {
          throw ex;
        }
      }

      public ActionResult Create()
      {
        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomersList = oCustomerRepository.GetAllCustomersList();
        oJobViewModel.UsersList = oUserRepository.GetAllUsersList();
        return View(oJobViewModel);
      }

      /// <summary>
      /// <this method is used to populate the Contacts list based on CustomerID at the time of job creation>
      /// </summary>
      /// <param name="CustomerID"></param>
      /// <returns></returns>
      //public ActionResult GetAllCustomerContactsByCustomerID(string CustomerID)
      //{
      //  JobViewModel oJobViewModel = new JobViewModel();
      //   oJobViewModel.CustomerContactsList = oCustomerContactsRepository.GetAllCustomerContactsByCustomerID(Convert.ToInt64(CustomerID));
      //   return View(oJobViewModel);
      //}

      public ActionResult GetAllCustomerContactsByCustomerID(string CustomerID)
      {
        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomerContactsList = oCustomerContactsRepository.GetAllCustomerContactsByCustomerID(Convert.ToInt64(CustomerID));
        return PartialView("~/Views/Shared/Job/_JobCustomerContacts.cshtml",oJobViewModel);
      }

      /// <summary>
      /// <Assigned contacts and assigned users are populated against a jobID>
      /// </summary>
      /// <param name="JobID"></param>
      /// <returns></returns>
      public ActionResult GetJobsAssignedCustomerContactsList(string JobID)
      {
        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomerContactsList = oJobRepository.GetJobsAssignedCustomerContactsList(Convert.ToInt64(JobID));
        oJobViewModel.UsersList = oJobRepository.GetJobsAssignedUsersList(Convert.ToInt64(JobID));
        return PartialView("~/Views/Shared/Job/_JobAssignedCustomerContacts.cshtml", oJobViewModel);
      }

      //public ActionResult GetJobsAssignedUsersList(string JobID)
      //{
      //  JobViewModel oJobViewModel = new JobViewModel();
      //  oJobViewModel.UsersList = oJobRepository.GetJobsAssignedUsersList(Convert.ToInt64(JobID));
      //  return PartialView("~/Views/Shared/Job/_JobAssignedUsers.cshtml", oJobViewModel);
      //}


      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Create(FormCollection formCollection)
      {

        if (ModelState.IsValid)
        {
          try
          {
            Job ojob = new Job();
            ojob.JobCode = Convert.ToString(formCollection["job.JobCode"]);
            ojob.JobTitle = Convert.ToString(formCollection["job.JobTitle"]);
            ojob.JobDescription = Convert.ToString(formCollection["job.JobDescription"]);
            ojob.CustomerID = Convert.ToInt64(formCollection["job.CustomerID"]);
            ojob.UserIDs = Convert.ToString(formCollection["chkUser"]);
            ojob.CustomerContactIDs = Convert.ToString(formCollection["chkCustomerContact"]);
            ojob.CreatedBy = CurrentUser.UserID;

            var result = oJobRepository.InsertJob(ojob);
            ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
            ViewBag.Message = result.ReturnMessage;
          }
          catch (Exception ex)
          {
            ViewBag.MessageType = MessageType.Error;
            ModelState.AddModelError("", ex.Message);
          }
        }
        else
        {
          ViewBag.MessageType = MessageType.Error;
        }

        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomersList = oCustomerRepository.GetAllCustomersList();
        oJobViewModel.UsersList = oUserRepository.GetAllUsersList();

        return View(oJobViewModel);
      }


      public ActionResult Edit(long JobID)
      {
        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomersList = oCustomerRepository.GetAllCustomersList();
        oJobViewModel.job = oJobRepository.GetJobInformationByID(JobID);
        oJobViewModel.UsersList = oJobRepository.GetJobsUsersList(JobID);
        oJobViewModel.CustomerContactsList = oJobRepository.GetJobsCustomerContactsList(JobID);
        return View(oJobViewModel);
      }

      [HttpPost]
      [ValidateAntiForgeryToken]
      public ActionResult Edit(FormCollection formCollection)
      {
        Job ojob = new Job();

        if (ModelState.IsValid)
        {
          try
          {
            ojob.JobID = Convert.ToInt64(formCollection["job.JobID"]);
            ojob.JobCode = Convert.ToString(formCollection["job.JobCode"]);
            ojob.JobTitle = Convert.ToString(formCollection["job.JobTitle"]);
            ojob.JobDescription = Convert.ToString(formCollection["job.JobDescription"]);
            ojob.UserIDs = Convert.ToString(formCollection["chkUser"]);
            ojob.CustomerContactIDs = Convert.ToString(formCollection["chkCustomerContact"]);
            ojob.ModifiedBy = CurrentUser.UserID;

            var result = oJobRepository.UpdateJob(ojob);
            ViewBag.MessageType = result.ReturnValue == 1 ? MessageType.Success : MessageType.Error;
            ViewBag.Message = result.ReturnMessage;
          }
          catch (Exception ex)
          {
            ViewBag.MessageType = MessageType.Error;
            ModelState.AddModelError("", ex.Message);
          }
        }
        else
        {
          ViewBag.MessageType = MessageType.Error;
        }

        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomersList = oCustomerRepository.GetAllCustomersList();
        oJobViewModel.job = oJobRepository.GetJobInformationByID(ojob.JobID);
        oJobViewModel.UsersList = oJobRepository.GetJobsUsersList(ojob.JobID);
        oJobViewModel.CustomerContactsList = oJobRepository.GetJobsCustomerContactsList(ojob.JobID);
        return View(oJobViewModel);
      }

      #region FileUpload

      /// <summary>
      /// <File Upload details>
      /// </summary>
      /// <param name="disposing"></param>
      public ActionResult JobFileUpload(long JobID)
      {
        JobViewModel oJobViewModel = new JobViewModel();
        oJobViewModel.CustomersList = oCustomerRepository.GetAllCustomersList();
        oJobViewModel.job = oJobRepository.GetJobInformationByID(JobID);
        oJobViewModel.UsersList = oJobRepository.GetJobsUsersList(JobID);
        oJobViewModel.CustomerContactsList = oJobRepository.GetJobsCustomerContactsList(JobID);
        return View(oJobViewModel);
      }

      //[HttpPost]
      //public ActionResult SaveFileUpload(long JobID, string FileUploadDescription, List<HttpPostedFileBase> file)
      //{
      //  string MessageLog = "";
      //  string SuccessLog = "";

      //  if (JobID <= 0)
      //  {
      //    ModelState.AddModelError("Job", "Job ID is Required!!");
      //  }

      //  if (file == null)
      //  {
      //    ModelState.AddModelError("file", "Please choose the file!!");
      //  }

      //  if (ModelState.IsValid == false)
      //  {
      //    var modelErrors = new List<string>();
      //    foreach (var modelState in ModelState.Values)
      //    {
      //      foreach (var modelError in modelState.Errors)
      //      {
      //        modelErrors.Add(modelError.ErrorMessage);
      //      }
      //    }
      //    return Json(new { modelErrors }, JsonRequestBehavior.AllowGet);
      //  }
      //  else
      //  {

      //    bool IsSuccess = true;
      //    string dateofcreation = DateTime.Now.ToString("yyyyMMdd").Replace("/", "");
      //    var FileExtensions = oFileSystemRepository.FileTypeList().ToList();

      //    string subFolder = Path.Combine(Server.MapPath("~/ZipFolder/"), dateofcreation);
      //    if (!Directory.Exists(subFolder))
      //    {
      //      Directory.CreateDirectory(subFolder);
      //    }

      //    string FileXml = "<Root>";
      //    string GetFileName = string.Empty;

      //    ///<Checking Total file sizes to posting>
      //    ///<if it exists 300mb then upload will be cancelled>
      //    int TotalFileSizetoPost = 0;
      //    foreach (HttpPostedFileBase postedFile in file)
      //    {
      //      TotalFileSizetoPost = TotalFileSizetoPost + postedFile.ContentLength;
      //    }

      //    if (TotalFileSizetoPost > 314572800)
      //    {
      //      MessageLog = " Total file size allowed 300 mb max.";
      //    }
      //    else
      //    {

      //      ServiceLayer.Entity.Master.FileUploadSettings oFileUploadSettings = new ServiceLayer.Entity.Master.FileUploadSettings();
      //      oFileUploadSettings = oFTPSettingRepository.GetFTPSetting().ftpSetting;
      //      if (oFileUploadSettings.Type == 1)
      //      {
      //        MessageLog = FTPUpload(file, dateofcreation, FileExtensions, NHS, FullName, out FileXml, out GetFileName, oFileUploadSettings, out IsSuccess);
      //      }
      //      if (oFileUploadSettings.Type == 2)
      //      {
      //        MessageLog = NetworkUpload(file, dateofcreation, FileExtensions, NHS, FullName, out FileXml, out GetFileName, oFileUploadSettings, out IsSuccess);
      //      }
      //      if (oFileUploadSettings.Type == 3)
      //      {
      //        MessageLog = LocalDriveUpload(file, dateofcreation, FileExtensions, NHS, FullName, out FileXml, out GetFileName, oFileUploadSettings, out IsSuccess);
      //      }

      //    }
      //    FileXml += "</Root>";


      //    if (MessageLog == string.Empty)
      //    {

      //      var EmailAddress = oFileSystemRepository.GetRecipientList().RecipientList.Find(i => i.RecipientID == Convert.ToInt32(RecipientID));
      //      bool CheckSend = false;
      //      string style = "<style>table {border-collapse: collapse;width: 800px;font-family:Arial;}" +
      //                      "th {font-weight: bold;background-color: #757575;color:#ffffff;}" +
      //                      "th,td {text-align: left;padding: 8px;}" +
      //                      "tr:nth-child(even) {background-color: #f2f2f2;}</style>";
      //      string BodyPass = style + "<br/><br/>" +
      //                        "<table style='border:1px solid #757575'>" +
      //                        "<tr>" +
      //                        "<th colspan='2'>File upload details </th>" +
      //                        "</tr>" +
      //                        "<tr>" +
      //                        "<td style='width:10%;font-weight:bold;border:1px solid #757575'>NHS Agency </td> " +
      //                        "<td style='width:40%;border:1px solid #757575'>" + NHS + "</td> " +
      //                        "</tr>" +
      //                        "<tr>" +
      //                        "<td style='width:10%;font-weight:bold;border:1px solid #757575'>Uploaded By </td> " +
      //                        "<td style='width:40%;border:1px solid #757575'>" + FullName + "</td> " +
      //                        "</tr>" +
      //                        "<tr>" +
      //                        "<td style='vertical-align:top;width:10%;font-weight:bold;border:1px solid #757575'>Contact Address </td> " +
      //                        "<td style='width:40%;border:1px solid #757575; '>" + Email + "</td>" +
      //                        "</tr>" +
      //                        "<tr>" +
      //                        "<td style='vertical-align:top;width:10%;font-weight:bold;border:1px solid #757575'>File Name</td> " +
      //                        "<td style='width:40%;border:1px solid #757575; '>" + GetFileName + "</td>" +
      //                        "</tr>" +
      //                        "</table>";
      //      try
      //      {
      //        CheckSend = oSendEmail.SendEmailNow(EmailAddress.EmailAddress.Trim(), "File Uploaded", BodyPass, Email, FullName);
      //      }
      //      catch (Exception ex)
      //      {
      //        ExceptionLogger logger = new ExceptionLogger()
      //        {
      //          ExceptionMessage = ex.Message,
      //          ExceptionStackTrace = ex.StackTrace,
      //          ControllerName = "FileUploadController",
      //          ActionName = "Create",
      //          LogTime = DateTime.Now
      //        };

      //        var exceptionRepository = new OnExceptionRepository();
      //        exceptionRepository.InsertExceptionLogger(logger);
      //      }
      //      finally
      //      {
      //        oFileSystemRepository.InsertFileManage(Convert.ToInt32(RecipientID), FullName, Email, NHS, LinkGenerate, VerificationCode, GenerateGuid, FileXml, IsSuccess, CheckSend);
      //        SuccessLog = "True";
      //      }

      //    }
      //  }
      //  return Json(new { MessageLog, SuccessLog }, JsonRequestBehavior.AllowGet);
      //}


      #endregion



      protected override void Dispose(bool disposing)
      {
        oJobRepository.Dispose();
        oCustomerRepository.Dispose();
        oCustomerContactsRepository.Dispose();
        oUserRepository.Dispose();
        base.Dispose(disposing);
      }


    }
}
