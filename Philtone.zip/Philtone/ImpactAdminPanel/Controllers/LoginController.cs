﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Repository.Administration;
using ServiceLayer.Repository.Common;
using ServiceLayer.Entity.Administration;
using System.Web.Security;
using ServiceLayer.Utitlity;
using Newtonsoft.Json;

namespace ImpactAdminPanel.Controllers
{
    [AllowAnonymous]
    public class LoginController : Controller
    {
        
        UserRepository oUserRepository;
        CommonRepository oCommonRepository;
        public LoginController()
        {
            oUserRepository = new UserRepository();
            oCommonRepository = new CommonRepository();
        }

        //
        // GET: /Login/

        public ActionResult Index()
        {
            return View();
        }
       

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(User oUser)
        {

            if (ModelState.IsValid)
            {
                List<MapMenuUser> oMapMenuUsers = new List<MapMenuUser>();
                if (oUserRepository.IsValid(oUser.LoginName, oUser.LoginPassword, out oUser))
                {
                    //Setting a unique session name
                    SessionNames.CurrentUser = oCommonRepository.GetUniqueIdentifier();
                    Session[SessionNames.CurrentUser] = oUser;
                    //Session[SessionNames.CurrentMenus] = oMapMenuUsers;
                    FormsAuthentication.SetAuthCookie(oUser.LoginName, false);
                    ///Here we are inserting the new logged on time that is why type is passed as 1
                    oCommonRepository.InsertUpdateSessiongLog(SessionNames.CurrentUser, oUser.UserID, 1);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ViewBag.ErrorMessage = "Login name and password don't exists.";                   
                }
            }
            return View(oUser);
        }

        public ActionResult ResetUserPassword(string EmailAddress)
        {
            dynamic result = oUserRepository.ResetUserPassword(EmailAddress);
            result = ImpactAdminPanel.Models.LoginValidation.ResetPassword(EmailAddress,result);
            return Json(JsonConvert.SerializeObject(result), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Logout(string UserID)
        {
            ///Here we are updating the existing logged on time that is why type is passed as 1
            oCommonRepository.InsertUpdateSessiongLog(SessionNames.CurrentUser, Convert.ToInt32(UserID), 2);
            FormsAuthentication.SignOut();
            Session.Remove(SessionNames.CurrentUser);
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }

        
        public ActionResult LoginRedirect()
        {
            return RedirectToAction("Index", "Login");
        }

        protected override void Dispose(bool disposing)
        {
            oUserRepository.Dispose();
            oCommonRepository.Dispose();
            base.Dispose(disposing);
        }

    }
}
