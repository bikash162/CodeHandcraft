﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Utitlity;
using System.Web.Routing;
using ImpactAdminPanel.Helper;
using ServiceLayer.Entity.Administration;



namespace ImpactAdminPanel.Controllers
{
    public class BaseController : Controller
    {
        /// <summary>
        /// It fetches the user information in session which is typecasted against User Model
        /// </summary>
        public User CurrentUser
        {

            get
            {
                User user = null;
                if (Session[SessionNames.CurrentUser] != null)
                {
                    user = (User)Session[SessionNames.CurrentUser];
                }
                return user;
            }
            set
            {
                Session[SessionNames.CurrentUser] = value;
            }
        }
        /// <summary>
        /// It fetches the user menu information in session which is typecasted against MapMenuUser Model
        /// </summary>
        public List<MapMenuUser> CurrentMenus
        {
            get
            {
                List<MapMenuUser> oMapMenuUser = null;
                if (Session[SessionNames.CurrentMenus] != null)
                {
                    oMapMenuUser = (List<MapMenuUser>)Session[SessionNames.CurrentMenus];
                }
                return oMapMenuUser;
            }
            set
            {
                Session[SessionNames.CurrentMenus] = value;
            }
        }

        /// <summary>
        /// This is used to hold current page index from which state create or edit action was used from listing
        /// </summary>
        public int RedirectPage
        {
            get
            {
                int redirectPage = 1;
                if (Session["redirectPage"] != null)
                {
                    redirectPage = Convert.ToInt32(Session["redirectPage"]);
                }
                return redirectPage;
            }
            set { Session["redirectPage"] = value; }
        }

        public string CurrentUserId { get; set; }

        public string ReturnLink = "/Login/Logout";

        /// <summary>
        /// Checks whether session is alive or not
        /// </summary>
        /// <returns></returns>
        public bool HasSessionChecker()
        {
            if (Session.Count == 0 && Session[SessionNames.CurrentUser] == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// This the based method for every action against any action taken by inherited controllers of BaseController
        /// EveryTime it checks whether session expires or not, if expired then redirected to login page by redirecting to logout action of root 
        /// Else Current userinfo and Current user Activity permission are assigned to viewbag which can be easily accessible from Razor View
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            base.OnActionExecuting(filterContext);
            if (!HasSessionChecker())
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new
                {
                    controller = "Login",
                    action = "Logout",
                    area = ""

                }));
            }
            else
            {
                ViewBag.userInfo = CurrentUser;
                ViewBag.UserMenus = CurrentMenus;
            }
        }
        /// <summary>
        /// Not In Use but helpfull 
        /// </summary>
        /// <param name="filterContext"></param>
        private void EncryptParameter(ActionExecutingContext filterContext)
        {
            var ActionInfo = filterContext.ActionDescriptor;
            var pars = ActionInfo.GetParameters();
            foreach (var p in pars)
            {
                var type = p.ParameterType; //get type expected
                var value = filterContext.ActionParameters[p.ParameterName];
                if (p.ParameterName == "ClientId")
                {
                    filterContext.ActionParameters[p.ParameterName] = CommonHelper.Encrypt(value.ToString().Trim());
                }
            }
        }
        /// <summary>
        /// It decryptes from CustomHelper class within MvcSite.RazorHelper Namespace
        /// </summary>
        /// <param name="Parameter"></param>
        protected T ParamDecrypter<T>(string Parameter)
        {
            return CustomHelper.DecryptParameter<T>(Parameter);
        }

    }
}
