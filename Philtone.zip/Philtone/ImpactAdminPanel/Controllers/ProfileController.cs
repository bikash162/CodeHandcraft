﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImpactAdminPanel.Controllers;
using ServiceLayer.Entity.Administration;
using ServiceLayer.ViewModel.Administration;
using ServiceLayer.Repository.Administration;
using ImpactAdminPanel.Helper;

namespace ImpactAdminPanel.Controllers
{
    public class ProfileController : BaseController
    {
        UserRepository oUserRepository;

        public ProfileController()
        {
            oUserRepository = new UserRepository();
        }

        public ActionResult Index(int UserID)
        {
            UserViewModel ouser = oUserRepository.GetUserById(UserID);
            return View(ouser);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(UserViewModel users)
        {
            try
            {
                var result = oUserRepository.UpdateProfile(users, CurrentUser.UserID);
                ViewBag.MessageType = result.ReturnValue == 2 ? MessageType.Success : MessageType.Error;
                ViewBag.Message = result.ReturnMessage;
                users = oUserRepository.GetUserById(users.user.UserID);
            }
            catch (Exception ex)
            {
                ViewBag.MessageType = MessageType.Error;
                ModelState.AddModelError("", ex.Message);
            }
            return View(users);
        }

    }
}
