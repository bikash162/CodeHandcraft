﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Repository.Administration;
using ServiceLayer.Entity.Administration;
using Newtonsoft.Json;

namespace ImpactAdminPanel.Controllers
{
    public class HomeController : BaseController
    {
        UserRepository oUserRepository;

        public HomeController()
        {
            oUserRepository = new UserRepository();
        }

        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ChangePassword(string Password)
        {
            var result = oUserRepository.UpdateUserPassword(CurrentUser.UserID, Password);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

    }
}
