﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Entity.Master;
using ServiceLayer.Repository.Master;
using ServiceLayer.ViewModel.Master;
using ServiceLayer.Utitlity;


namespace ImpactAdminPanel.Controllers
{
    public class MenuController : BaseController
    {
        // GET: /MenuRepository/
        MenuRepository oMenuRepository;

        public MenuController()
        {
            oMenuRepository = new MenuRepository();
        }

        /// <summary>
        /// This method populates the left side panel menu of the application
        /// IsAdmin = true from Superadmin and isAdmin=false from user 
        /// </summary>
        /// <returns></returns>
        [ChildActionOnly]
        public ActionResult MenuListing(bool IsAdmin = false, int? UserID = 0)
        {
            MenuViewModel oMenuViewModel = new MenuViewModel();
            oMenuViewModel = oMenuRepository.GetMenusByPriviledge(IsAdmin, UserID);
            return PartialView("_LeftMenu", oMenuViewModel);
        }

        

        protected override void Dispose(bool disposing)
        {
            oMenuRepository.Dispose();
            base.Dispose(disposing);
        }
    }
}
