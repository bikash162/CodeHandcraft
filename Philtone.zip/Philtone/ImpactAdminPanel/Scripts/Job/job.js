﻿
function GetJobsAssignedCustomerContactsList(JobID, CustomerName) {
    if (JobID != "" && JobID != "0") {
        $('#txtCustomerName').html(CustomerName);
        $.ajax({
            url: window.rootUrl + 'Job/GetJobsAssignedCustomerContactsList',
            type: "GET",
            dataType: "html",
            data: { JobID: JobID },
            contentType: "application/html;charset=UTF-8",
            success: function (data) {
                $('#divCustomerContact').html('');
                $('#divCustomerContact').html(data);
                $('#divCustomerContact').show();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
}





function GetAllCustomerContactsByCustomerID() {
    var CustomerID = $('#job_CustomerID').val();
    if (CustomerID != "" && CustomerID != "0") {
        $.ajax({
            url: window.rootUrl + 'Job/GetAllCustomerContactsByCustomerID',
            type: "GET",
            dataType: "html",
            data: { CustomerID: CustomerID },
            contentType: "application/html;charset=UTF-8",
            success: function (data) {
                $('#divCustomerContactList').html('');
                $('#divCustomerContactList').html(data);
               
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    else {
        $("#divCustomerContactList").html('');
        var trHTML;
        trHTML = "<div class='row'> <div class='col-md-12'><div class='well' style='max-height: 300px; overflow: auto;'><ul class='list-group checked-list-box'><li class='list-group-item'><h4>No Contacts to display</h4></li></ul></div></div></div>";
        $("#divCustomerContactList").html(trHTML);
    }
}


function InsertJob() {
        var UserIDs = "";
        $('.chkUser:checked').each(function () {
            UserIDs += $(this).attr("value") + ",";
        });
        if (UserIDs.length > 0) {
            UserIDs = UserIDs.slice(0, -1);
        }

        var jobObj = {
            JobCode: $('#job_JobCode').val(),
            JobTitle: $('#job_JobTitle').val(),
            JobDescription: $('#job_JobDescription').val(),
            CustomerID: $('#job_CustomerID').val(),
            UserIDs: UserIDs,
            CustomerContactIDs: ''
        };

        $.ajax({
            url: window.rootUrl + 'Job/Create',
            contentType: 'application/json; charset=utf-8',
            type: 'POST',
            data: JSON.stringify(jobObj),
            cache: false,
            success: function (result) {
                
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
}

$(function () {
    $(document).on('click', '.btn-add', function (e) {
        e.preventDefault();

        var controlForm = $('.controls:first'),
            currentEntry = $(this).parents('.entry:first'),
            newEntry = $(currentEntry.clone()).appendTo(controlForm);

        newEntry.find('input').val('');
        controlForm.find('.entry:not(:last) .btn-add')
            .removeClass('btn-add').addClass('btn-remove')
            .removeClass('btn-success').addClass('btn-danger')
            .html('<span class="glyphicon glyphicon-minus"> </span>');
    }).on('click', '.btn-remove', function (e) {
        $(this).parents('.entry:first').remove();

        e.preventDefault();
        return false;
    });
});