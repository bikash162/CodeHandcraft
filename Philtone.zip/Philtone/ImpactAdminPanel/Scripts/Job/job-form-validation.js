﻿var JobFormValidation = function (element) {
    var handleJobFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "job.JobCode": {
                    required: true
                },
                "job.JobTitle": {
                    required: true
                },
                "job.CustomerID": {
                    required: true
                },
                "chkUser": {
                    required: true
                },
                "chkCustomerContact": {
                    required: true
                }
            },
            messages: {
                "job.JobCode": {
                    required: 'Enter Job Code'
                },
                "job.JobTitle": {
                    required: 'Enter Job Title'
                },
                "job.CustomerID": {
                    required: 'Select Customer'
                },
                "chkUser": {
                    required: 'Select atleast one User'
                },
                "chkCustomerContact": {
                    required: 'Select atleast one Contact'
                }
            },

            submitHandler: function (form) {
                myApp.showPleaseWait();
                form.submit();
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleJobFormValidation(element);
        }
    };
}();