﻿var ContactFormValidation = function (element) {
    var handleContactFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactName": {
                    required: true
                },
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactEmail": {
                    required: true,
                    email: true
                },
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactPhoneNumber": {
                    required: true
                }  ,
                "CustomerContactsViewModel.oCustomerContacts.UserName": {
                required: true
                },
                "CustomerContactsViewModel.oCustomerContacts.UserPassword": {
                    required: true
                }
                    
            },
            messages: {
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactName": {
                    required: 'Enter Name'
                },
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactEmail": {
                    required: 'Enter Email'
                },
                "CustomerContactsViewModel.oCustomerContacts.CustomerContactPhoneNumber": {
                    required: 'Enter Phone Number'
                },
                "CustomerContactsViewModel.oCustomerContacts.UserName": {
                    required: 'Enter User Name'
                },
                "CustomerContactsViewModel.oCustomerContacts.UserPassword": {
                    required: 'Please generate the password'
                }

            },

            submitHandler: function (form) {
                handleCustomerContactAddEditForm($(form));
            }
        });
    }
    var handleCustomerContactAddEditForm = function (form) {
        $.ajax({
            url: window.rootUrl + 'Customer/AddEdit',
            data: form.serialize(),
            cache: false,
            type: 'POST',
            //contentType: "application/json;charset=utf-8",
            dataType: 'json',
            success: function (data) {
                if (data.ReturnValue == "1") {
                    $("#modal-CustomerContact-add").modal('hide');
                    $("#alertdiv").removeClass().addClass("alert alert-success");
                    $("#alertstrong").text("Success!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                    location.reload();
                }
                else {
                    $("#alertdiv").removeClass().addClass("alert alert-danger");
                    $("#alertstrong").text("Error!");
                    $("#alertmsg").text(data.ReturnMessage);
                    $("#alertModal").modal('show');
                }
                return;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status == 911) {
                    window.location.reload(xhr.statusText);
                }
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleContactFormValidation(element);
        }
    };
}();