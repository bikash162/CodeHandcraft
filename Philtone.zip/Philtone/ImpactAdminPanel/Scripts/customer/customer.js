﻿
//function validateCustomerInfo() {
//    var isValid = true;
//    if ($('#CustomerName').val().trim() == "") {
//        $('#CustomerName').css('border-color', 'Red');
//        isValid = false;
//    }
//    else {
//        $('#CustomerName').css('border-color', 'lightgrey');
//    }

//    if ($('#CustomerEmail').val().trim() == "") {
//        $('#CustomerEmail').css('border-color', 'Red');
//        isValid = false;
//    }
//    else {
//        $('#CustomerEmail').css('border-color', 'lightgrey');
//    }
//}

//function ResetCustomer() {
//    $('#CustomerName').val('');
//    $('#CustomerEmail').val('');
//    $('#CustomerDescription').val('');
//    $('#CustomerName').css('border-color', 'lightgrey');
//    $('#CustomerEmail').css('border-color', 'lightgrey');
//}


function FillCityBasedOnCountryID() {
    var CountryID = $('#Customer_CountryId').val();
    if (CountryID != "") {
        $.ajax({
            url: window.rootUrl + 'Customer/FillCityBasedOnCountryID',
            type: "GET",
            async: true,
            dataType: "json",
            data: { CountryId: CountryID },
            success: function (data) {
                $("#Customer_CityId").html(""); // clear before appending new list 
                $("#Customer_CityId").empty().append('<option selected="selected" value="0">Select City</option>');
                $.each(data, function (i, item) {
                    $("#Customer_CityId").append($('<option></option>').val(item.CityId).html(item.CityName));
                });
            }
        });
    }
    else {
        $("#Customer_CityId").empty().append('<option selected="selected" value="">Select City</option>');
    }
}

function GetCustomerContactList(CustomerID, CustomerName) {
    $('#txtCustomerName').html(CustomerName);
    $.ajax({
        url: window.rootUrl + 'Customer/GetCustomerContactList',
        typr: "GET",
        //contentType: "application/json;charset=UTF-8",
        dataType: "html",
        data: {
            CustomerID: CustomerID,
            page: 1,
            pagesize: 10,
            sortBy: "CustomerContactName",
            ascending: true
        },
        success: function (data) {
            $('#divCustomerContact').html('');
            $('#divCustomerContact').html(data);
            $('#divCustomerContactsList').show();
            
        },
        error: function (xhr, ajaxOptions, thrownError) {
            if (xhr.status == 911) {
                window.location.reload(xhr.statusText);
            }
        }
    });
    return false;
}


