﻿var CustomerContact = function () {

    var handleCustomerContactAddEdit = function () {
        $("#btnCustomerContactAdd").click(function () {
            var CustomerID = $('#hdnCustomerID').val();
            $("#CustomerContactsViewModel_oCustomerContacts_CustomerContactID").val("");
            $("#modal-CustomerContact-add").modal('show');
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("customercontact-form-addedit");
            $('#hdnCustomerID').val(CustomerID);
        });
    }
    return {
        //main function to initiate the module
        init: function () {
            handleCustomerContactAddEdit();
        }
    };
}();

var myCustomerContact;
myCustomerContact = myCustomerContact || (function () {
    return {
        Edit: function (Element) {            
            //This method is written in form-jquery-validation and refered in layout page
            myForm.Clear("customercontact-form-addedit");
           
            $.ajax({
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                type: "GET",
                data: { CustomerContactID: Element },
                url: window.rootUrl + 'Customer/GetCustomerContactByID',
                success: function (data) {                    
                    $('#hdnCustomerID').val(data.CustomerID);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactID').val(data.CustomerContactID);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactName').val(data.CustomerContactName);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactEmail').val(data.CustomerContactEmail);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactPhoneNumber').val(data.CustomerContactPhoneNumber);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactDesignation').val(data.CustomerContactDesignation);
                    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactRemark').val(data.CustomerContactRemark);
                    $('#CustomerContactsViewModel_oCustomerContacts_UserName').val(data.UserName);
                    $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(data.UserPassword);
                    $("#CustomerContactsViewModel_oCustomerContacts_IsPrimary").val(data.IsPrimary).prop('checked', data.IsPrimary).change();
                    $("#CustomerContactsViewModel_oCustomerContacts_IsActive").val(data.IsActive).prop('checked', data.IsActive).change();
                    $("#modal-CustomerContact-add").modal('show');
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            });
        },

        GeneratePassword: function () {
            $.ajax({
                url: window.rootUrl + 'Customer/CreatePassword',
                typr: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "JSON",
                success: function (data) {
                    $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(data);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (xhr.status == 911) {
                        window.location.reload(xhr.statusText);
                    }
                }
            });
        },
        UserNameCreate: function () {
            var GeneratedUserName;
                $("#CustomerContactsViewModel_oCustomerContacts_CustomerContactName").blur(function () {
                    GeneratedUserName = $("#CustomerContactsViewModel_oCustomerContacts_CustomerContactName").val();
                    if (GeneratedUserName != '') {
                        GeneratedUserName = GeneratedUserName.replace(' ', '').substring(0, 6);
                        if ($('#CustomerContactsViewModel_oCustomerContacts_UserName').val() == '') {
                            $('#CustomerContactsViewModel_oCustomerContacts_UserName').val(GeneratedUserName);
                        }
                    }
                    else {
                        $('#CustomerContactsViewModel_oCustomerContacts_UserName').val('');
                    }

                });
        }    

    }
})();
//function HideAddEditCustomerContactPopUp() {
//    $('#divAddEditCustomerContact').hide();
//}

//function AddContact()
//{
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactID').val(0);
//}

//function AddNewCustomerContact() {
//    myForm.Clear("customercontact-form-addedit");
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactID').val(0);
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactName').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactEmail').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactPhoneNumber').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactDesignation').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactRemark').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_UserName').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val('');
//    $('#CustomerContactsViewModel_oCustomerContacts_IsPrimary').prop('checked', false);
//    $('#CustomerContactsViewModel_oCustomerContacts_IsActive').prop('checked', false);
//}

//function InsertCustomerContact() {
//    var res = false;
//    res = CheckCustomerContactUserNameExists($('#CustomerContactsViewModel_oCustomerContacts_UserName').val());
//    if (res == false) {
//        var IsPrimary;
//        if (!$('#CustomerContactsViewModel_oCustomerContacts_IsPrimary').is(':checked')) {
//            IsPrimary = false;
//        }
//        else {
//            IsPrimary = true;
//        }

//        var CustomerContactObj = {
//            CustomerID: $('#Customer_CustomerID').val(),
//            CustomerContactName: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactName').val(),
//            CustomerContactEmail: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactEmail').val(),
//            CustomerContactPhoneNumber: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactPhoneNumber').val(),
//            CustomerContactDesignation: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactDesignation').val(),
//            CustomerContactRemark: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactRemark').val(),
//            UserName: $('#CustomerContactsViewModel_oCustomerContacts_UserName').val(),
//            UserPassword: $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(),
//            IsPrimary: IsPrimary
//        };
//        $.ajax({
//            url: window.rootUrl + 'Customer/InsertCustomerContact',
//            data: JSON.stringify(CustomerContactObj),
//            type: "POST",
//            contentType: "application/json;charset=utf-8",
//            dataType: "json",
//            success: function (result) {
//                $('#divAddEditCustomerContact').modal('hide');
//                location.reload();
//            },
//            error: function (xhr, ajaxOptions, thrownError) {
//                if (xhr.status == 911) {
//                    window.location.reload(xhr.statusText);
//                }
//            }
//        });
//    }
//}



//function UpdateCustomerContact() {

//    var IsPrimary;
//    var IsActive;

//    if (!$('#CustomerContactsViewModel_oCustomerContacts_IsPrimary').is(':checked')){
//        IsPrimary = false;
//    }
//    else {
//        IsPrimary = true;
//    }

//    if (!$('#CustomerContactsViewModel_oCustomerContacts_IsActive').is(':checked')) {
//        IsActive = false;
//    }
//    else {
//        IsActive = true;
//    }

//    var CustomerContactObj = {
//        CustomerID: $('#Customer_CustomerID').val(),
//        CustomerContactID: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactID').val(),
//        CustomerContactName: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactName').val(),
//        CustomerContactEmail: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactEmail').val(),
//        CustomerContactPhoneNumber: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactPhoneNumber').val(),
//        CustomerContactDesignation: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactDesignation').val(),
//        CustomerContactRemark: $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactRemark').val(),
//        UserPassword: $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(),
//        IsPrimary: IsPrimary,
//        IsActive: IsActive,
//    };
//    $.ajax({
//        url: window.rootUrl + 'Customer/UpdateCustomerContact',
//        data: JSON.stringify(CustomerContactObj),
//        type: "POST",
//        contentType: "application/json;charset=utf-8",
//        dataType: "json",
//        success: function (result) {
//            $('#divAddEditCustomerContact').modal('hide');
//            location.reload();
//        },
//        error: function (xhr, ajaxOptions, thrownError) {
//            if (xhr.status == 911) {
//                window.location.reload(xhr.statusText);
//            }
//        }
//    });
//}


//function GetCustomerContactByID(CustomerContactID) {

//    $.ajax({
//        url: window.rootUrl + 'Customer/GetCustomerContactByID',
//        typr: "GET",
//        contentType: "application/json;charset=UTF-8",
//        dataType: "json",
//        data: { CustomerContactID: CustomerContactID },
//        success: function (result) {
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactID').val(result.CustomerContactID);
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactName').val(result.CustomerContactName);
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactEmail').val(result.CustomerContactEmail);
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactPhoneNumber').val(result.CustomerContactPhoneNumber);
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactDesignation').val(result.CustomerContactDesignation);
//            $('#CustomerContactsViewModel_oCustomerContacts_CustomerContactRemark').val(result.CustomerContactRemark);
//            $('#CustomerContactsViewModel_oCustomerContacts_UserName').val(result.UserName);
//            $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(result.UserPassword);
//            $("#CustomerContactsViewModel_oCustomerContacts_IsPrimary").val(result.IsPrimary).prop('checked', result.IsPrimary).change();
//            $("#CustomerContactsViewModel_oCustomerContacts_IsActive").val(result.IsActive).prop('checked', result.IsActive).change();
            
                
//            $('#modal-CustomerContact-add').modal('show');
//            $('#btnAdd').show();
//        },
//        error: function (xhr, ajaxOptions, thrownError) {
//            if (xhr.status == 911) {
//                window.location.reload(xhr.statusText);
//            }
//        }
//    });
//    return false;
//}

//function CheckCustomerContactUserNameExists(UserName) {
//    var UserExists = false;
//    $.ajax({
//        url: window.rootUrl + 'Customer/CheckCustomerContactUserNameExists',
//        typr: "POST",
//        contentType: "application/json;charset=UTF-8",
//        dataType: "JSON",
//        data: { UserName: UserName },
//        success: function (data) {
//            if (data = 1) {
//                UserExists = true;
//            }
//            else {
//                UserExists = false;
//            }

//        },
//        error: function (xhr, ajaxOptions, thrownError) {
//            if (xhr.status == 911) {
//                window.location.reload(xhr.statusText);
//            }
//        }
//    });
//    return UserExists;
//}


//$(document).ready(function () {
//    var GeneratedUserName;
//    $("#CustomerContactsViewModel_oCustomerContacts_CustomerContactName").blur(function () {
//        GeneratedUserName = $("#CustomerContactsViewModel_oCustomerContacts_CustomerContactName").val();
//        if (GeneratedUserName != '') {
//            GeneratedUserName = GeneratedUserName.replace(' ', '').substring(0, 6);
//            if ($('#CustomerContactsViewModel_oCustomerContacts_UserName').val() == '') {
//                $('#CustomerContactsViewModel_oCustomerContacts_UserName').val(GeneratedUserName);
//            }
//        }
//        else {
//            $('#CustomerContactsViewModel_oCustomerContacts_UserName').val('');
//        }

//    });
//});


//function GeneratePassword() {
//    $.ajax({
//        url: window.rootUrl + 'Customer/CreatePassword',
//        typr: "POST",
//        contentType: "application/json;charset=UTF-8",
//        dataType: "JSON",
//        success: function (data) {
//            $('#CustomerContactsViewModel_oCustomerContacts_UserPassword').val(data);
//        },
//        error: function (xhr, ajaxOptions, thrownError) {
//            if (xhr.status == 911) {
//                window.location.reload(xhr.statusText);
//            }
//        }
//    });
//}