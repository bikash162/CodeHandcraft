﻿var CustomerFormValidation = function (element) {
    var handleCustomerFormValidation = function (element) {
        $("#" + element).validate({
            rules: {
                "Customer.CustomerName": {
                    required: true
                },
                "Customer.CustomerEmail": {
                    required: true,
                    email:true
                },
                "Customer.PhoneNo": {
                    required: true
                },
                "Customer.Address": {
                    required: true
                },
                "Customer.PostCode": {
                    required: true
                },
                "Customer.CountryId": {
                    required: true
                },
                "Customer.CityId": {
                    required: true
                },
                "Customer.DefaultContactName": {
                    required: true
                },
                "Customer.DefaultContactEmail":{
                    required: true,
                    email: true
                },
                "Customer.DefaultContactPhoneNo": {
                    required:true
                },
                "Customer.UserID": {
                    required: true,
                    minlength:6
                },
                "Customer.UserPassword": {
                    required: true                   
                },
                "Customer.UserConfirmPassword": {
                    required: true
                }
            },
            messages: {
                "Customer.CustomerName": {
                    required: 'Enter Name'
                },
                "Customer.CustomerEmail": {
                    required: 'Enter Email'
                },
                "Customer.PhoneNo": {
                    required: 'Enter Phone Number'
                },
                "Customer.Address": {
                    required: 'Enter Address'
                },
                "Customer.PostCode": {
                    required: 'Enter Post Code'
                },
                "Customer.CountryId": {
                    required: 'Select Country'
                },
                "Customer.CityId": {
                    required: 'Select City'
                },
                "Customer.DefaultContactName": {
                    required: 'Enter Primary Contact Name'
                },
                "Customer.DefaultContactEmail": {
                    required: 'Enter Primary Contact Email'
                },
                "Customer.DefaultContactPhoneNo": {
                    required: 'Enter Primary Phone Number'
                },
                "Customer.UserID": {
                    required: 'Enter Login Name',
                    minlength: 'Login Name contain atleast 6 character.'
                },
                "Customer.UserPassword": {
                    required: 'Enter Password'
                },
                "Customer.UserConfirmPassword": {
                    required: 'Enter Confirm Password'
                }
            },

            submitHandler: function (form) {
                myApp.showPleaseWait();
                form.submit();
            }
        });
    }
    return {
        //main function to initiate the module
        init: function (element) {
            handleCustomerFormValidation(element);
        }
    };
}();