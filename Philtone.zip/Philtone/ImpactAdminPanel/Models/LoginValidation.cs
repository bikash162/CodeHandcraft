﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ServiceLayer.Entity.Master;
using ServiceLayer.Repository.Master;
using ServiceLayer.Utitlity;
using System.Dynamic;

namespace ImpactAdminPanel.Models
{
    public static class LoginValidation
    {
        public static dynamic ResetPassword(string EmailAddress, dynamic objResetUserPassword)
        {
            EmailSettingsRepository oEmailSettingsRepository = new EmailSettingsRepository();
            var result = oEmailSettingsRepository.GetEmailSettingsList().Where(y=> y.IsActive==true).FirstOrDefault();
            dynamic jsonObject = new ExpandoObject();
            objResetUserPassword=(ExpandoObject)objResetUserPassword;
            if (objResetUserPassword.Status == 1)
            {
                INotificaiton oNotifiation = new Email(result.FromEmail, result.FromDisplayName, EmailAddress, objResetUserPassword.Subject, objResetUserPassword.MailBody, result.SmtpHost, result.SmptPort, result.EnableSsl, result.UseDefaultCredentials, result.CredentialUserName, result.CredentialPassword);                
                try
                {
                    jsonObject.ReturnValue = oNotifiation.SendMessage();
                    jsonObject.ReturnMessage = "Mail Send Successfully";
                }
                catch (Exception ex)
                {
                    jsonObject.ReturnValue = false;
                    jsonObject.ReturnMessage = ex.Message;
                    CommonHelper.ExceptionLogger(ex, "EmailSettings", "TestMail");
                }
            }
            else
            {
                jsonObject.ReturnValue = false;
                jsonObject.ReturnMessage = "Mail Address don't exists in the system";
            }

            return jsonObject;
        }
    }
}