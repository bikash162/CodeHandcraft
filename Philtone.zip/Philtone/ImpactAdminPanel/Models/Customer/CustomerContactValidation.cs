﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Repository.Customers;
using ServiceLayer.Utitlity;
using System.Dynamic;

namespace ImpactAdminPanel.Models.Customer
{
  public static class CustomerContactValidation
  {
    public static dynamic AddEditCustomerContact(FormCollection formCollection, CustomerContactsRepository oCustomerContactsRepository, int CurrentUserID)
    {
      dynamic result = "";
      CustomerContacts oCustomerContacts = new CustomerContacts();
      try
      {
        oCustomerContacts.CustomerID = Convert.ToInt64(formCollection["hdnCustomerID"]);
        oCustomerContacts.CustomerContactID = Convert.ToInt64(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactID"] == "" ? "0" : formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactID"]);
        oCustomerContacts.CustomerContactName = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactName"]);
        oCustomerContacts.CustomerContactEmail = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactEmail"]);
        oCustomerContacts.UserName = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.UserName"]);
        oCustomerContacts.UserPassword = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.UserPassword"]);
        oCustomerContacts.CustomerContactPhoneNumber = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactPhoneNumber"]);
        oCustomerContacts.CustomerContactDesignation = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactDesignation"]);
        oCustomerContacts.CustomerContactRemark = Convert.ToString(formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactRemark"]);

        if (oCustomerContacts.CustomerContactID > 0)
        {
          oCustomerContacts.ModifiedBy = CurrentUserID;
        }
        else
        {
          oCustomerContacts.CreatedBy = CurrentUserID;
        }

        oCustomerContacts.IsPrimary = Convert.ToBoolean(formCollection["CustomerContactsViewModel.oCustomerContacts.IsPrimary"] != null ? true : false);
        oCustomerContacts.IsActive = Convert.ToBoolean(formCollection["CustomerContactsViewModel.oCustomerContacts.IsActive"] != null ? true : false);
        result = formCollection["CustomerContactsViewModel.oCustomerContacts.CustomerContactID"] == "" ? oCustomerContactsRepository.InsertCustomerContact(oCustomerContacts) : oCustomerContactsRepository.UpdateCustomerContact(oCustomerContacts);
      }
      catch (Exception)
      {
        throw;
      }
      return result;
     
    }
  }
}