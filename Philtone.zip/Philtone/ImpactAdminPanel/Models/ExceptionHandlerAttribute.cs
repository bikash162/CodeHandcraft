﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ServiceLayer.Entity.Common;
using ServiceLayer.Utitlity;
using ServiceLayer.Repository.Common;

namespace ImpactAdminPanel.Models
{
    public class ExceptionHandlerAttribute : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            if (!filterContext.ExceptionHandled)
            {
                ExceptionLogger logger = new ExceptionLogger()
                {
                    ExceptionMessage = filterContext.Exception.Message,
                    ExceptionStackTrace = filterContext.Exception.StackTrace,
                    ControllerName = filterContext.RouteData.Values["controller"].ToString(),
                    ActionName = filterContext.RouteData.Values["action"].ToString(),
                    LogTime = DateTime.Now
                };

                var exceptionRepository = new ExceptionRepository();
                //DMLReturn oDmlexceptionRepository = exceptionRepository.InsertExceptionLogger(logger);
                exceptionRepository.InsertExceptionLogger(logger);
                filterContext.ExceptionHandled = true;

            }
        }
    }
}