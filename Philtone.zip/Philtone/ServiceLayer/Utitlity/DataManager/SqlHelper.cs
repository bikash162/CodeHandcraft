﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace ServiceLayer.Utitlity
{
    public class SqlHelper :ISqlHelper,IDisposable
    {

        private string _connectionString = string.Empty;
        private SqlConnection _con = null;
        private int _sqlTimeOut = 30;
        public SqlHelper()
        {
            _connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            _con = new SqlConnection(_connectionString);
            _sqlTimeOut = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["SqlTimeOut"].ToString());
        }
        /// <summary>
        /// It will return dataset result against single query
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        public DataSet ExecuteQueryList(string spQuery)
        {
            DataSet ds = new DataSet();
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandTimeout = _sqlTimeOut;

                    using (SqlDataAdapter da = new SqlDataAdapter(com))
                    {
                        _con.Open();
                        da.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }

            return ds;
        }
        /// <summary>
        /// It will return dataset result along with parameters
        /// </summary>
        /// <param name="spQuery"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public DataSet ExecuteQueryList(string spQuery, object[] parameters)
        {
            DataSet ds = new DataSet();
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddRange(parameters);
                    com.CommandTimeout = _sqlTimeOut;
                    using (SqlDataAdapter da = new SqlDataAdapter(com))
                    {
                        _con.Open();
                        da.Fill(ds);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }

            return ds;
        }
        /// <summary>
        /// It will return value of single table which can be easily bind to any entity
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        public DataTable ExecuteQuery(string spQuery)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandTimeout = _sqlTimeOut;
                    using (SqlDataAdapter da = new SqlDataAdapter(com))
                    {
                        _con.Open();
                        da.Fill(dt);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }

            return dt;
        }

        /// <summary>
        /// <This is only for SQL view execution>
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        public DataTable ExecuteInLineQuery(string spQuery)
        {
          DataTable dt = new DataTable();
          try
          {
            using (SqlCommand com = new SqlCommand())
            {
              com.Connection = _con;
              com.CommandText = spQuery;
              com.CommandType = CommandType.Text;
              com.CommandTimeout = _sqlTimeOut;
              using (SqlDataAdapter da = new SqlDataAdapter(com))
              {
                _con.Open();
                da.Fill(dt);
              }
            }

          }
          catch (Exception ex)
          {
            throw ex;
          }
          finally
          {
            if (_con.State == ConnectionState.Open)
            {
              _con.Close();
            }
          }

          return dt;
        }

      /// <summary>
        /// It will return value of single table along with parameter which can be easily bind to any entity
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        public DataTable ExecuteQuery(string spQuery, object[] parameters)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddRange(parameters);
                    com.CommandTimeout = _sqlTimeOut;
                    using (SqlDataAdapter da = new SqlDataAdapter(com))
                    {
                        _con.Open();
                        da.Fill(dt);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }

            return dt;
        }

        /// <summary>
        /// This method is for the executing data manipulation language query
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        public int ExecuteCommand(string spQuery)
        {
            int result = 0;
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandTimeout = _sqlTimeOut;
                    _con.Open();
                    result = com.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }
            return result;
        }
        /// <summary>
        /// This method is for the executing data manipulation language query with input parameters
        /// </summary>
        /// <param name="spQuery"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public int ExecuteCommand(string spQuery, object[] parameters)
        {
            int result = 0;
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddRange(parameters);
                    com.CommandTimeout = _sqlTimeOut;
                    _con.Open();
                    result = com.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }
            return result;
        }
        /// <summary>
        /// Manually Count the output parameter and send to the method
        /// </summary>
        /// <param name="hostServer"></param>
        /// <returns></returns>
        public int ExecuteCommand(string spQuery, object[] parameters, int outputParamIndex)
        {
            int result = 0;
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddRange(parameters);
                    com.CommandTimeout = _sqlTimeOut;
                    _con.Open();
                    com.ExecuteNonQuery();
                    result = Convert.ToInt32(((SqlParameter)parameters[outputParamIndex]).Value.ToString().Trim());
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }
            return result;
        }

        /// <summary>
        /// Manually Count the output parameter and send to the method
        /// </summary>
        /// <param name="hostServer"></param>
        /// <returns></returns>
        public DMLReturn ExecuteCommand(string spQuery, object[] parameters, int outputReturnIndex, int outputMessageIndex)
        {
            DMLReturn oDMLReturn = new DMLReturn();
            try
            {
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = _con;
                    com.CommandText = spQuery;
                    com.CommandType = CommandType.StoredProcedure;                    
                    com.Parameters.AddRange(parameters);
                    com.CommandTimeout = _sqlTimeOut;
                    _con.Open();
                    com.ExecuteNonQuery();
                    oDMLReturn.ReturnValue = Convert.ToInt32(((SqlParameter)parameters[outputReturnIndex]).Value.ToString().Trim());
                    oDMLReturn.ReturnMessage = ((SqlParameter)parameters[outputMessageIndex]).Value.ToString().Trim();                    
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                {
                    _con.Close();
                }
            }
            return oDMLReturn;
        }

       

      


        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _con.Close();
                    _con.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
