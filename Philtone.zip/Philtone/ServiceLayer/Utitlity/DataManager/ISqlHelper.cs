﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ServiceLayer.Utitlity
{
    /// <summary>
    /// This interface generally defines the ado .net methods for sql operation
    /// </summary>
    public interface ISqlHelper
    {
        /// <summary>
        /// It will return dataset result against single query
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        DataSet ExecuteQueryList(string spQuery);
        /// <summary>
        /// It will return dataset result along with parameters
        /// </summary>
        /// <param name="spQuery"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        DataSet ExecuteQueryList(string spQuery, object[] parameters);
        /// <summary>
        /// It will return value of single table which can be easily bind to any entity
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        DataTable ExecuteQuery(string spQuery);
        /// <summary>
        /// It will return value of single table along with parameter which can be easily bind to any entity
        /// </summary>
        /// <param name="spQuery"></param>
        /// <returns></returns>
        DataTable ExecuteQuery(string spQuery, object[] parameters);

        int ExecuteCommand(string spQuery);
        int ExecuteCommand(string spQuery, object[] parameters);
        /// <summary>
        /// Manually Count the output parameter and send to the method
        /// </summary>
        /// <param name="hostServer"></param>
        /// <returns></returns>
        int ExecuteCommand(string spQuery, object[] parameters, int outputIndex);
        /// <summary>
        /// Manually Count the output parameter and send to the method
        /// </summary>
        /// <param name="hostServer"></param>
        /// <returns></returns>
        DMLReturn ExecuteCommand(string spQuery, object[] parameters, int outputReturnIndex, int outputMessageIndex);
     
    }
}
