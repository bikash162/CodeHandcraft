﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Utitlity
{
  /// <summary>
  /// <This class is used for Paging the List, so it will be inherited in all entities where paging is needed>
  /// </summary>
  public class Pagination
  {
    public int RowNumber { get; set; }
    public int startRowIndex { get; set; }
    public int maximumRows { get; set; }
    public string SortBy { get; set; }
    public bool SortAscending { get; set; }
  }
}
