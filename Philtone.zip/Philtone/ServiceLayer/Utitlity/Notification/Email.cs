﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace ServiceLayer.Utitlity
{
    
    public class Email : INotificaiton
    {
        readonly string SenderEmail = string.Empty;
        readonly string SenderName = string.Empty;
        readonly string ToMailAddress = string.Empty;
        readonly string Subject = string.Empty;
        readonly string Body = string.Empty;
        readonly string SmtpHost = string.Empty;
        readonly int Port = 0;
        readonly bool EnableSSL = false;
        readonly bool UseDefaultCredentails = false;
        readonly string CredentialUserName = string.Empty;
        readonly string CredentialPassword = string.Empty;

        public Email(string SenderEmail, string SenderName, string ToMailAddress, string Subject, string Body, string SmtpHost, int Port, bool EnableSSL, bool UseDefaultCredentails, string CredentialUserName, string CredentialPassword)
        {
            this.SenderEmail = SenderEmail;
            this.SenderName = SenderName;
            this.ToMailAddress = ToMailAddress;
            this.Subject = Subject;
            this.Body = Body;
            this.SmtpHost = SmtpHost;
            this.Port = Port;
            this.EnableSSL = EnableSSL;
            this.UseDefaultCredentails = UseDefaultCredentails;
            this.CredentialUserName = CredentialUserName;
            this.CredentialPassword = CredentialPassword;
        }


        public bool SendMessage()
        {
            try
            {
                MailMessage message = new MailMessage();
                SmtpClient smtpClient = new SmtpClient();
                MailAddress fromAddress = new MailAddress(this.SenderEmail, this.SenderName);
                message.From = fromAddress;
                message.To.Add(this.ToMailAddress.ToString().Trim());
                message.Subject = this.Subject;
                message.IsBodyHtml = true;
                message.Body = this.Body;
                smtpClient.Host = this.SmtpHost;
                smtpClient.Port = this.Port;
                smtpClient.EnableSsl = this.EnableSSL;
                smtpClient.UseDefaultCredentials = this.UseDefaultCredentails;
                smtpClient.Credentials = new System.Net.NetworkCredential(this.CredentialUserName, this.CredentialPassword);
                smtpClient.Send(message);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
