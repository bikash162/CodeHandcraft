﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Utitlity
{
    /// <summary>
    /// This class return the data-manupulation-language result from the database like insert, update, delete.
    /// To function this class two output parameters need to be passed in the procedure like ReturnValue and ReturnMessage
    /// which needs to be set in the repository class where the data connection is done 
    /// </summary>
    public class DMLReturn
    {
        public int ReturnValue { get; set; }
        public string ReturnMessage { get; set; }
    }
}
