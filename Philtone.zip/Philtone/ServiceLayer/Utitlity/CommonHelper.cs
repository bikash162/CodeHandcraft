﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using ServiceLayer.Entity.Common;
using ServiceLayer.Repository.Common;

namespace ServiceLayer.Utitlity
{
    public class CommonHelper
    {
        /// <summary>
        /// Convert any date format to default sql server date format
        /// </summary>
        /// <param name="DateString"></param>
        /// <returns></returns>
        public static string FormatDate(string DateString)
        {
            string date = string.Empty;
            string[] DateStringFormat = DateString.Split('/');
            int ddIndex = 0;
            int mmIndex = 0;
            int yyIndex = 0;
            string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            string[] sysFormatTrack = sysFormat.ToString().Replace("-", "/").Split('/');

            if (sysFormatTrack.Length > 0)
            {
                for (int i = 0; i < sysFormatTrack.Length; i++)
                {
                    if (sysFormatTrack[i].ToString().ToUpper().Contains("M"))
                    {
                        mmIndex = i;
                    }
                    if (sysFormatTrack[i].ToString().ToUpper().Contains("D"))
                    {
                        ddIndex = i;
                    }
                    if (sysFormatTrack[i].ToString().ToUpper().Contains("Y"))
                    {
                        yyIndex = i;
                    }
                }
            }
            if (DateStringFormat.Length > 2)
            {
                if (Convert.ToInt32(DateStringFormat[mmIndex].ToString().Trim()) > 12)
                {
                    date = DateStringFormat[yyIndex].ToString().Trim().Substring(0, 4).Trim() + "-"
                         + (DateStringFormat[ddIndex].ToString().Trim().Length == 1 ? "0" + DateStringFormat[ddIndex].ToString().Trim() : DateStringFormat[ddIndex].ToString().Trim()) + "-"
                         + (DateStringFormat[mmIndex].ToString().Trim().Length == 1 ? "0" + DateStringFormat[mmIndex].ToString().Trim() : DateStringFormat[mmIndex].ToString().Trim());
                }
                else
                {
                    date = DateStringFormat[yyIndex].ToString().Trim().Substring(0, 4).Trim() + "-"
                         + (DateStringFormat[mmIndex].ToString().Trim().Length == 1 ? "0" + DateStringFormat[mmIndex].ToString().Trim() : DateStringFormat[mmIndex].ToString().Trim()) + "-"
                         + (DateStringFormat[ddIndex].ToString().Trim().Length == 1 ? "0" + DateStringFormat[ddIndex].ToString().Trim() : DateStringFormat[ddIndex].ToString().Trim());
                }
            }
            else
            {
                date = DateString;
            }


            return date;
        }

        /// <summary>
        /// Encoding of any string value to SHA1 hashing it is mainly used for password save
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        //public static string Encode(string value)
        //{
        //    var hash = System.Security.Cryptography.SHA1.Create();
        //    var encoder = new System.Text.ASCIIEncoding();
        ////////    var combined = encoder.GetBytes(value ?? "");
        //    return BitConverter.ToString(hash.ComputeHash(combined)).ToLower().Replace("-", "");
        //}
        /// <summary>
        /// Password Decode
        /// </summary>
        /// <param name="encrString"></param>
        /// <returns></returns>
        public static string Decode(string encrString)
        {
            string decryptpwd = string.Empty;
            UTF8Encoding encodepwd = new UTF8Encoding();
            Decoder Decode = encodepwd.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encrString);
            int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            decryptpwd = new String(decoded_char);
            return decryptpwd;
        }
        /// <summary>
        /// Password Encode
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string Encode(string password)
        {
            string strmsg = string.Empty;
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            strmsg = Convert.ToBase64String(encode);
            return strmsg;
        }
        /// <summary>
        /// This is to encrypt the url parameter
        /// </summary>
        /// <param name="inputText"></param>
        /// <returns></returns>
        public static string Encrypt(string inputText)
        {
            string encryptionkey = "SAUW193BX628TD57";
            byte[] keybytes = Encoding.ASCII.GetBytes(encryptionkey.Length.ToString());
            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] plainText = Encoding.Unicode.GetBytes(inputText);
            PasswordDeriveBytes pwdbytes = new PasswordDeriveBytes(encryptionkey, keybytes);
            using (ICryptoTransform encryptrans = rijndaelCipher.CreateEncryptor(pwdbytes.GetBytes(32), pwdbytes.GetBytes(16)))
            {
                using (MemoryStream mstrm = new MemoryStream())
                {
                    using (CryptoStream cryptstm = new CryptoStream(mstrm, encryptrans, CryptoStreamMode.Write))
                    {
                        cryptstm.Write(plainText, 0, plainText.Length);
                        cryptstm.Close();
                        return Convert.ToBase64String(mstrm.ToArray());
                    }
                }
            }
        }
        /// <summary>
        /// This is decrypt the url parameter
        /// </summary>
        /// <param name="encryptText"></param>
        /// <returns></returns>
        public static string Decrypt(string encryptText)
        {
            string encryptionkey = "SAUW193BX628TD57";
            byte[] keybytes = Encoding.ASCII.GetBytes(encryptionkey.Length.ToString());
            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] encryptedData = Convert.FromBase64String(encryptText.Replace(" ", "+"));
            PasswordDeriveBytes pwdbytes = new PasswordDeriveBytes(encryptionkey, keybytes);
            using (ICryptoTransform decryptrans = rijndaelCipher.CreateDecryptor(pwdbytes.GetBytes(32), pwdbytes.GetBytes(16)))
            {
                using (MemoryStream mstrm = new MemoryStream(encryptedData))
                {
                    using (CryptoStream cryptstm = new CryptoStream(mstrm, decryptrans, CryptoStreamMode.Read))
                    {
                        byte[] plainText = new byte[encryptedData.Length];
                        int decryptedCount = cryptstm.Read(plainText, 0, plainText.Length);
                        return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                    }
                }
            }
        }

        public static void ExceptionLogger(Exception ex,string ControllerName,string ActionName)
        {
            ExceptionLogger logger = new ExceptionLogger()
            {
                ExceptionMessage = ex.Message,
                ExceptionStackTrace = ex.StackTrace,
                ControllerName = ControllerName,
                ActionName = ActionName,
                LogTime = DateTime.Now
            };

            ExceptionRepository exceptionRepository = new ExceptionRepository();
            exceptionRepository.InsertExceptionLogger(logger);
        }

        public static string GenerateRandomPassword(int PasswordLength)
        {
            string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
            Random randNum = new Random();
            char[] chars = new char[PasswordLength];
            int allowedCharCount = _allowedChars.Length;
            for (int i = 0; i < PasswordLength; i++)
            {
                chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
            }
            return new string(chars);
        }


    }
}
