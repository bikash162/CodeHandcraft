﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Utitlity
{
    public class SessionNames
    {
        public SessionNames()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        //public string CurrentUser = "CurrentUser";
        //public const string CurrentMenus = "CurrentMenus";
        private static string _currentUser = string.Empty;
        public static string CurrentUser
        {
            get
            {               
                return _currentUser;
            }
            set
            {
                _currentUser = value;
            }
        }

        private static string _currentMenu = string.Empty;
        public static string CurrentMenus
        {
            get
            {
                return _currentMenu;
            }
            set
            {
                _currentMenu = value;
            }
        }
    }
}
