﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Customers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Repository.Customers
{
  public class CustomerContactsRepository
  {

    public SqlHelper objSqlHelper = null;

    public CustomerContactsRepository()
    {
      this.objSqlHelper = new SqlHelper();
    }
    /// <summary>
    /// <Insert Customer user against CustomerID>
    /// </summary>
    /// <param name="CustomerUser"></param>
    /// <returns></returns>
    public DMLReturn InsertCustomerContact(CustomerContacts CustomerContact)
    {
      try
      {
        string spQuery = "[Customer].[usp_InsertCustomerContact]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerContact.CustomerID),
                    new SqlParameter("@CustomerContactName",CustomerContact.CustomerContactName),
                    new SqlParameter("@CustomerContactEmail",CustomerContact.CustomerContactEmail),  
                    new SqlParameter("@CustomerContactPhoneNumber",CustomerContact.CustomerContactPhoneNumber), 
                    new SqlParameter("@CustomerContactDesignation",CustomerContact.CustomerContactDesignation),  
                    new SqlParameter("@CustomerContactRemark",CustomerContact.CustomerContactRemark),
                    new SqlParameter("@UserName",CustomerContact.UserName),
                    new SqlParameter("@UserPassword",ServiceLayer.Utitlity.CommonHelper.Encode(CustomerContact.UserPassword)),
                    new SqlParameter("@IsPrimary",CustomerContact.IsPrimary),   
                    new SqlParameter("@CreatedBy",CustomerContact.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 10, 11);
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <Update Customer user by Customeruserid>
    /// </summary>
    /// <param name="CustomerUser"></param>
    /// <returns></returns>
    public DMLReturn UpdateCustomerContact(CustomerContacts CustomerContact)
    {
      try
      {
        string spQuery = "[Customer].[usp_UpdateCustomerContact]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerContact.CustomerID),
                    new SqlParameter("@CustomerContactID",CustomerContact.CustomerContactID),
                    new SqlParameter("@CustomerContactName",CustomerContact.CustomerContactName),
                    new SqlParameter("@CustomerContactEmail",CustomerContact.CustomerContactEmail),
                    new SqlParameter("@CustomerContactPhoneNumber",CustomerContact.CustomerContactPhoneNumber),
                    new SqlParameter("@CustomerContactDesignation",CustomerContact.CustomerContactDesignation),   
                    new SqlParameter("@CustomerContactRemark",CustomerContact.CustomerContactRemark),   
                    new SqlParameter("@UserPassword",ServiceLayer.Utitlity.CommonHelper.Encode(CustomerContact.UserPassword)),   
                    new SqlParameter("@IsPrimary",CustomerContact.IsPrimary),   
                    new SqlParameter("@IsActive",CustomerContact.IsActive),   
                    new SqlParameter("@ModifiedBy",CustomerContact.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 11, 12);
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <Customer Users Listing>
    /// </summary>
    /// <param name="page"></param>
    /// <param name="pagesize"></param>
    /// <param name="sortBy"></param>
    /// <param name="ascending"></param>
    /// <returns></returns>
    public CustomerContactsViewModel GetCustomerContactList(long CustomerID, int? page, int? pagesize, string sortBy, bool ascending)
    {
      try
      {
        int totalRecords = 0;
        page = page == null ? 1 : page;
        pagesize = pagesize == null ? 10 : pagesize;
        Customer oCustomer = new Customer();
        oCustomer.startRowIndex = Convert.ToInt32(page);
        oCustomer.maximumRows = Convert.ToInt32(pagesize);
        oCustomer.SortBy = sortBy == null ? "CustomerContactID" : sortBy;
        oCustomer.SortAscending = ascending;

        DataTable dt = new DataTable();
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerID),
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

        CustomerContactsViewModel oCustomerContactsViewModel = new CustomerContactsViewModel();
        dt = objSqlHelper.ExecuteQuery("[Customer].[usp_GetCustomerContactsList]", parameters);
        List<CustomerContacts> oCustomerContactList = new List<CustomerContacts>();

        if (dt.Rows.Count > 0)
        {
          oCustomerContactList = (from DataRow row in dt.Rows
                                  select new CustomerContacts
                                  {
                                    CustomerContactID = Convert.ToInt32(row["CustomerContactID"]),
                                    CustomerContactName = Convert.ToString(row["CustomerContactName"]),
                                    CustomerContactEmail = Convert.ToString(row["CustomerContactEmail"]),
                                    CustomerContactPhoneNumber = Convert.ToString(row["CustomerContactPhoneNumber"]),
                                    CustomerContactDesignation = Convert.ToString(row["CustomerContactDesignation"]),
                                    CustomerContactStatus = Convert.ToString(row["CustomerContactStatus"]),
                                    IsActive = Convert.ToBoolean(row["IsActive"]),
                                    IsPrimary = Convert.ToBoolean(row["IsPrimary"]),
                                    UserName = Convert.ToString(row["UserName"]),
                                    RowNumber = Convert.ToInt32(row["RowNumber"].ToString())
                                  }).ToList();
          if (oCustomerContactList.Count() > 0)
          {
            totalRecords = oCustomerContactList[(oCustomerContactList.Count - 1)].RowNumber;
            oCustomerContactList.RemoveAt((oCustomerContactList.Count - 1));
          }

          var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "CustomerContact", oCustomer.SortBy, oCustomer.SortAscending, "tblCustomerContact", "FormCustomerContact", "CustomerContact");
          oCustomerContactsViewModel.oCustomerContactsList = oCustomerContactList;
          oCustomerContactsViewModel.pagerAndSort = pager;
        }
        return oCustomerContactsViewModel;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <Getting all the Contact Customers list based on CustomerID>
    /// </summary>
    /// <returns></returns>
    public List<CustomerContacts> GetAllCustomerContactsByCustomerID(long CustomerID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Customer].[usp_GetAllCustomerContactsByCustomerID]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerID),                   
                };
        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        List<CustomerContacts> oCustomerContactsList = new List<CustomerContacts>();

        if (dt.Rows.Count > 0)
        {
          oCustomerContactsList = (from DataRow row in dt.Rows
                           select new CustomerContacts
                           {
                             CustomerContactID = Convert.ToInt64(row["CustomerContactID"]),
                             CustomerContactName = Convert.ToString(row["CustomerContactName"]),
                             IsPrimary = Convert.ToBoolean(row["IsPrimary"])
                           }).ToList();
        }
        return oCustomerContactsList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    



    /// <summary>
    /// <Get Customer user by CustomerUserid>
    /// </summary>
    /// <param name="CustomerUserID"></param>
    /// <returns></returns>
    public CustomerContacts GetCustomerContactByID(long CustomerContactID)
    {
      try
      {
        DataSet ds = new DataSet();
        string sQuery = "[Customer].[usp_GetCustomerContactByID]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerContactID",CustomerContactID),                   
                };

        ds = objSqlHelper.ExecuteQueryList(sQuery, parameters);

        CustomerContacts oCustomerContactList = new CustomerContacts();

        if (ds.Tables[0].Rows.Count > 0)
        {
          oCustomerContactList.CustomerContactID = Convert.ToInt32(ds.Tables[0].Rows[0]["CustomerContactID"].ToString());
          oCustomerContactList.CustomerID = Convert.ToInt64(ds.Tables[0].Rows[0]["CustomerID"].ToString());
          oCustomerContactList.CustomerContactName = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactName"]);
          oCustomerContactList.CustomerContactEmail = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactEmail"]);
          oCustomerContactList.CustomerContactPhoneNumber = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactPhoneNumber"]);
          oCustomerContactList.CustomerContactDesignation = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactDesignation"]);
          oCustomerContactList.CustomerContactRemark = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactRemark"]);
          oCustomerContactList.UserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
          oCustomerContactList.UserPassword = ServiceLayer.Utitlity.CommonHelper.Decode(Convert.ToString(ds.Tables[0].Rows[0]["UserPassword"]));
          oCustomerContactList.IsPrimary = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPrimary"]);
          oCustomerContactList.IsActive = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsActive"]);
        }
        return oCustomerContactList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <checking the username of the customercontact exist or not>
    /// </summary>
    /// <param name="UserName"></param>
    /// <returns></returns>
    public int CheckCustomerContactUserNameExists(string UserName)
    {
      int retval = 0;
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Customer].[usp_CheckCustomerContactUserNameExists]";
        object[] parameters = 
                {
                    new SqlParameter("@UserName",UserName),                   
                };

        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);


        if (dt.Rows.Count > 0)
        {
          retval = Convert.ToInt32(dt.Rows[0]["Retval"]);
        }
        return retval;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    public void Dispose()
    {
      objSqlHelper.Dispose();
    }

  }
}
