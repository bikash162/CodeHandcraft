﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Customers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Repository.Customers
{
  public class CustomerRepository
  {
    public SqlHelper objSqlHelper = null;

    public CustomerRepository()
    {
      this.objSqlHelper = new SqlHelper();
    }

    /// <summary>
    /// <Get Customer Page and Search based on Customer name>
    /// </summary>
    /// <param name="page"></param>
    /// <param name="pagesize"></param>
    /// <param name="sortBy"></param>
    /// <param name="ascending"></param>
    /// <param name="SearchCustomerName"></param>
    /// <returns></returns>
    public CustomerViewModel GetCustomerList(int? page, int? pagesize, string sortBy, bool ascending, string SearchCustomerName, string SearchPhoneNumber, string SearchEmailAddress)
    {
      try
      {
        int totalRecords = 0;
        page = page == null ? 1 : page;
        pagesize = pagesize == null ? 10 : pagesize;
        Customer oCustomer = new Customer();
        oCustomer.startRowIndex = Convert.ToInt32(page);
        oCustomer.maximumRows = Convert.ToInt32(pagesize);
        oCustomer.SortBy = sortBy == null ? "CustomerID" : sortBy;
        oCustomer.SortAscending = ascending;

        DataTable dt = new DataTable();
        object[] parameters = 
                {
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SearchCustomerName",SearchCustomerName),
                    new SqlParameter("@SearchPhoneNumber",SearchPhoneNumber),
                    new SqlParameter("@SearchEmailAddress",SearchEmailAddress),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

        CustomerViewModel oCustomerViewModel = new CustomerViewModel();
        dt = objSqlHelper.ExecuteQuery("[Customer].[usp_GetCustomerList]", parameters);
        List<Customer> oCustomerList = new List<Customer>();

        if (dt.Rows.Count > 0)
        {
          oCustomerList = (from DataRow row in dt.Rows
                           select new Customer
                         {
                           CustomerID = Convert.ToInt64(row["CustomerID"].ToString()),
                           CustomerName = Convert.ToString(row["CustomerName"]),
                           CustomerEmail = Convert.ToString(row["CustomerEmail"]),
                           Remarks = Convert.ToString(row["Remarks"]),
                           CustomerStatus = Convert.ToString(row["CustomerStatus"]),
                           Address = Convert.ToString(row["Address"]),
                           PhoneNo = Convert.ToString(row["PhoneNo"]),
                           MobileNo = Convert.ToString(row["MobileNo"]),
                           PostCode = Convert.ToString(row["PostCode"]),

                           DefaultContactName = Convert.ToString(row["CustomerContactName"]),
                           DefaultContactEmail = Convert.ToString(row["CustomerContactEmail"]),
                           DefaultContactPhoneNo = Convert.ToString(row["CustomerContactPhoneNumber"]),
                           DefaultContactDesignation = Convert.ToString(row["CustomerContactDesignation"]),
                           UserID = Convert.ToString(row["UserName"]),

                           RowNumber = Convert.ToInt32(row["RowNumber"].ToString())
                         }).ToList();
          if (oCustomerList.Count() > 0)
          {
            totalRecords = oCustomerList[(oCustomerList.Count - 1)].RowNumber;
            oCustomerList.RemoveAt((oCustomerList.Count - 1));
          }

          var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "Customer", oCustomer.SortBy, oCustomer.SortAscending, "", "form-customer-listing", "Customer");
          oCustomerViewModel.Customers = oCustomerList;
          oCustomerViewModel.pagerAndSort = pager;
        }
        return oCustomerViewModel;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <Get Customer By ID>
    /// </summary>
    /// <param name="CustomerID"></param>
    /// <returns></returns>
    public Customer GetCustomerByID(long CustomerID)
    {
      try
      {
        DataSet ds = new DataSet();
        string sQuery = "[Customer].[usp_GetCustomerByID]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerID),                   
                };

        ds = objSqlHelper.ExecuteQueryList(sQuery, parameters);

        Customer oCustomerList = new Customer();

        if (ds.Tables[0].Rows.Count > 0)
        {
          oCustomerList.CustomerID = Convert.ToInt64(ds.Tables[0].Rows[0]["CustomerID"]);
          oCustomerList.CustomerName = Convert.ToString(ds.Tables[0].Rows[0]["CustomerName"]);
          oCustomerList.CustomerEmail = Convert.ToString(ds.Tables[0].Rows[0]["CustomerEmail"]);

          oCustomerList.PhoneNo = Convert.ToString(ds.Tables[0].Rows[0]["PhoneNo"]);
          oCustomerList.MobileNo = Convert.ToString(ds.Tables[0].Rows[0]["MobileNo"]);
          oCustomerList.Address = Convert.ToString(ds.Tables[0].Rows[0]["Address"]);
          oCustomerList.CountryId = Convert.ToInt32(ds.Tables[0].Rows[0]["CountryId"]);
          oCustomerList.CityId = Convert.ToInt32(ds.Tables[0].Rows[0]["CityId"]);
          oCustomerList.PostCode = Convert.ToString(ds.Tables[0].Rows[0]["PostCode"]);
          oCustomerList.IsActive = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsActive"]);

          oCustomerList.DefaultContactName = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactName"]);
          oCustomerList.DefaultContactEmail = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactEmail"]);
          oCustomerList.DefaultContactPhoneNo = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactPhoneNumber"]);
          oCustomerList.DefaultContactDesignation = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactDesignation"]);
          oCustomerList.Remarks = Convert.ToString(ds.Tables[0].Rows[0]["CustomerContactRemark"]);
          oCustomerList.UserID = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
          oCustomerList.UserPassword = ServiceLayer.Utitlity.CommonHelper.Decode(Convert.ToString(ds.Tables[0].Rows[0]["UserPassword"]));
          
          oCustomerList.CountryName = Convert.ToString(ds.Tables[0].Rows[0]["CountryName"]);
          oCustomerList.CityName = Convert.ToString(ds.Tables[0].Rows[0]["CityName"]);
        
        
        
        }
        return oCustomerList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <getting all the customers when creating a new job>
    /// </summary>
    /// <returns></returns>
    public List<Customer> GetAllCustomersList()
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Customer].[usp_GetAllCustomersList]";
        dt = objSqlHelper.ExecuteQuery(sQuery);
        List<Customer> oCustomerList = new List<Customer>();

        if (dt.Rows.Count > 0)
        {
          oCustomerList = (from DataRow row in dt.Rows
                           select new Customer
                           {
                             CustomerID = Convert.ToInt64(row["CustomerID"].ToString()),
                             CustomerName = row["CustomerName"].ToString()
                           }).ToList();
        }
        return oCustomerList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <May be this method is not be in used anywhere>
    /// </summary>
    /// <returns></returns>
    public List<Customer> GetAllCustomers()
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Administration].[usp_GetCustomerById]";
        //object[] parameters = 
        //    {
        //        new SqlParameter("@CustomerID",CustomerID),                   
        //    };

        dt = objSqlHelper.ExecuteQuery(sQuery);
        List<Customer> oCustomerList = new List<Customer>();

        if (dt.Rows.Count > 0)
        {
          oCustomerList = (from DataRow row in dt.Rows
                           select new Customer
                         {
                           CustomerID = Convert.ToInt64(row["CustomerID"].ToString()),
                           CustomerName = row["CustomerName"].ToString()
                         }).ToList();
        }
        return oCustomerList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <Insert New Customer>
    /// </summary>
    /// <param name="Customer"></param>
    /// <param name="CreatedBy"></param>
    /// <returns></returns>
    public DMLReturn InsertCustomer(CustomerViewModel customerViewModel)
    {
      try
      {
        string spQuery = "[Customer].[usp_InsertCustomer]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerName",customerViewModel.Customer.CustomerName),
                    new SqlParameter("@CustomerEmail",customerViewModel.Customer.CustomerEmail),
                    new SqlParameter("@PhoneNo",customerViewModel.Customer.PhoneNo),                
                    new SqlParameter("@MobileNo",customerViewModel.Customer.MobileNo),                
                    new SqlParameter("@Address",customerViewModel.Customer.Address),                
                    new SqlParameter("@CountryId",customerViewModel.Customer.CountryId),                
                    new SqlParameter("@CityId",customerViewModel.Customer.CityId),                
                    new SqlParameter("@PostCode",customerViewModel.Customer.PostCode),                
                    new SqlParameter("@UserID",customerViewModel.Customer.UserID),                
                    new SqlParameter("@UserPassword",ServiceLayer.Utitlity.CommonHelper.Encode(customerViewModel.Customer.UserPassword)),   
                    new SqlParameter("@DefaultContactName",customerViewModel.Customer.DefaultContactName),                
                    new SqlParameter("@DefaultContactEmail",customerViewModel.Customer.DefaultContactEmail),                
                    new SqlParameter("@DefaultContactPhoneNo",customerViewModel.Customer.DefaultContactPhoneNo),                
                    new SqlParameter("@DefaultContactDesignation",customerViewModel.Customer.DefaultContactDesignation),  
                    new SqlParameter("@Remarks",customerViewModel.Customer.Remarks),                
                    new SqlParameter("@CreatedBy",customerViewModel.Customer.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 16, 17);      
       
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    /// <summary>
    /// <update the Customer>
    /// </summary>
    /// <param name="CustomerViewModel"></param>
    /// <returns></returns>
    public int UpdateCustomer(CustomerViewModel CustomerViewModel, out string ReturnOutput)
    {
      int result = 0;
      try
      {
        string spQuery = "[Customer].[usp_UpdateCustomer]";
        object[] parameters = 
                {
                    new SqlParameter("@CustomerID",CustomerViewModel.Customer.CustomerID),
                    new SqlParameter("@CustomerName",CustomerViewModel.Customer.CustomerName),
                    new SqlParameter("@CustomerEmail",CustomerViewModel.Customer.CustomerEmail),

                    new SqlParameter("@PhoneNo",CustomerViewModel.Customer.PhoneNo),                
                    new SqlParameter("@MobileNo",CustomerViewModel.Customer.MobileNo),                
                    new SqlParameter("@Address",CustomerViewModel.Customer.Address),                
                    new SqlParameter("@CountryId",CustomerViewModel.Customer.CountryId),                
                    new SqlParameter("@CityId",CustomerViewModel.Customer.CityId),                
                    new SqlParameter("@PostCode",CustomerViewModel.Customer.PostCode),                
                    new SqlParameter("@UserID",CustomerViewModel.Customer.UserID),                
                    new SqlParameter("@UserPassword",ServiceLayer.Utitlity.CommonHelper.Encode(CustomerViewModel.Customer.UserPassword)),                

                    new SqlParameter("@DefaultContactName",CustomerViewModel.Customer.DefaultContactName),                
                    new SqlParameter("@DefaultContactEmail",CustomerViewModel.Customer.DefaultContactEmail),                
                    new SqlParameter("@DefaultContactPhoneNo",CustomerViewModel.Customer.DefaultContactPhoneNo),                
                    new SqlParameter("@DefaultContactDesignation",CustomerViewModel.Customer.DefaultContactDesignation),                

                    new SqlParameter("@Remarks",CustomerViewModel.Customer.Remarks),                
                    new SqlParameter("@IsActive",CustomerViewModel.Customer.IsActive),                

                    new SqlParameter("@ModifiedBy",CustomerViewModel.Customer.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };

            DMLReturn oDML = objSqlHelper.ExecuteCommand(spQuery, parameters, 18, 19);
            ReturnOutput = oDML.ReturnMessage;
            result = oDML.ReturnValue;
            return result;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }



    public List<Customer> GetCountryList()
    {
      try
      {
        string spQuery = "[Administration].[usp_GetCountry]";
        DataTable dt = new DataTable();
        dt = objSqlHelper.ExecuteQuery(spQuery);
        List<Customer> oCountryList = new List<Customer>();
        if (dt.Rows.Count > 0)
        {
          oCountryList = (from DataRow row in dt.Rows
                          select new Customer
                          {
                            CountryId = Convert.ToInt32(row["CountryId"].ToString()),
                            CountryName = row["CountryName"].ToString()
                          }).ToList();
        }

        return oCountryList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <City Names are populated based on CountryId>
    /// </summary>
    /// <param name="CountryId"></param>
    /// <returns></returns>
    public List<Customer> GetCityList(int CountryId)
    {
      try
      {
        string spQuery = "[Administration].[usp_GetCityList]";
        DataTable dt = new DataTable();
        object[] parameters = 
                { 
                    new SqlParameter("@CountryID",CountryId),
                };
        dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
        List<Customer> oCityList = new List<Customer>();
        if (dt.Rows.Count > 0)
        {
          oCityList = (from DataRow row in dt.Rows
                       select new Customer
                       {
                         CityId = Convert.ToInt32(row["CityId"].ToString()),
                         CityName = row["CityName"].ToString()
                       }).ToList();
        }
        return oCityList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    public void Dispose()
    {
      objSqlHelper.Dispose();
    }


  }
}
