﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Master;

namespace ServiceLayer.Repository.Master
{
  public class FileUploadSettingsRepository
  {
    public SqlHelper objSqlHelper = null;

    public FileUploadSettingsRepository()
    {
      this.objSqlHelper = new SqlHelper();
    }
    /// <summary>
    /// <Getting File upload settings list>
    /// </summary>
    /// <returns></returns>
    public List<FileUploadSettings> GetFileUploadSettingsList()
    {
      try
      {
        DataTable dt = new DataTable();

        dt = objSqlHelper.ExecuteQuery("[Master].[usp_GetFileUploadSettingsList]");
        List<FileUploadSettings> oFileUploadSettingsList = new List<FileUploadSettings>();

        if (dt.Rows.Count > 0)
        {
          foreach (DataRow row in dt.Rows)
          {
            FileUploadSettings oFileUploadSettings = new FileUploadSettings();
            oFileUploadSettings.ID = Convert.ToInt32(row["ID"]);
            oFileUploadSettings.Path = Convert.ToString(row["Path"]);
            oFileUploadSettings.FolderName = Convert.ToString(row["FolderName"]);
            oFileUploadSettings.Domain = Convert.ToString(row["Domain"]);
            oFileUploadSettings.Port = Convert.ToInt32(row["Port"]);
            oFileUploadSettings.Type = Convert.ToInt32(row["Type"]);
            oFileUploadSettings.Username = Convert.ToString(row["Username"]);

            ///<For FTP Settings and Network settings The Password is needed; for Local settings it is not needed>
            if (oFileUploadSettings.Type == 1 || oFileUploadSettings.Type == 2)
            {
              oFileUploadSettings.Password = CommonHelper.Decode(Convert.ToString(row["Password"]));
              //oFileUploadSettings.Password = Convert.ToString(row["Password"]);
            }
            else
            {
              oFileUploadSettings.Password = "";
            }

            oFileUploadSettings.SSLEnable = Convert.ToBoolean(row["SSLEnable"]);
            oFileUploadSettings.IsActive = Convert.ToBoolean(row["IsActive"]);
            oFileUploadSettingsList.Add(oFileUploadSettings);
          }
        }
        return oFileUploadSettingsList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    public FileUploadSettings GetFileUploadSettingsById(int Id)
    {
        var result = GetFileUploadSettingsList().Where(y => y.ID == Id).FirstOrDefault();
        return result;
    }

    public DMLReturn InsertFileUploadSettings(FileUploadSettings oFileUploadSettings)
    {
      try
      {
        string spQuery = "[Master].[usp_InsertFileUploadSettings]";
        object[] parameters = 
                {                   
                    new SqlParameter("@Path",oFileUploadSettings.Path),
                    new SqlParameter("@FolderName",oFileUploadSettings.FolderName),
                    new SqlParameter("@Domain",oFileUploadSettings.Domain),
                    new SqlParameter("@Port",oFileUploadSettings.Port),
                    new SqlParameter("@Type",oFileUploadSettings.Type),
                    new SqlParameter("@Username",oFileUploadSettings.Username),
                    new SqlParameter("@Password",oFileUploadSettings.Password),
                    new SqlParameter("@SSLEnable",oFileUploadSettings.SSLEnable),
                    new SqlParameter("@CreatedBy",oFileUploadSettings.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 9, 10);
      }
      catch (Exception exc)
      {
        throw exc;
      }
    }


    public DMLReturn UpdateFileUploadSettings(FileUploadSettings oFileUploadSettings)
    {
      try
      {
        string spQuery = "[Master].[usp_UpdateFileUploadSettings]";
        object[] parameters = 
                {                   
                    new SqlParameter("@ID",oFileUploadSettings.ID),
                    new SqlParameter("@Path",oFileUploadSettings.Path),
                    new SqlParameter("@FolderName",oFileUploadSettings.FolderName),
                    new SqlParameter("@Domain",oFileUploadSettings.Domain),
                    new SqlParameter("@Port",oFileUploadSettings.Port),
                    new SqlParameter("@Type",oFileUploadSettings.Type),
                    new SqlParameter("@Username",oFileUploadSettings.Username),
                    new SqlParameter("@Password",oFileUploadSettings.Password),
                    new SqlParameter("@SSLEnable",oFileUploadSettings.SSLEnable),
                    new SqlParameter("@ModifiedBy",oFileUploadSettings.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 10, 11);
      }
      catch (Exception exc)
      {
        throw exc;
      }
    }
    
    public DMLReturn ActivateFileUploadSettings(string ID, bool status)
    {
      try
      {
        string spQuery = "[Master].[usp_ActivateFileUploadSettings]";
        object[] parameters = 
                {                   
                    new SqlParameter("@ID",Convert.ToInt32(ID==""?"0":ID)),  
                    new SqlParameter("@IsActive",status),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 2, 3);
      }
      catch (Exception exc)
      {
        throw exc;
      }
    }

    public void Dispose()
    {
      objSqlHelper.Dispose();
    }

  }
}
