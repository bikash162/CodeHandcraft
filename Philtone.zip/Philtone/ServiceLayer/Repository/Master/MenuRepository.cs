﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.ViewModel.Master;
using System.Data;
using System.Data.SqlClient;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Repository.Master
{
    public class MenuRepository
    {
        public SqlHelper objSqlHelper = null;

        public MenuRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }
        /// <summary>
        /// First Table contains the module,
        /// Second Table contains the parent menu
        /// Third Table contains the pages 
        /// Logic goes for populating in razor is that, first module list is populated then each moduleid is based parent menu is fetched
        /// from Second table and populated then from Second Table each parent menu id is used to fetch pages against the each parent menu
        /// from Third Table
        /// </summary>
        /// <returns></returns>
        public MenuViewModel GetMenuList()
        {
            try
            {                

                MenuViewModel oMenuViewModel = new MenuViewModel();
                DataSet ds = objSqlHelper.ExecuteQueryList("[Master].usp_GetMenuList");
                List<Menu> oModuleList = new List<Menu>();
                List<Menu> oMenuList = new List<Menu>();
                List<Menu> oPageList = new List<Menu>();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    oModuleList = (from DataRow row in ds.Tables[0].Rows

                                 select new Menu
                                 {
                                     MenuID = Convert.ToInt32(row["MenuID"].ToString()),
                                     MenuName = row["MenuName"].ToString(),
                                     IsThirdParty = Convert.ToBoolean(row["IsThirdParty"].ToString()),
                                     MenuUrl = row["MenuUrl"].ToString(),
                                     MenuIcon = row["MenuIcon"].ToString(),
                                     ParentMenuID = Convert.ToInt32(row["ParentMenuID"].ToString()),
                                     DisplayOrder = Convert.ToInt32(row["DisplayOrder"].ToString()),
                                     IsActive = Convert.ToBoolean(row["IsActive"])
                                 }).ToList();
                    
                }
                oMenuViewModel.Modules = oModuleList;
                if (ds.Tables[1].Rows.Count > 0)
                {
                    oMenuList = (from DataRow row in ds.Tables[1].Rows

                                 select new Menu
                                 {
                                     MenuID = Convert.ToInt32(row["MenuID"].ToString()),
                                     MenuName = row["MenuName"].ToString(),
                                     IsThirdParty = Convert.ToBoolean(row["IsThirdParty"].ToString()),
                                     MenuUrl = row["MenuUrl"].ToString(),
                                     MenuIcon = row["MenuIcon"].ToString(),
                                     ParentMenuID = Convert.ToInt32(row["ParentMenuID"].ToString()),
                                     DisplayOrder = Convert.ToInt32(row["DisplayOrder"].ToString()),
                                     IsActive = Convert.ToBoolean(row["IsActive"])
                                 }).ToList();
                    
                }
                oMenuViewModel.Menus = oMenuList;              
                if (ds.Tables[2].Rows.Count > 0)
                {
                    oPageList = (from DataRow row in ds.Tables[2].Rows

                                 select new Menu
                                 {
                                     MenuID = Convert.ToInt32(row["MenuID"].ToString()),
                                     MenuName = row["MenuName"].ToString(),
                                     IsThirdParty = Convert.ToBoolean(row["IsThirdParty"].ToString()),
                                     MenuUrl = row["MenuUrl"].ToString(),
                                     MenuIcon = row["MenuIcon"].ToString(),
                                     ParentMenuID = Convert.ToInt32(row["ParentMenuID"].ToString()),
                                     DisplayOrder = Convert.ToInt32(row["DisplayOrder"].ToString()),
                                     IsActive =Convert.ToBoolean(row["IsActive"])
                                 }).ToList();
                    
                }
                oMenuViewModel.PageLevelMenus = oPageList;              
                Menu oMenu = new Menu();
                oMenuViewModel.menu = oMenu;
                return oMenuViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        /// <summary>
        /// It fetches the parent menu of the pages within a module, so module Id is passed as parameter
        /// Module Id checks whether it has a parent menu then those are fetched and bind below module and then 
        /// respective pages within parent menu / module is binded 
        /// </summary>
        /// <param name="ModuleId"></param>
        /// <returns></returns>
        public List<Menu> GetParentMenu(int ModuleId)
        {
            var menuList = GetMenuList().Menus.Where(x=> x.ParentMenuID==ModuleId).ToList();
            return menuList;
        }
        /// <summary>
        /// It fetches the module list, it is mainly used after any successfull insertion/updation
        /// </summary>
        /// <returns></returns>
        public List<Menu> GetModule()
        {
            var moduleList = GetMenuList().Modules;
            return moduleList;
        }

        /// <summary>
        /// Insert new menu 
        /// </summary>
        /// <param name="menu"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>
        public DMLReturn AddEditMenu(Menu menu)
        {
            try
            {
                string spQuery = "[Master].[usp_AddEditMenu]";
                object[] parameters = 
                {
                    new SqlParameter("@MenuID",menu.MenuID),
                    new SqlParameter("@ParentMenuID",menu.ParentMenuID),
                    new SqlParameter("@IsThirdParty",menu.IsThirdParty),   
                    new SqlParameter("@MenuName",menu.MenuName),
                    new SqlParameter("@MenuUrl",menu.MenuUrl),                  
                    new SqlParameter("@MenuType",menu.MenuType.ToString().Trim()),
                    new SqlParameter("@IsActive",menu.IsActive==true?1:0),                       
                    new SqlParameter("@CreatedBy",menu.CreatedBy),
                    new SqlParameter("@EditID",menu.EditID),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 9, 10);
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }


        /// <summary>
        /// <Get Menu information based on MenuID>
        /// </summary>
        /// <param name="MenuID"></param>
        /// <returns></returns>
        public Menu GetMenuInfo(int MenuID)
        {
            try
            {
                DataTable dt = new DataTable();
                string sQuery = "[Master].[usp_GetMenuInfo]";
                object[] parameters = 
                {
                    new SqlParameter("@MenuID",MenuID),                   
                };
                dt = objSqlHelper.ExecuteQuery(sQuery, parameters);

                Menu oMenuInfo = new Menu();

                if (dt.Rows.Count > 0)
                {
                    oMenuInfo.MenuID = Convert.ToInt32(dt.Rows[0]["MenuID"]);
                    oMenuInfo.MenuName = Convert.ToString(dt.Rows[0]["MenuName"]);
                    oMenuInfo.MenuUrl = Convert.ToString(dt.Rows[0]["MenuUrl"]);
                    oMenuInfo.MenuIcon = Convert.ToString(dt.Rows[0]["MenuIcon"]);
                    oMenuInfo.ParentMenuID = Convert.ToInt32(dt.Rows[0]["ParentMenuID"]);
                    oMenuInfo.DisplayOrder = Convert.ToInt32(dt.Rows[0]["DisplayOrder"]);
                    oMenuInfo.IsModule = Convert.ToBoolean(dt.Rows[0]["IsModule"]);
                    oMenuInfo.IsParent = Convert.ToBoolean(dt.Rows[0]["IsParent"]);
                    oMenuInfo.IsActive = Convert.ToBoolean(dt.Rows[0]["IsActive"]);
                    oMenuInfo.ParentMenuName = Convert.ToString(dt.Rows[0]["ParentMenuName"]);
                    oMenuInfo.ModuleName = Convert.ToString(dt.Rows[0]["ModuleName"]);
                    oMenuInfo.ModuleID = Convert.ToInt32(dt.Rows[0]["ModuleID"]);
                }
                return oMenuInfo;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// Get Menu based on User Priviledge
        /// </summary>
        /// <param name="IsAdmin"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public MenuViewModel GetMenusByPriviledge(bool IsAdmin, int? UserID)
        {
            MenuViewModel oMenuViewModel = new MenuViewModel();
            DataSet ds = new DataSet();
            object[] parameters = 
                {
                    new SqlParameter("@IsAdmin",IsAdmin),
                    new SqlParameter("@UserID",UserID)
                };
            ds = objSqlHelper.ExecuteQueryList("[Master].[usp_GetMenusByPriviledge]", parameters);


            if (ds.Tables.Count > 0)
            {
                List<Menu> oModules = new List<Menu>();
                List<Menu> oMenus = new List<Menu>();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    oModules = (from DataRow row in ds.Tables[0].Rows
                                select new Menu
                                {
                                    MenuID = Convert.ToInt32(row["MenuID"].ToString()),
                                    MenuName = row["MenuName"].ToString(),
                                    IsThirdParty = Convert.ToBoolean(row["IsThirdParty"].ToString()),
                                    MenuUrl = row["MenuUrl"].ToString(),
                                    MenuIcon = row["MenuIcon"].ToString(),
                                    ParentMenuID = Convert.ToInt32(row["ParentMenuID"].ToString()),
                                    DisplayOrder = Convert.ToInt32(row["DisplayOrder"].ToString()),
                                    IsActive = Convert.ToBoolean(row["IsActive"].ToString())
                                }).ToList();
                }
                oMenuViewModel.Modules = oModules;

                if (ds.Tables[1].Rows.Count > 0)
                {
                    oMenus = (from DataRow row in ds.Tables[1].Rows
                                select new Menu
                                {
                                    MenuID = Convert.ToInt32(row["MenuID"].ToString()),
                                    MenuName = row["MenuName"].ToString(),
                                    IsThirdParty = Convert.ToBoolean(row["IsThirdParty"].ToString()),
                                    MenuUrl = row["MenuUrl"].ToString(),
                                    MenuIcon = row["MenuIcon"].ToString(),
                                    ParentMenuID = Convert.ToInt32(row["ParentMenuID"].ToString()),
                                    DisplayOrder = Convert.ToInt32(row["DisplayOrder"].ToString() == "" ? "0" : row["DisplayOrder"].ToString()),
                                    IsActive = Convert.ToBoolean(row["IsActive"].ToString())
                                }).ToList();
                }
                oMenuViewModel.Menus = oMenus;
            }
            return oMenuViewModel;
        }

        /// <summary>
        /// It is used to dispose sql object, implementation is done in sql helper class
        /// </summary>
        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
