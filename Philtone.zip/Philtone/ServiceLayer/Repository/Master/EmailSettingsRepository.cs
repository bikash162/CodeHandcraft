﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Master;

namespace ServiceLayer.Repository.Master
{
    public class EmailSettingsRepository
    {
        public SqlHelper objSqlHelper = null;

        public EmailSettingsRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        /// <summary>
        /// <Get Department Listing with paging and Sorting and Search based on Department name>
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public List<EmailSettings> GetEmailSettingsList()
        {
            try
            {
                
                DataTable dt = new DataTable();

                dt = objSqlHelper.ExecuteQuery("[Master].[usp_GetEmailSettingsList]");
                List<EmailSettings> oEmailSettingsList = new List<EmailSettings>();

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        EmailSettings oEmailSettings = new EmailSettings();
                        oEmailSettings.ID = Convert.ToInt32(row["ID"].ToString());
                        oEmailSettings.ProviderName = row["ProviderName"].ToString();
                        oEmailSettings.FromEmail = row["FromEmail"].ToString();
                        oEmailSettings.FromDisplayName = row["FromDisplayName"].ToString();
                        oEmailSettings.SmtpHost = row["SmtpHost"].ToString();
                        oEmailSettings.SmptPort = Convert.ToInt32(row["SmptPort"].ToString());
                        oEmailSettings.UseDefaultCredentials = Convert.ToBoolean(row["UseDefaultCredentials"].ToString());
                        oEmailSettings.CredentialUserName = row["CredentialUserName"].ToString();
                        oEmailSettings.CredentialPassword = CommonHelper.Decode(row["CredentialPassword"].ToString());
                        oEmailSettings.EnableSsl = Convert.ToBoolean(row["EnableSsl"].ToString());
                        oEmailSettings.IsActive = Convert.ToBoolean(row["IsActive"].ToString());

                        oEmailSettingsList.Add(oEmailSettings);
                    }
                }
                return oEmailSettingsList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        public EmailSettings GetEmailSettingsById(int Id)
        {
            var result = GetEmailSettingsList().Where(y => y.ID == Id).FirstOrDefault();
            return result;
        }

        public DMLReturn InsertEmailSettings(EmailSettings emailSettings)
        {
            try
            {
                string spQuery = "[Master].[usp_InsertEmailSettings]";
                object[] parameters = 
                {                   
                    new SqlParameter("@ProviderName",emailSettings.ProviderName),
                    new SqlParameter("@FromEmail",emailSettings.FromEmail),
                    new SqlParameter("@FromDisplayName",emailSettings.FromDisplayName),
                    new SqlParameter("@SmtpHost",emailSettings.SmtpHost),
                    new SqlParameter("@SmptPort",emailSettings.SmptPort),
                    new SqlParameter("@UseDefaultCredentials",emailSettings.UseDefaultCredentials),                    
                    new SqlParameter("@CredentialUserName",emailSettings.CredentialUserName),
                    new SqlParameter("@CredentialPassword",CommonHelper.Encode(emailSettings.CredentialPassword)),
                    new SqlParameter("@EnableSsl",emailSettings.EnableSsl),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 9, 10);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public DMLReturn UpdateEmailSettings(EmailSettings emailSettings)
        {
            try
            {
                string spQuery = "[Master].[usp_UpdateEmailSettings]";
                object[] parameters = 
                {                   
                    new SqlParameter("@ID",emailSettings.ID),  
                    new SqlParameter("@ProviderName",emailSettings.ProviderName),
                    new SqlParameter("@FromEmail",emailSettings.FromEmail),
                    new SqlParameter("@FromDisplayName",emailSettings.FromDisplayName),
                    new SqlParameter("@SmtpHost",emailSettings.SmtpHost),
                    new SqlParameter("@SmptPort",emailSettings.SmptPort),
                    new SqlParameter("@UseDefaultCredentials",emailSettings.UseDefaultCredentials),                    
                    new SqlParameter("@CredentialUserName",emailSettings.CredentialUserName),
                    new SqlParameter("@CredentialPassword",CommonHelper.Encode(emailSettings.CredentialPassword)),
                    new SqlParameter("@EnableSsl",emailSettings.EnableSsl),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 10, 11);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public DMLReturn ActivateEmailSettings(string Id, bool status)
        {
            try
            {
                string spQuery = "[Master].[usp_ActivateEmailSettings]";
                object[] parameters = 
                {                   
                    new SqlParameter("@ID",Convert.ToInt32(Id==""?"0":Id)),  
                    new SqlParameter("@IsActive",status),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 2, 3);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Dispose all Sql object
        /// </summary>
        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
