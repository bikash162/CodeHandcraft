﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Master;

namespace ServiceLayer.Repository.Master
{
    public class DepartmentRepository
    {
        public SqlHelper objSqlHelper = null;

        public DepartmentRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        /// <summary>
        /// <Get Department Listing with paging and Sorting and Search based on Department name>
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public DepartmentViewModel GetDepartments(int? page, int? pagesize, string sortBy, bool ascending, string SearchDepartmentName)
        {
            try
            {
                int totalRecords = 0;
                page = page == null ? 1 : page;
                pagesize = pagesize == null ? 10 : pagesize;
                Department oDepartment = new Department();
                oDepartment.startRowIndex = Convert.ToInt32(page);
                oDepartment.maximumRows = Convert.ToInt32(pagesize);
                oDepartment.SortBy = sortBy == null ? "Id" : sortBy;
                oDepartment.SortAscending = ascending;

                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SearchDepartmentname",SearchDepartmentName),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

                DepartmentViewModel oDepartmentViewModel = new DepartmentViewModel();
                dt = objSqlHelper.ExecuteQuery("[Master].[usp_GetDepartmentList]", parameters);
                List<Department> oDepartmentList = new List<Department>();

                if (dt.Rows.Count > 0)
                {
                    oDepartmentList = (from DataRow row in dt.Rows

                                       select new Department
                                       {
                                           DepartmentID = Convert.ToInt32(row["DepartmentID"].ToString()),
                                           DepartmentName = row["DepartmentName"].ToString(),
                                           DepartmentDescription = row["DepartmentDescription"].ToString(),
                                           DepartmentStatus = row["DepartmentStatus"].ToString(),
                                           RowNumber = Convert.ToInt32(row["RowNumber"].ToString())
                                       }).ToList();
                    if (oDepartmentList.Count() > 0)
                    {
                        totalRecords = oDepartmentList[(oDepartmentList.Count - 1)].RowNumber;
                        oDepartmentList.RemoveAt((oDepartmentList.Count - 1));
                    }

                    var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "Index", oDepartment.SortBy, oDepartment.SortAscending, "tblDepartment", "FormDepartment", "Department");
                    oDepartmentViewModel.DepartmentList = oDepartmentList;
                    oDepartmentViewModel.pagerAndSort = pager;
                }
                return oDepartmentViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// <Get Department based on Departmentid from database>
        /// </summary>
        /// <param name="DepartmentId"></param>
        /// <returns></returns>
        public Department GetDepartmentId(int DepartmentId)
        {
            try
            {
                string spQuery = "[Master].[usp_GetDepartmentById]";
                object[] parameters = 
                {
                    new SqlParameter("@DepartmentId",DepartmentId),
                };
                DataTable dt = new DataTable();
                Department oDepartment = new Department();
                dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
                if (dt.Rows.Count > 0)
                {
                    oDepartment.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"].ToString());
                    oDepartment.DepartmentName = dt.Rows[0]["DepartmentName"].ToString();
                    oDepartment.DepartmentDescription = dt.Rows[0]["DepartmentDescription"].ToString();
                }
                return oDepartment;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }

        }

        /// <summary>
        /// <Insert New Department>
        /// </summary>
        /// <param name="Departments"></param>
        /// <returns></returns>
        public DMLReturn InsertDepartment(DepartmentViewModel departmentViewModel)
        {
            try
            {
                string spQuery = "[Master].[usp_InsertDepartment]";
                object[] parameters = 
                {
                    new SqlParameter("@DepartmentName",departmentViewModel.Department.DepartmentName),
                    new SqlParameter("@DepartmentDescription",departmentViewModel.Department.DepartmentDescription),                
                    new SqlParameter("@CreatedBy",departmentViewModel.Department.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 3, 4);
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// <Update Department based on DepartmentId>
        /// </summary>
        /// <param name="DepartmentViewModel"></param>
        /// <returns></returns>
        public DMLReturn UpdateDepartment(DepartmentViewModel DepartmentViewModel)
        {
            try
            {
                string spQuery = "[Master].[usp_UpdateDepartment]";
                object[] parameters = 
                {
                    new SqlParameter("@DepartmentID",DepartmentViewModel.Department.DepartmentID),
                    new SqlParameter("@DepartmentName",DepartmentViewModel.Department.DepartmentName),
                    new SqlParameter("@DepartmentDescription",DepartmentViewModel.Department.DepartmentDescription),                                     
                    new SqlParameter("@ModifiedBy",DepartmentViewModel.Department.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 4, 5);
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// Dispose all Sql object
        /// </summary>
        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
