﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using ServiceLayer.Entity.Common;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Repository.Common
{
    public class ExceptionRepository
    {
        public SqlHelper objSqlHelper = null;

        public ExceptionRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        /// <summary>
        /// Log all the Exception 
        /// </summary>
        /// <param name="exceptionLoggers"></param>
        /// <returns></returns>
        public int InsertExceptionLogger(ExceptionLogger exceptionLoggers)
        {
            string spQuery = "[Common].[InsertExceptionLogger]";
            object[] parameters = 
                { 
                    new SqlParameter("@ExceptionMessage",exceptionLoggers.ExceptionMessage), 
                    new SqlParameter("@ControllerName",exceptionLoggers.ControllerName),
                    new SqlParameter("@ActionName",exceptionLoggers.ActionName),
                    new SqlParameter("@ExceptionStackTrace",exceptionLoggers.ExceptionStackTrace),     
                    new SqlParameter("@LogTime",exceptionLoggers.LogTime)                    
                    //new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    //new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
            //return objSqlHelper.ExecuteCommand(spQuery, parameters, 6, 7);
            return objSqlHelper.ExecuteCommand(spQuery, parameters);
        }

        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
