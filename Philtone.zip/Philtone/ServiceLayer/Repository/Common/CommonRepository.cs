﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ServiceLayer.Entity.Common;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Repository.Common
{
    public class CommonRepository
    {
        public SqlHelper objSqlHelper = null;

        public CommonRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        /// <summary>
        /// It gets unique identifier from database 
        /// </summary>
        /// <param name="exceptionLoggers"></param>
        /// <returns></returns>
        public string GetUniqueIdentifier()
        {
            string outPut = string.Empty;
            string spQuery = "[Common].[usp_GetUniqueIdentifier]";                   
            DataTable dt = new DataTable();
            dt = objSqlHelper.ExecuteQuery(spQuery);
            if (dt.Rows.Count > 0)
            {
                outPut = dt.Rows[0][0].ToString().Trim();
            }
            return outPut;
        }

        /// <summary>
        /// It keeps the user login details in the application
        /// </summary>
        /// <param name="SessionID"></param>
        /// <param name="UserID">Logged in User ID </param>
        /// <param name="Type">Insert or Update </param>
        /// <returns></returns>
        public int InsertUpdateSessiongLog(string SessionID, int UserID, int Type)
        {
            try
            {
                string spQuery = "[Common].[usp_InsertUpdateSessiongLog]";
                object[] parameters = 
                {
                    new SqlParameter("@SessionID",SessionID),  
                    new SqlParameter("@UserID",UserID), 
                    new SqlParameter("@Type",Type)
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
