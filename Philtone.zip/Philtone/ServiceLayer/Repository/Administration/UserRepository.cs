﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;
using ServiceLayer.Entity.Master;
using ServiceLayer.Entity.Common;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Administration;

namespace ServiceLayer.Repository.Administration
{
    public class UserRepository
    {
        public SqlHelper objSqlHelper = null;

        public UserRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        
        /// <summary>
        /// Checks if user with given password exists in the database
        /// </summary>
        /// <param name="_username">User name</param>
        /// <param name="_password">User password</param>
        /// <returns>True if user exist and password is correct</returns>
        /// Previously method used to pass activity permission but that is not required as activity permission is now only limited to view permission
        /// if menu don't have view permission then it will not show, add/edit/delete activity permission depricated from october 1 2017
        ///  public bool IsValid(string username, string password, out User oUser,out List<MapMenuUser> oMapMenuUsers)
        public bool IsValid(string username, string password, out User oUser)
        {
            // string aaa = CommonHelper.Decode("ZGViYW1pdGE=");
            try
            {
                oUser = new User();
                // oMapMenuUsers = new List<MapMenuUser>();
                DataSet ds = new DataSet();
                object[] parameters = 
                {
                    new SqlParameter("@LoginName",username),
                    new SqlParameter("@LoginPassowrd", CommonHelper.Encode(password))
                 
                };
                ds = objSqlHelper.ExecuteQueryList("[Administration].[usp_IsValidUser]", parameters);

                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            oUser.UserID = Convert.ToInt32(dr["UserID"].ToString().Trim());
                            oUser.LoginName = dr["LoginName"].ToString().Trim();
                            oUser.CompanyID = Convert.ToInt32(dr["CompanyId"].ToString());
                            oUser.IsCompanyAdmin = Convert.ToBoolean(dr["IsAdmin"].ToString());
                            oUser.ProfileImage = dr["ProfileImage"].ToString().Trim();
                            oUser.Firstname = dr["FirstName"].ToString().Trim();
                            oUser.Lastname = dr["LastName"].ToString().Trim();
                            oUser.EmailAddress = dr["EmailAddress"].ToString().Trim();
                            oUser.RoleID = Convert.ToInt32(dr["RoleId"]);
                        }
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
                else
                {
                    return false;
                }
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// Get User Paging
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public dynamic ResetUserPassword(string EmailAddress)
        {
            try
            {
                
                dynamic objResetUserPassword = new System.Dynamic.ExpandoObject();
                objResetUserPassword.Status = 0;
                objResetUserPassword.Subject = "";
                objResetUserPassword.MailBody = "";
                string newPassword = CommonHelper.GenerateRandomPassword(6).ToString().Trim();
                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@EmailAddress",EmailAddress),
                    new SqlParameter("@EncodedPassword",CommonHelper.Encode(newPassword)),
                    new SqlParameter("@NewPassword",newPassword),
                };
                dt = objSqlHelper.ExecuteQuery("[Administration].[usp_ResetUserPassword]", parameters);
               
                if (dt.Rows.Count > 0)
                {
                    objResetUserPassword.Status = 1;
                    objResetUserPassword.Subject = dt.Rows[0]["Subject"].ToString().Trim();
                    objResetUserPassword.MailBody = dt.Rows[0]["MailBody"].ToString().Trim();
                }
                return objResetUserPassword;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }


        /// <summary>
        /// Get User Paging
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public UserViewModel GetUserList(int? page, int? pagesize, string sortBy, bool ascending, string SearchUserName, string DepartmentID, string RoleID, string DesignationID)
        {
            try
            {
                int totalRecords = 0;
                page = page == null ? 1 : page;
                pagesize = pagesize == null ? 10 : pagesize;
                Role oRole = new Role();
                oRole.startRowIndex = Convert.ToInt32(page);
                oRole.maximumRows = Convert.ToInt32(pagesize);
                oRole.SortBy = sortBy == null ? "UserID" : sortBy;
                oRole.SortAscending = ascending;

                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SearchUsername",SearchUserName),
                    new SqlParameter("@DepartmentID",DepartmentID),
                    new SqlParameter("@RoleID",RoleID=="0"?"":RoleID),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

                UserViewModel oUserViewModel = new UserViewModel();
                dt = objSqlHelper.ExecuteQuery("[Administration].[usp_GetUserList]", parameters);
                List<User> oUserList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oUserList = (from DataRow row in dt.Rows

                                 select new User
                                 {
                                     UserID = Convert.ToInt32(row["UserID"].ToString()),
                                     FullName = row["FullName"].ToString(),
                                     LoginName = row["LoginName"].ToString(),
                                     DepartmentName = row["DepartmentName"].ToString(),
                                     RoleName = row["RoleName"].ToString(),
                                     EmailAddress = row["EmailAddress"].ToString(),
                                     Phonenumber = row["PhoneNumber"].ToString(),
                                     UserStatus = row["UserStatus"].ToString(),
                                     Skype = row["Skype"].ToString(),
                                     Status = Convert.ToBoolean(row["Status"]),
                                     RowNumber = Convert.ToInt32(row["RowNumber"])
                                 }).ToList();
                    if (oUserList.Count() > 0)
                    {
                        totalRecords = oUserList[(oUserList.Count - 1)].RowNumber;
                        oUserList.RemoveAt((oUserList.Count - 1));
                    }

                    var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "User", oRole.SortBy, oRole.SortAscending, "", "form-user-listing", "User");
                    oUserViewModel.UserList = oUserList;
                    oUserViewModel.pagerAndSort = pager;
                    oUserViewModel.DepartmentList = GetDepartmentList();                   
                    oUserViewModel.RoleList = GetRoleListByDepartmentId(Convert.ToInt32(DepartmentID == "" ? "0" : DepartmentID));

                }
                return oUserViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }



        /// <summary>
        /// Get All the User Information Based on UserID
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public UserViewModel GetUserById(Int64 UserID)
        {
            string spQuery = "[Administration].[usp_GetUserbyId]";
            object[] parameters = { new SqlParameter("@UserID", UserID) };

            UserViewModel oUserViewModel = new UserViewModel();
            DataTable dt = new DataTable();
            dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
            if (dt.Rows.Count > 0)
            {
                User Userdetail = new User();
                Userdetail.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                Userdetail.Firstname = dt.Rows[0]["FirstName"].ToString();
                Userdetail.Lastname = dt.Rows[0]["LastName"].ToString();
                Userdetail.LoginName = dt.Rows[0]["LoginName"].ToString();
                Userdetail.LoginPassword = CommonHelper.Decode(dt.Rows[0]["LoginPassword"].ToString());
                Userdetail.EmailAddress = dt.Rows[0]["EmailAddress"].ToString();
                Userdetail.Address = dt.Rows[0]["Address"].ToString();
                Userdetail.Gender = dt.Rows[0]["Gender"].ToString();
                Userdetail.CityID = Convert.ToInt32(dt.Rows[0]["CityId"]);
                Userdetail.CountryID = Convert.ToInt32(dt.Rows[0]["CountryId"]);
                Userdetail.CountryName = dt.Rows[0]["CountryName"].ToString();
                Userdetail.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"]);
                Userdetail.DepartmentName = dt.Rows[0]["DepartmentName"].ToString();
                Userdetail.RoleID = Convert.ToInt32(dt.Rows[0]["RoleID"]);
                Userdetail.RoleName = dt.Rows[0]["RoleName"].ToString();
                Userdetail.IsProjectManager = Convert.ToBoolean(dt.Rows[0]["IsProjectManager"]);
                Userdetail.Phonenumber = dt.Rows[0]["PhoneNumber"].ToString();
                Userdetail.Remark = dt.Rows[0]["Remark"].ToString();
                Userdetail.DOB = dt.Rows[0]["DOB"].ToString();
                Userdetail.GuardianName = dt.Rows[0]["GuardianName"].ToString();
                Userdetail.GuardianContact = dt.Rows[0]["GuardianContact"].ToString();
                Userdetail.EmergencyContact = dt.Rows[0]["EmergencyContact"].ToString();
                Userdetail.Notes = dt.Rows[0]["Notes"].ToString();
                Userdetail.PersonalEmail = dt.Rows[0]["PersonalEmail"].ToString();
                Userdetail.PersonalContactNumber = dt.Rows[0]["PersonalContactNumber"].ToString();
                Userdetail.Skype = dt.Rows[0]["Skype"].ToString();
                Userdetail.CityName = dt.Rows[0]["CityName"].ToString();
                Userdetail.SkypePassword = dt.Rows[0]["SkypePassword"].ToString();
                Userdetail.StateID = Convert.ToInt32(dt.Rows[0]["StateId"]);
                Userdetail.StateName = dt.Rows[0]["StateName"].ToString();
                Userdetail.PostcodeId = Convert.ToInt32(dt.Rows[0]["PostCodeId"]);
                Userdetail.Postcode = dt.Rows[0]["PostCodeNumber"].ToString();
                Userdetail.ProfileImage = dt.Rows[0]["ProfileImage"].ToString() == "" ? oUserViewModel.NoImagePath : dt.Rows[0]["ProfileImage"].ToString();
                Userdetail.Status = Convert.ToBoolean(dt.Rows[0]["Status"]);
                Userdetail.IsActive = Convert.ToBoolean(dt.Rows[0]["IsActive"]);
                Userdetail.DOJ = dt.Rows[0]["DOJ"].ToString();
                oUserViewModel.user = Userdetail;
                oUserViewModel.CountryList = GetCountryList();
                oUserViewModel.DepartmentList = GetDepartmentList();                
                oUserViewModel.RoleList = GetRoleListByDepartmentId(Userdetail.DepartmentID);
                
            }
            return oUserViewModel;
        }

        /// <summary>
        /// Get Deapartment listing
        /// </summary>
        /// <returns></returns>
        public List<Department> GetDepartmentList()
        {
            try
            {
                DataTable dt = new DataTable();

                dt = objSqlHelper.ExecuteQuery("[Master].[usp_GetDepartmentList]");
                List<Department> oDepartmentList = new List<Department>();

                if (dt.Rows.Count > 0)
                {
                    oDepartmentList = (from DataRow row in dt.Rows
                                       select new Department
                                       {
                                           DepartmentID = Convert.ToInt32(row["DepartmentID"].ToString()),
                                           DepartmentName = row["DepartmentName"].ToString(),
                                           DepartmentStatus = row["DepartmentStatus"].ToString()
                                       }).ToList();

                    oDepartmentList = oDepartmentList.FindAll(i => i.DepartmentStatus == "Active").ToList();
                }
                return oDepartmentList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// Get Role based on DepartmentID
        /// </summary>
        /// <param name="DepartmentID"></param>
        /// <returns></returns>
        public List<Role> GetRoleListByDepartmentId(int? DepartmentID = 0)
        {
            try
            {
                DataTable dt = new DataTable();
                string sQuery = "[Administration].[usp_GetRoleListByDepartmentId]";
                object[] parameters = 
                {
                    new SqlParameter("@DepartmentID",DepartmentID),                   
                };
                dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
                List<Role> oRoleList = new List<Role>();

                if (dt.Rows.Count > 0)
                {
                    oRoleList = (from DataRow row in dt.Rows
                                 select new Role
                                 {
                                     RoleID = Convert.ToInt32(row["RoleID"].ToString()),
                                     RoleName = row["RoleName"].ToString(),
                                 }).ToList();

                }
                return oRoleList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

      
        /// Get Country listing for DropDown
        /// </summary>
        /// <returns></returns>
        public List<User> GetCountryList()
        {
            try
            {
                DataTable dt = new DataTable();

                dt = objSqlHelper.ExecuteQuery("[Administration].[usp_GetCountry]");
                List<User> oCountryList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oCountryList = (from DataRow row in dt.Rows
                                    select new User
                                    {
                                        CountryID = Convert.ToInt32(row["CountryID"].ToString()),
                                        CountryName = row["CountryName"].ToString()
                                    }).ToList();
                }
                return oCountryList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// It is return all city list against the country Id, and then filteration for autocomplete search is done using the CityName paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <returns></returns>
        public List<User> GetCityListByCountryID(int? CountryID, string CityName)
        {
            try
            {
                DataTable dt = new DataTable();
                string sQuery = "[Administration].[usp_GetCityList]";
                object[] parameters = 
                {
                    new SqlParameter("@CountryId",CountryID),                   
                };
                dt = objSqlHelper.ExecuteQuery(sQuery, parameters);

                List<User> oCityList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oCityList = (from DataRow row in dt.Rows
                                 select new User
                                 {
                                     CityID = Convert.ToInt32(row["CityID"].ToString()),
                                     CityName = row["CityName"].ToString()
                                 }).ToList();
                    ///Filteration of city list done based on the CityName provided
                    oCityList = oCityList.Where(i => i.CityName.ToLower().Contains(CityName)).OrderBy(i => i.CityName).ToList();
                }
                return oCityList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// It is return all state list against the country Id, and then filteration for autocomplete search is done using the StateName paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <param name="StateName"></param>
        /// <returns></returns>
        public List<User> GetStateListByCountryID(int? CountryID, string StateName)
        {
            try
            {
                DataTable dt = new DataTable();
                string sQuery = "[Administration].[usp_GetStateList]";
                object[] parameters = 
                {
                    new SqlParameter("@CountryId",CountryID),                   
                };
                dt = objSqlHelper.ExecuteQuery(sQuery, parameters);

                List<User> oStateList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oStateList = (from DataRow row in dt.Rows
                                  select new User
                                  {
                                      StateID = Convert.ToInt32(row["StateId"].ToString()),
                                      StateName = row["StateName"].ToString()
                                  }).ToList();
                    ///Filteration of state list done based on the StateName provided
                    oStateList = oStateList.Where(i => i.StateName.ToLower().Contains(StateName)).OrderBy(i => i.StateName).ToList();
                }
                return oStateList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// It is return all PostCode list against the country Id, and then filteration for autocomplete search is done using the PostCode paramerter
        /// </summary>
        /// <param name="CountryID"></param>
        /// <param name="PostCode"></param>
        /// <returns></returns>
        public List<User> GetPostCodeListByCountryID(int? CountryID, string PostCode)
        {
            try
            {
                DataTable dt = new DataTable();
                string sQuery = "[Administration].[usp_GetPostcodeList]";
                object[] parameters = 
                {
                    new SqlParameter("@CountryId",CountryID),                   
                };
                dt = objSqlHelper.ExecuteQuery(sQuery, parameters);

                List<User> oPostcodeList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oPostcodeList = (from DataRow row in dt.Rows
                                     select new User
                                     {
                                         PostcodeId = Convert.ToInt32(row["PostCodeId"].ToString()),
                                         Postcode = row["PostCodeNumber"].ToString()
                                     }).ToList();
                    ///Filteration of postcode list done based on the postcode number provided
                    oPostcodeList = oPostcodeList.Where(i => i.Postcode.ToLower().Contains(PostCode)).OrderBy(i => i.Postcode).ToList();
                }
                return oPostcodeList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        

        /// <summary>
        /// <Inserting user information with all the details of user; also no return paramter is needed; because dmlreturn contains 2 parameters>
        /// </summary>
        /// <param name="userdetail"></param>
        /// <returns></returns>
        public DMLReturn InsertUser(UserViewModel userdetail, int CreatedBy)
        {
            DMLReturn oDML = new DMLReturn();
            try
            {
                string spQuery = "[Administration].[usp_InsertUser]";
                object[] parameters = 
                {
                    new SqlParameter("@FirstName",userdetail.user.Firstname),  
                    new SqlParameter("@LastName",userdetail.user.Lastname), 
                    new SqlParameter("@LoginName",userdetail.user.LoginName),
                    new SqlParameter("@LoginPassword",CommonHelper.Encode(userdetail.user.LoginPassword)),
                    new SqlParameter("@DepartmentID",userdetail.user.DepartmentID),     
                    new SqlParameter("@RoleID",userdetail.user.RoleID),  
                    new SqlParameter("@DesignationID",0),
                    new SqlParameter("@PhoneNumber",userdetail.user.Phonenumber),
                    new SqlParameter("@EmailAddress",userdetail.user.EmailAddress),                      
                    new SqlParameter("@Address",userdetail.user.Address), 
                    new SqlParameter("@Gender",userdetail.user.Gender), 
                    new SqlParameter("@CityName",userdetail.user.CityName), 
                    new SqlParameter("@CountryID",userdetail.user.CountryID),
                    new SqlParameter("@ProfileImage",userdetail.user.ProfileImage),
                    new SqlParameter("@DOB",userdetail.user.DOB),
                    new SqlParameter("@GuardianName",userdetail.user.GuardianName),
                    new SqlParameter("@GuardianContact",userdetail.user.GuardianContact),
                    new SqlParameter("@EmergencyContact",userdetail.user.EmergencyContact),
                    new SqlParameter("@Notes",userdetail.user.Notes),
                    new SqlParameter("@PersonalEmail",userdetail.user.PersonalEmail),
                    new SqlParameter("@Skype",userdetail.user.Skype),
                    new SqlParameter("@PersonalContactNumber",userdetail.user.PersonalContactNumber),     
                    new SqlParameter("@StateName",userdetail.user.StateName), 
                    new SqlParameter("@PostCode",userdetail.user.Postcode),
                    new SqlParameter("@SkypePassword",userdetail.user.SkypePassword),
                    new SqlParameter("@DOJ",userdetail.user.DOJ),
                    new SqlParameter("@CreatedBy",CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                oDML = objSqlHelper.ExecuteCommand(spQuery, parameters, 27, 28);
               // ReturnOutput = oDML.ReturnMessage;
               
            }
            catch (Exception exc)
            {
                throw exc;
            }
            return oDML;
        }



        /// <summary>
        /// Update User based on UserID
        /// </summary>
        /// <param name="users"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public DMLReturn UpdateUser(UserViewModel users, int ModifiedBy)
        {
            DMLReturn oDML = new DMLReturn();
            try
            {
                string spQuery = "[Administration].[usp_UpdateUser]";
                object[] parameters = 
                {
                    new SqlParameter("@PType",users.user.PType),
                    new SqlParameter("@UserID",users.user.UserID),
                    new SqlParameter("@FirstName",users.user.Firstname),  
                    new SqlParameter("@LastName",users.user.Lastname),                    
                    new SqlParameter("@LoginPassword",users.user.LoginPassword==null?"":CommonHelper.Encode(users.user.LoginPassword)),
                    new SqlParameter("@DepartmentID",users.user.DepartmentID),     
                    new SqlParameter("@RoleID",users.user.RoleID),  
                    new SqlParameter("@IsProjectManager",users.user.IsProjectManager==false?false:true),      
                    new SqlParameter("@DesignationID",0),
                    new SqlParameter("@PersonalEmail",users.user.PersonalEmail),
                    new SqlParameter("@PhoneNumber",users.user.Phonenumber),
                    new SqlParameter("@PersonalContactNumber",users.user.PersonalContactNumber),
                    new SqlParameter("@GuardianName",users.user.GuardianName),
                    new SqlParameter("@GuardianContact",users.user.GuardianContact),
                    new SqlParameter("@EmergencyContact",users.user.EmergencyContact),
                    new SqlParameter("@DOB",users.user.DOB),
                    new SqlParameter("@EmailAddress",users.user.EmailAddress),                      
                    new SqlParameter("@Address",users.user.Address), 
                    new SqlParameter("@Gender",users.user.Gender), 
                    new SqlParameter("@CityID",users.user.CityID), 
                    new SqlParameter("@CityName",users.user.CityName),
                    new SqlParameter("@StateId",users.user.StateID), 
                    new SqlParameter("@StateName",users.user.StateName),
                    new SqlParameter("@CountryID",users.user.CountryID),
                    new SqlParameter("@PostCodeId",users.user.PostcodeId),
                    new SqlParameter("@PostCodeNumber",users.user.Postcode),
                    new SqlParameter("@SkypeId",users.user.Skype),
                    new SqlParameter("@SkypePassword",users.user.SkypePassword),
                    new SqlParameter("@ProfileImage",users.user.ProfileImage),
                    new SqlParameter("@Notes",users.user.Notes),                   
                    new SqlParameter("@ModifiedBy",ModifiedBy),
                    new SqlParameter("@DOJ",users.user.DOJ),
                    new SqlParameter("@IsActive",users.user.IsActive),
                    new SqlParameter("@Status",users.user.Status),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                oDML = objSqlHelper.ExecuteCommand(spQuery, parameters, 34, 35);
            }
            catch (Exception exc)
            {
                throw exc;
            }

            return oDML;
        }
        
        /// <summary>
        /// <update user password information>
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="LoginPassword"></param>
        /// <returns></returns>
        public DMLReturn UpdateUserPassword(int UserID, string LoginPassword)
        {
          DMLReturn oDML = new DMLReturn();
          try
          {
            string spQuery = "[Administration].[usp_UpdateUserPassword]";
            object[] parameters = 
                {
                    new SqlParameter("@UserID",UserID),
                    new SqlParameter("@LoginPassword",CommonHelper.Encode(LoginPassword)),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
            oDML = objSqlHelper.ExecuteCommand(spQuery, parameters, 2, 3);
          }
          catch (Exception exc)
          {
            throw exc;
          }

          return oDML;
        }



        /// <summary>
        /// Update User based on UserID
        /// </summary>
        /// <param name="users"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public DMLReturn UpdateProfile(UserViewModel users, int ModifiedBy)
        {
            DMLReturn oDML = new DMLReturn();
            try
            {
                string spQuery = "[Administration].[usp_UpdateProfile]";
                object[] parameters = 
                {
                    new SqlParameter("@PType",users.user.PType),
                    new SqlParameter("@UserID",users.user.UserID),
                    new SqlParameter("@FirstName",users.user.Firstname),  
                    new SqlParameter("@LastName",users.user.Lastname),                    
                    new SqlParameter("@LoginPassword",users.user.LoginPassword==null?"":CommonHelper.Encode(users.user.LoginPassword)),
                    new SqlParameter("@DepartmentID",users.user.DepartmentID),     
                    new SqlParameter("@RoleID",users.user.RoleID),  
                    new SqlParameter("@IsProjectManager",users.user.IsProjectManager==false?false:true),      
                    new SqlParameter("@DesignationID",0),
                    new SqlParameter("@PersonalEmail",users.user.PersonalEmail),
                    new SqlParameter("@PhoneNumber",users.user.Phonenumber),
                    new SqlParameter("@PersonalContactNumber",users.user.PersonalContactNumber),
                    new SqlParameter("@GuardianName",users.user.GuardianName),
                    new SqlParameter("@GuardianContact",users.user.GuardianContact),
                    new SqlParameter("@EmergencyContact",users.user.EmergencyContact),
                    new SqlParameter("@DOB",users.user.DOB),
                    new SqlParameter("@EmailAddress",users.user.EmailAddress),                      
                    new SqlParameter("@Address",users.user.Address), 
                    new SqlParameter("@Gender",users.user.Gender), 
                    new SqlParameter("@CityID",users.user.CityID), 
                    new SqlParameter("@CityName",users.user.CityName),
                    new SqlParameter("@StateId",users.user.StateID), 
                    new SqlParameter("@StateName",users.user.StateName),
                    new SqlParameter("@CountryID",users.user.CountryID),
                    new SqlParameter("@PostCodeId",users.user.PostcodeId),
                    new SqlParameter("@PostCodeNumber",users.user.Postcode),
                    new SqlParameter("@SkypeId",users.user.Skype),
                    new SqlParameter("@SkypePassword",users.user.SkypePassword),
                    new SqlParameter("@ProfileImage",users.user.ProfileImage),
                    new SqlParameter("@Notes",users.user.Notes),                   
                    new SqlParameter("@ModifiedBy",ModifiedBy),
                    new SqlParameter("@DOJ",users.user.DOJ),
                    new SqlParameter("@IsActive",users.user.IsActive),
                    new SqlParameter("@Status",users.user.Status),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                oDML = objSqlHelper.ExecuteCommand(spQuery, parameters, 34, 35);
            }
            catch (Exception exc)
            {
                throw exc;
            }

            return oDML;
        }

        
        /// <summary>
        /// <Get all users who are active except the super administrator userid=1>
        /// </summary>
        /// <returns></returns>
        public List<User> GetAllUsersList()
        {
          try
          {
            DataTable dt = new DataTable();
            string sQuery = "[Administration].[usp_GetAllUsersList]";
            dt = objSqlHelper.ExecuteQuery(sQuery);
            List<User> oUsersList = new List<User>();

            if (dt.Rows.Count > 0)
            {
              oUsersList = (from DataRow row in dt.Rows
                              select new User
                              {
                                UserID = Convert.ToInt32(row["UserID"]),
                                Firstname = Convert.ToString(row["Firstname"]),
                                Lastname = Convert.ToString(row["Lastname"]),
                                FullName = Convert.ToString(row["FullName"]),
                              }).ToList();
            }
            return oUsersList;
          }
          catch (Exception Exc)
          {
            throw Exc;
          }
        }



        /// <summary>
        /// Get the list of User with paging ,sorting and Search based on 
        /// Username ,DepartmentId ,roleId, designationId
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <param name="SearchUserName"></param>
        /// <param name="DepartmentID"></param>
        /// <param name="RoleID"></param>
        /// <param name="DesignationID"></param>
        /// <returns></returns>
        public UserViewModel GetUserListing(int? page, int? pagesize, string sortBy, bool ascending, string SearchUserName, string DepartmentID, string RoleID, string DesignationID)
        {
            try
            {
                int totalRecords = 0;
                page = page == null ? 1 : page;
                pagesize = pagesize == null ? 10 : pagesize;
                Role oRole = new Role();
                oRole.startRowIndex = Convert.ToInt32(page);
                oRole.maximumRows = Convert.ToInt32(pagesize);
                oRole.SortBy = sortBy == null ? "UserID" : sortBy;
                oRole.SortAscending = ascending;

                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SearchUsername",SearchUserName),
                    new SqlParameter("@DepartmentID",DepartmentID),
                    new SqlParameter("@RoleID",RoleID=="0"?"":RoleID),
                    new SqlParameter("@DesignationID",DesignationID),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

                UserViewModel oUserViewModel = new UserViewModel();
                dt = objSqlHelper.ExecuteQuery("[Administration].[usp_GetUserList]", parameters);
                List<User> oUserList = new List<User>();

                if (dt.Rows.Count > 0)
                {
                    oUserList = (from DataRow row in dt.Rows

                                 select new User
                                 {
                                     UserID = Convert.ToInt32(row["UserID"].ToString()),
                                     FullName = row["FullName"].ToString(),
                                     LoginName = row["LoginName"].ToString(),
                                     DepartmentName = row["DepartmentName"].ToString(),
                                     RoleName = row["RoleName"].ToString(),
                                     DesignationName = row["DesignationName"].ToString(),
                                     EmailAddress = row["EmailAddress"].ToString(),
                                     Phonenumber = row["PhoneNumber"].ToString(),
                                     UserStatus = row["UserStatus"].ToString(),
                                     Skype = row["Skype"].ToString(),
                                     Status = Convert.ToBoolean(row["Status"]),
                                     RowNumber = Convert.ToInt32(row["RowNumber"].ToString())
                                 }).ToList();
                    if (oUserList.Count() > 0)
                    {
                        totalRecords = oUserList[(oUserList.Count - 1)].RowNumber;
                        oUserList.RemoveAt((oUserList.Count - 1));
                    }

                    var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "UserListing", oRole.SortBy, oRole.SortAscending, "tblUserListing", "FormUserListing", "UserListing");
                    oUserViewModel.UserList = oUserList;
                    oUserViewModel.pagerAndSort = pager;
                    oUserViewModel.DepartmentList = GetDepartmentList();                   
                    oUserViewModel.RoleList = GetRoleListByDepartmentId(Convert.ToInt32(DepartmentID == "" ? "0" : DepartmentID));

                }
                return oUserViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
