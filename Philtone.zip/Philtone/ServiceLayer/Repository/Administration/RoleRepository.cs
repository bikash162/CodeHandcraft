﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Master;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Administration;
using ServiceLayer.Entity.Administration;

namespace ServiceLayer.Repository.Administration
{
    public class RoleRepository
    {
        public SqlHelper objSqlHelper = null;

        public RoleRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        /// <summary>
        /// <Get Role list with Paging and search>
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="sortBy"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        public RoleViewModel GetRoleList(int? page, int? pagesize, string sortBy, bool ascending, string SearchRoleName)
        {
            try
            {
                int totalRecords = 0;
                page = page == null ? 1 : page;
                pagesize = pagesize == null ? 10 : pagesize;
                Role oRole = new Role();
                oRole.startRowIndex = Convert.ToInt32(page);
                oRole.maximumRows = Convert.ToInt32(pagesize);
                oRole.SortBy = sortBy == null ? "Id" : sortBy;
                oRole.SortAscending = ascending;

                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SearchRolename",SearchRoleName),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

                RoleViewModel oRoleViewModel = new RoleViewModel();
                dt = objSqlHelper.ExecuteQuery("[Administration].[usp_GetRoleList]", parameters);
                List<Role> oRoleList = new List<Role>();

                if (dt.Rows.Count > 0)
                {
                    oRoleList = (from DataRow row in dt.Rows

                                 select new Role
                                 {
                                     DepartmentID = Convert.ToInt32(row["DepartmentId"]),
                                     DepartmentName = Convert.ToString(row["DepartmentName"]),
                                     RoleID = Convert.ToInt32((row["RoleID"])),
                                     RoleName = Convert.ToString(row["RoleName"]),
                                     RoleDescription = Convert.ToString(row["RoleDescription"]),
                                     RoleStatus = Convert.ToString(row["RoleStatus"]),
                                     RowNumber = Convert.ToInt32((row["RowNumber"]))
                                 }).ToList();
                    if (oRoleList.Count() > 0)
                    {
                        totalRecords = oRoleList[(oRoleList.Count - 1)].RowNumber;
                        oRoleList.RemoveAt((oRoleList.Count - 1));
                    }

                    var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "Role", oRole.SortBy, oRole.SortAscending, "tblRole", "FormRole", "Role");
                    oRoleViewModel.roleList = oRoleList;
                    oRoleViewModel.pagerAndSort = pager;
                }
                return oRoleViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// <Get Deapartment listing>
        /// </summary>
        /// <returns></returns>
        public List<Department> GetDepartmentLists()
        {
            try
            {
                DataTable dt = new DataTable();

                dt = objSqlHelper.ExecuteQuery("[Master].[usp_GetDepartmentLists]");
                List<Department> oDepartmentList = new List<Department>();

                if (dt.Rows.Count > 0)
                {
                    oDepartmentList = (from DataRow row in dt.Rows
                                       select new Department
                                       {
                                           DepartmentID = Convert.ToInt32(row["DepartmentID"].ToString()),
                                           DepartmentName = Convert.ToString(row["DepartmentName"].ToString()),
                                       }).ToList();
                }
                return oDepartmentList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// <Get Role information by RoleID>
        /// </summary>
        /// <param name="RoleId"></param>
        /// <returns></returns>
        public Role GetRoleById(int RoleId)
        {
            try
            {
                string spQuery = "[Administration].[usp_GetRoleById]";
                object[] parameters = 
                {
                    new SqlParameter("@RoleId",RoleId),
                };
                DataTable dt = new DataTable();
                Role oRole = new Role();
                dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
                if (dt.Rows.Count > 0)
                {
                    oRole.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"]);
                    oRole.RoleID = Convert.ToInt32(dt.Rows[0]["RoleID"]);
                    oRole.RoleName = Convert.ToString(dt.Rows[0]["RoleName"]);
                    oRole.RoleDescription = Convert.ToString(dt.Rows[0]["RoleDescription"]);
                }
                return oRole;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }


        /// <summary>
        /// <Get only Role information by RoleID>
        /// </summary>
        /// <param name="RoleID"></param>
        /// <returns></returns>
        public RoleViewModel GetRoleDetailByID(int RoleID)
        {
            try
            {
                string spQuery = "[Administration].[usp_GetRoleDetailByID]";
                object[] parameters = 
                {
                    new SqlParameter("@RoleID",RoleID),
                };
                DataTable dt = new DataTable();
                RoleViewModel roleViewModel = new RoleViewModel();
                dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
                if (dt.Rows.Count > 0)
                {
                    Role oRole = new Role();
                    oRole.DepartmentID = Convert.ToInt32(dt.Rows[0]["DepartmentID"]);
                    oRole.RoleID = Convert.ToInt32(dt.Rows[0]["RoleID"]);
                    oRole.RoleName = Convert.ToString(dt.Rows[0]["RoleName"]);
                    oRole.RoleDescription = Convert.ToString(dt.Rows[0]["RoleDescription"]);
                    roleViewModel.role = oRole;
                    roleViewModel.DepartmentList = GetDepartmentLists();
                }
                return roleViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }



        /// <summary>
        /// <Insert New Role>
        /// </summary>
        /// <param name="roles"></param>
        /// <returns></returns>
        public DMLReturn InsertRole(RoleViewModel roleViewModel)
        {
            try
            {
                string spQuery = "[Administration].[usp_InsertRole]";
                object[] parameters = 
                {
                    new SqlParameter("@DepartmentID",roleViewModel.role.DepartmentID),
                    new SqlParameter("@RoleName",roleViewModel.role.RoleName),
                    new SqlParameter("@RoleDescription",roleViewModel.role.RoleDescription),  
                    new SqlParameter("@CreatedBy",roleViewModel.role.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 4, 5);
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// <Update Role based on RoleId>
        /// </summary>
        /// <param name="roleViewModel"></param>
        /// <returns></returns>

        public DMLReturn UpdateRole(RoleViewModel roleViewModel)
        {
            try
            {
                string spQuery = "[Administration].[usp_UpdateRole]";
                object[] parameters = 
                {
                    new SqlParameter("@RoleID",roleViewModel.role.RoleID),
                    new SqlParameter("@DepartmentID",roleViewModel.role.DepartmentID),                  
                    new SqlParameter("@RoleName",roleViewModel.role.RoleName),
                    new SqlParameter("@RoleDescription",roleViewModel.role.RoleDescription),
                    new SqlParameter("@ModifiedBy",roleViewModel.role.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters,5, 6);
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        /// <summary>
        /// Dispose all Sql object
        /// </summary>
        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
