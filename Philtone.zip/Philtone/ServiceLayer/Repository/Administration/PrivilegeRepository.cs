﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;
using ServiceLayer.ViewModel.Administration;
using ServiceLayer.Utitlity;
using System.Xml.Linq;
using System.Xml.Serialization;



namespace ServiceLayer.Repository.Administration
{
    public class PrivilegeRepository
    {
        public SqlHelper objSqlHelper = null;

        public PrivilegeRepository()
        {
            this.objSqlHelper = new SqlHelper();
        }

        #region Role Section

        /// <summary>
        /// Populate Role for dropdown list
        /// </summary>
        /// <returns></returns>
        public List<MapMenuRole> GetMenuRoleList(int? RoleId)
        {
            try
            {
                DataTable dt = new DataTable();
                object[] parameters = 
                {
                    new SqlParameter("@RoleId",0)
                };
                string spQuery = "[Administration].[usp_GetRoleById]";
                dt = objSqlHelper.ExecuteQuery(spQuery, parameters);
                List<MapMenuRole> oMapMenuRoleList = new List<MapMenuRole>();

                if (dt.Rows.Count > 0)
                {
                    oMapMenuRoleList = (from DataRow row in dt.Rows
                                        select new MapMenuRole
                                        {
                                            RoleID = Convert.ToInt32(row["RoleID"].ToString()),
                                            RoleName = row["RoleName"].ToString(),
                                            DepartmentID = Convert.ToInt32(row["DepartmentID"].ToString())
                                        }).ToList();
                }
                return oMapMenuRoleList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }

        /// <summary>
        /// Populate the List of menu based on RoleID=0 or search based RoleID greater than 0
        /// </summary>
        /// <param name="SearchRoleID"></param>
        /// <returns></returns>
        public MapMenuRoleViewModel GetRoleMenuList(int? SearchRoleID)
        {
            MapMenuRoleViewModel oMapMenuRoleViewModel = new MapMenuRoleViewModel();

            DataSet ds = new DataSet();
            object[] parameters = 
            {
                    new SqlParameter("@RoleID",SearchRoleID)
             };

            ds = objSqlHelper.ExecuteQueryList("[Administration].[usp_GetRoleMenuList]", parameters);
            if (ds.Tables.Count > 0)
            {
                List<MapMenuRole> oModules = new List<MapMenuRole>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        MapMenuRole oModule = new MapMenuRole();
                        oModule.MenuID = Convert.ToInt32(dr["MenuID"].ToString().Trim());
                        oModule.MenuName = dr["MenuName"].ToString().Trim();
                        oModule.CanView = Convert.ToBoolean(dr["CanView"].ToString().Trim() == "False" ? false : true);
                        oModule.CanAdd = Convert.ToBoolean(dr["CanAdd"].ToString().Trim() == "False" ? false : true);
                        oModule.CanEdit = Convert.ToBoolean(dr["CanEdit"].ToString().Trim() == "False" ? false : true);
                        oModule.CanDelete = Convert.ToBoolean(dr["CanDelete"].ToString().Trim() == "False" ? false : true);
                        oModules.Add(oModule);
                    }
                }
                oMapMenuRoleViewModel.ModuleMenus = oModules;

                List<MapMenuRole> oParentMenus = new List<MapMenuRole>();
                if (ds.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        MapMenuRole oMenu = new MapMenuRole();
                        oMenu.MenuID = Convert.ToInt32(dr["MenuID"].ToString().Trim());
                        oMenu.MenuName = dr["MenuName"].ToString().Trim();
                        oMenu.ParentMenuID = Convert.ToInt32(dr["ParentMenuID"].ToString().Trim());
                        oMenu.ParentMenuName = dr["ParentMenu"].ToString().Trim();
                        oMenu.Module = dr["Module"].ToString().Trim();
                        oMenu.CanView = Convert.ToBoolean(dr["CanView"].ToString().Trim() == "False" ? false : true);
                        oMenu.CanAdd = Convert.ToBoolean(dr["CanAdd"].ToString().Trim() == "False" ? false : true);
                        oMenu.CanEdit = Convert.ToBoolean(dr["CanEdit"].ToString().Trim() == "False" ? false : true);
                        oMenu.CanDelete = Convert.ToBoolean(dr["CanDelete"].ToString().Trim() == "False" ? false : true);
                        oParentMenus.Add(oMenu);
                    }
                }
                oMapMenuRoleViewModel.ParentMenus = oParentMenus;
            }
            oMapMenuRoleViewModel.SelectListRole = GetMenuRoleList(SearchRoleID);
            oMapMenuRoleViewModel.SelectListRoleGroup = GetRoleLabelList();
            return oMapMenuRoleViewModel;
        }

        public List<RoleGroup> GetRoleLabelList()
        {
            try
            {
                DataTable dt = new DataTable();

                string spQuery = "[Administration].[usp_GetRoleGroupLabel]";
                dt = objSqlHelper.ExecuteQuery(spQuery);
                List<RoleGroup> oMapMenuRoleList = new List<RoleGroup>();

                if (dt.Rows.Count > 0)
                {
                    oMapMenuRoleList = (from DataRow row in dt.Rows
                                        select new RoleGroup
                                        {
                                            DepartmentID = Convert.ToInt32(row["DepartmentID"].ToString()),
                                            DepartmentName = row["DepartmentName"].ToString()

                                        }).ToList();
                }
                return oMapMenuRoleList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        /// <summary>
        /// This update menu privilege against the role as well as menu privilege against all the user against that role
        /// </summary>
        /// <param name="XmlViewDoc">Contains all the menuid along with its permission status</param>      
        /// <returns></returns>
        public DMLReturn InsertUpdateRoleMapMenu(Dictionary<int, bool> myDictionary, int RoleID)
        {
            try
            {
                XDocument docview = new XDocument();
                docview.Add(
                        new XElement("CanViewLists", myDictionary.Select(x => new XElement("CanViewList",
                                                                                new XElement("MenuID", x.Key),
                                                                                new XElement("CanView", x.Value)))));
                string XmlViewDoc = docview.ToString().Trim();

                string spQuery = "[Administration].[usp_InsertUpdateRoleMapMenu]";
                object[] parameters = 
                {                   
                    new SqlParameter("@RoleID",RoleID),      
                    new SqlParameter("@XmlViewDoc",XmlViewDoc==null?string.Empty:XmlViewDoc),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 2, 3);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
        #endregion Role Section

        #region User Section
        /// <summary>
        /// Get All User List
        /// </summary>
        /// <returns></returns>
        public List<MapMenuUser> MenuGetUserList()
        {
            try
            {
                DataTable dt = new DataTable();

                string spQuery = "[Administration].[usp_MenuGetUserList]";
                dt = objSqlHelper.ExecuteQuery(spQuery);
                List<MapMenuUser> oMapMenuUserList = new List<MapMenuUser>();

                if (dt.Rows.Count > 0)
                {
                    oMapMenuUserList = (from DataRow row in dt.Rows
                                        select new MapMenuUser
                                        {
                                            UserID = Convert.ToInt32(row["UserID"].ToString()),
                                            UserName = row["FullName"].ToString(),
                                            RoleID = Convert.ToInt32(row["RoleID"].ToString())

                                        }).ToList();
                }
                return oMapMenuUserList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        public List<UserGroup> GetUserLabelList()
        {
            try
            {
                DataTable dt = new DataTable();

                string spQuery = "[Administration].[usp_GetUserGroupLabel]";
                dt = objSqlHelper.ExecuteQuery(spQuery);
                List<UserGroup> oMapMenuUserList = new List<UserGroup>();

                if (dt.Rows.Count > 0)
                {
                    oMapMenuUserList = (from DataRow row in dt.Rows
                                        select new UserGroup
                                        {
                                            RoleID = Convert.ToInt32(row["RoleID"].ToString()),
                                            RoleName = row["RoleName"].ToString()

                                        }).ToList();
                }
                return oMapMenuUserList;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        /// <summary>
        /// Get all menu list based on UserID=0 or search based UserID greater than 0
        /// </summary>
        /// <param name="ParentMenuId"></param>
        /// <returns></returns>
        public MapMenuUserViewModel GetUserMenuList(int? SearchUserID)
        {
            try
            {
                MapMenuUserViewModel mapMenuUserViewModel = new MapMenuUserViewModel();
                DataSet ds = new DataSet();
                object[] parameters = 
                {
                    new SqlParameter("@UserID",SearchUserID)
                };

                ds = objSqlHelper.ExecuteQueryList("[Administration].[usp_GetUserMenuList]", parameters);
                if (ds.Tables.Count > 0)
                {
                    List<MapMenuUser> oModules = new List<MapMenuUser>();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            MapMenuUser oModule = new MapMenuUser();
                            oModule.MenuID = Convert.ToInt32(dr["MenuID"].ToString().Trim());
                            oModule.MenuName = dr["MenuName"].ToString().Trim();
                            oModule.CanView = Convert.ToBoolean(dr["CanView"].ToString().Trim() == "False" ? false : true);
                            oModule.CanAdd = Convert.ToBoolean(dr["CanAdd"].ToString().Trim() == "False" ? false : true);
                            oModule.CanEdit = Convert.ToBoolean(dr["CanEdit"].ToString().Trim() == "False" ? false : true);
                            oModule.CanDelete = Convert.ToBoolean(dr["CanDelete"].ToString().Trim() == "False" ? false : true);
                            oModules.Add(oModule);
                        }
                    }
                    mapMenuUserViewModel.ModuleMenus = oModules;

                    List<MapMenuUser> oParentMenus = new List<MapMenuUser>();
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            MapMenuUser oMenu = new MapMenuUser();
                            oMenu.MenuID = Convert.ToInt32(dr["MenuID"].ToString().Trim());
                            oMenu.MenuName = dr["MenuName"].ToString().Trim();
                            oMenu.ParentMenuID = Convert.ToInt32(dr["ParentMenuID"].ToString().Trim());
                            oMenu.ParentMenuName = dr["ParentMenu"].ToString().Trim();
                            oMenu.Module = dr["Module"].ToString().Trim();
                            oMenu.CanView = Convert.ToBoolean(dr["CanView"].ToString().Trim() == "False" ? false : true);
                            oMenu.CanAdd = Convert.ToBoolean(dr["CanAdd"].ToString().Trim() == "False" ? false : true);
                            oMenu.CanEdit = Convert.ToBoolean(dr["CanEdit"].ToString().Trim() == "False" ? false : true);
                            oMenu.CanDelete = Convert.ToBoolean(dr["CanDelete"].ToString().Trim() == "False" ? false : true);
                            oParentMenus.Add(oMenu);
                        }
                    }
                    mapMenuUserViewModel.ParentMenus = oParentMenus;
                }
                mapMenuUserViewModel.SelectListUser = MenuGetUserList();
                mapMenuUserViewModel.SelectListUserGroup = GetUserLabelList();
                return mapMenuUserViewModel;
            }
            catch (Exception Exc)
            {
                throw Exc;
            }
        }
        /// <summary>
        /// insert and update the Role Privilage
        /// </summary>
        /// <param name="XmlViewDoc"></param>
        /// <param name="XmlAddDoc"></param>
        /// <param name="XmlEditDoc"></param>
        /// <param name="XmlDeleteDoc"></param>
        /// <returns></returns>
        public DMLReturn InsertUpdateUserMapMenu(Dictionary<int, bool> myDictionary, int UserID)
        {
            try
            {
                XDocument docview = new XDocument();
                docview.Add(
                        new XElement("CanViewLists", myDictionary.Select(x => new XElement("CanViewList",
                                                                                new XElement("MenuID", x.Key),
                                                                                new XElement("CanView", x.Value)))));
                string XmlViewDoc = docview.ToString().Trim();

                string spQuery = "[Administration].[usp_InsertUpdateUserMapMenu]";
                object[] parameters = 
                {                   
                    new SqlParameter("@UserID",UserID),      
                    new SqlParameter("@XmlViewDoc",XmlViewDoc==null?string.Empty:XmlViewDoc),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
                return objSqlHelper.ExecuteCommand(spQuery, parameters, 2, 3);
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }
        #endregion User Section

        public void Dispose()
        {
            objSqlHelper.Dispose();
        }
    }
}
