﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Jobs;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Entity.Administration;
using ServiceLayer.Utitlity;
using ServiceLayer.ViewModel.Jobs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Repository.Jobs
{
  public class JobRepository
  {
    public SqlHelper objSqlHelper = null;

    public JobRepository()
    {
      this.objSqlHelper = new SqlHelper();
    }

    public JobViewModel GetJobsList(int? page, int? pagesize, string sortBy, bool ascending, string CustomerName = null, int Status = 0, string JobTitle = null, string JobCode = null)
    {
      try
      {
        int totalRecords = 0;
        page = page == null ? 1 : page;
        pagesize = pagesize == null ? 10 : pagesize;
        Job oJob = new Job();
        oJob.startRowIndex = Convert.ToInt32(page);
        oJob.maximumRows = Convert.ToInt32(pagesize);
        oJob.SortBy = sortBy == null ? "CreatedOn" : sortBy;
        oJob.SortAscending = ascending;

        DataTable dt = new DataTable();
        object[] parameters = 
                {
                    new SqlParameter("@JobCode",JobCode),
                    new SqlParameter("@JobTitle",JobTitle),
                    new SqlParameter("@CustomerName",CustomerName),
                    new SqlParameter("@Status",Status),
                    new SqlParameter("@startRowIndex",page),
                    new SqlParameter("@maximumRows",pagesize),
                    new SqlParameter("@SortBy",sortBy),
                    new SqlParameter("@IsAscending",ascending)
                };

        JobViewModel oJobViewModel = new JobViewModel();
        dt = objSqlHelper.ExecuteQuery("[Jobs].[usp_GetJobsList]", parameters);
        List<Job> oJobList = new List<Job>();

        if (dt.Rows.Count > 0)
        {
          oJobList = (from DataRow row in dt.Rows
                           select new Job
                           {
                             JobID = Convert.ToInt64(row["JobID"].ToString()),
                             JobCode = Convert.ToString(row["JobCode"]),
                             JobTitle = Convert.ToString(row["JobTitle"]),
                             JobDescription = Convert.ToString(row["JobDescription"]),
                             CustomerID = Convert.ToInt64(row["CustomerID"]),
                             CustomerName = Convert.ToString(row["CustomerName"]),
                             Status = Convert.ToInt32(row["Status"]),
                             StatusName = Convert.ToString(row["StatusName"]),
                             CreatedDateFormatted = Convert.ToString(row["CreatedDateFormatted"]),
                             FullName = Convert.ToString(row["FullName"]),
                             RowNumber = Convert.ToInt32(row["RowNumber"].ToString())
                           }).ToList();
          if (oJobList.Count() > 0)
          {
            totalRecords = oJobList[(oJobList.Count - 1)].RowNumber;
            oJobList.RemoveAt((oJobList.Count - 1));
          }

          var pager = new PagerAndSort(totalRecords, Convert.ToInt32(page), Convert.ToInt32(pagesize), "Job", oJob.SortBy, oJob.SortAscending, "", "form-job-listing", "Job");
          oJobViewModel.oJobsList = oJobList;
          oJobViewModel.pagerAndSort = pager;
        }
        return oJobViewModel;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    public Job GetJobInformationByID(long JobID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Jobs].[usp_GetJobInformationByID]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",JobID),                   
                };

        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        Job oJob = new Job();

        if (dt.Rows.Count > 0)
        {

          oJob.JobID = Convert.ToInt64(dt.Rows[0]["JobID"]);
          oJob.JobCode = Convert.ToString(dt.Rows[0]["JobCode"]);
          oJob.JobTitle = Convert.ToString(dt.Rows[0]["JobTitle"]);
          oJob.JobDescription = Convert.ToString(dt.Rows[0]["JobDescription"]);
          oJob.CustomerID = Convert.ToInt64(dt.Rows[0]["CustomerID"]);
          oJob.Status = Convert.ToInt32(dt.Rows[0]["Status"]);
        }

        return oJob;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }





    /// <summary>
    /// <Get Customer Contacts List based on CustomerID and if Contact is assigned to that job then it will be marked checked>
    /// </summary>
    /// <returns></returns>
    public List<CustomerContacts> GetJobsCustomerContactsList(long JobID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Jobs].[usp_GetJobsCustomerContactsList]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",JobID),                   
                };
        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        List<CustomerContacts> oCustomerContactsList = new List<CustomerContacts>();

        if (dt.Rows.Count > 0)
        {
          oCustomerContactsList = (from DataRow row in dt.Rows
                                   select new CustomerContacts
                                   {
                                     CustomerContactID = Convert.ToInt64(row["CustomerContactID"]),
                                     CustomerContactName = Convert.ToString(row["CustomerContactName"]),
                                     CustomerContactPhoneNumber = Convert.ToString(row["CustomerContactPhoneNumber"]),
                                     CustomerContactEmail = Convert.ToString(row["CustomerContactEmail"]),
                                     JobID = Convert.ToInt64(row["JobID"]),
                                     IsPrimary = Convert.ToBoolean(row["IsPrimary"])
                                   }).ToList();
        }
        return oCustomerContactsList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <Get userd List if user is assigned to that job then it will be marked checked>
    /// </summary>
    /// <returns></returns>
    public List<User> GetJobsUsersList(long JobID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Jobs].[usp_GetJobsUsersList]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",JobID),                   
                };
        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        List<User> oUsersList = new List<User>();

        if (dt.Rows.Count > 0)
        {
          oUsersList = (from DataRow row in dt.Rows
                                   select new User
                                   {
                                     UserID = Convert.ToInt32(row["UserID"]),
                                     FullName = Convert.ToString(row["FullName"]),
                                     EmailAddress = Convert.ToString(row["EmailAddress"]),
                                     Phonenumber = Convert.ToString(row["Phonenumber"]),
                                     JobID = Convert.ToInt64(row["JobID"])
                                   }).ToList();
        }
        return oUsersList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <Get only assigned contacts for a respective job>
    /// </summary>
    /// <param name="JobID"></param>
    /// <returns></returns>
    public List<CustomerContacts> GetJobsAssignedCustomerContactsList(long JobID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Jobs].[usp_GetJobsAssignedCustomerContactsList]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",JobID),                   
                };
        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        List<CustomerContacts> oCustomerContactsList = new List<CustomerContacts>();

        if (dt.Rows.Count > 0)
        {
          oCustomerContactsList = (from DataRow row in dt.Rows
                                   select new CustomerContacts
                                   {
                                     CustomerContactID = Convert.ToInt64(row["CustomerContactID"]),
                                     CustomerContactName = Convert.ToString(row["CustomerContactName"]),
                                     CustomerContactPhoneNumber = Convert.ToString(row["CustomerContactPhoneNumber"]),
                                     CustomerContactEmail = Convert.ToString(row["CustomerContactEmail"]),
                                     IsPrimary = Convert.ToBoolean(row["IsPrimary"])
                                   }).ToList();
        }
        return oCustomerContactsList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }

    /// <summary>
    /// <get only assigned users list based on JobID>
    /// </summary>
    /// <param name="JobID"></param>
    /// <returns></returns>
    public List<User> GetJobsAssignedUsersList(long JobID)
    {
      try
      {
        DataTable dt = new DataTable();
        string sQuery = "[Jobs].[usp_GetJobsAssignedUsersList]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",JobID),                   
                };
        dt = objSqlHelper.ExecuteQuery(sQuery, parameters);
        List<User> oUsersList = new List<User>();

        if (dt.Rows.Count > 0)
        {
          oUsersList = (from DataRow row in dt.Rows
                        select new User
                        {
                          UserID = Convert.ToInt32(row["UserID"]),
                          FullName = Convert.ToString(row["FullName"]),
                          EmailAddress = Convert.ToString(row["EmailAddress"]),
                          Phonenumber = Convert.ToString(row["Phonenumber"])
                        }).ToList();
        }
        return oUsersList;
      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    public DMLReturn InsertJob(Job ojob)
    {
      try
      {
        string spQuery = "[Jobs].[usp_InsertJob]";
        object[] parameters = 
                {
                    new SqlParameter("@JobCode",ojob.JobCode),
                    new SqlParameter("@JobTitle",ojob.JobTitle),
                    new SqlParameter("@JobDescription",ojob.JobDescription),
                    new SqlParameter("@CustomerID",ojob.CustomerID),
                    new SqlParameter("@UserIDs",ojob.UserIDs),
                    new SqlParameter("@CustomerContactIDs",ojob.CustomerContactIDs),
                    new SqlParameter("@CreatedBy",ojob.CreatedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 7, 8);

      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }
    
    /// <summary>
    /// <Updating Job details based on job id, Customer information will not be updated>
    /// </summary>
    /// <param name="ojob"></param>
    /// <returns></returns>
    public DMLReturn UpdateJob(Job ojob)
    {
      try
      {
        string spQuery = "[Jobs].[usp_UpdateJob]";
        object[] parameters = 
                {
                    new SqlParameter("@JobID",ojob.JobID),
                    new SqlParameter("@JobCode",ojob.JobCode),
                    new SqlParameter("@JobTitle",ojob.JobTitle),
                    new SqlParameter("@JobDescription",ojob.JobDescription),
                    new SqlParameter("@UserIDs",ojob.UserIDs),
                    new SqlParameter("@CustomerContactIDs",ojob.CustomerContactIDs),
                    new SqlParameter("@ModifiedBy",ojob.ModifiedBy),
                    new SqlParameter("@ReturnValue",SqlDbType.Int){Direction=ParameterDirection.Output},
                    new SqlParameter("@ReturnValueMessage",SqlDbType.VarChar,500){Direction=ParameterDirection.Output}
                };
        return objSqlHelper.ExecuteCommand(spQuery, parameters, 7, 8);

      }
      catch (Exception Exc)
      {
        throw Exc;
      }
    }


    public void Dispose()
    {
      objSqlHelper.Dispose();
    }
  }
}
