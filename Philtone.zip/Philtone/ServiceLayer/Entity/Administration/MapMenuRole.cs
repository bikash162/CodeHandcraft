﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Administration
{
    public class MapMenuRole
    {
        public int MenuUserID { get; set; }

        public int MenuID { get; set; }
        public string MenuName { get; set; }

        public int ParentMenuID { get; set; }
        public string ParentMenuName { get; set; }

        public string Module { get; set; }

        public string MenuURL { get; set; } 
    
        public int RoleID { get; set; }

        [Required(ErrorMessage = "Role name is required.")]
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        public bool CanAdd { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
        public bool CanView { get; set; }

        public int DepartmentID { get; set; }
    }
}
