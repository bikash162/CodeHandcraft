﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ServiceLayer.Entity.Administration
{
    /// <summary>
    /// class Role 
    /// use in RoleModelView,RoleControl,RoleRepository
    /// </summary>
    public class Role
    {
        public Int32 RoleID { get; set; }

        [Required(ErrorMessage = "Role name is required.")]
        [Display(Name="Role Name")]
        public string RoleName { get; set; }

        [Display(Name = "Role Description")]
        public string RoleDescription { get; set; }

        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }

        [Display(Name = "Status")]
        public string RoleStatus { get; set; }


        public int CompanyID { get; set; }

        public Int32 CreatedBy { get; set; }
        public Int32 ModifiedBy { get; set; }
        public int RowNumber { get; set; }
        //Pagination and column sorting related fields
        public int startRowIndex { get; set; }
        public int maximumRows { get; set; }
        public string SortBy { get; set; }
        public bool SortAscending { get; set; }
    }    
}
