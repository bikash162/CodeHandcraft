﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace ServiceLayer.Entity.Administration
{
    public class User
    {
        public int UserID { get; set; }
        [Display(Name = "First name")]
        public string Firstname { get; set; }
         [Display(Name = "Last name")]
        public string Lastname { get; set; }
        [Display(Name = "User name")]
        public string LoginName { get; set; }
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string LoginPassword { get; set; }
        /// <summary>
        /// Not in used
        /// </summary>
        public string Description { get; set; }
        public int DepartmentID { get; set; }  
        public int RoleID { get; set; }  
        public int DesignationID { get; set; }
        [Display(Name = "Phone Number")]       
        public string Phonenumber { get; set; }
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string EmailAddress { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }   
        public int CityID { get; set; }   
        public int CountryID { get; set; }         
        public string ProfileImage { get; set; }
        public int CompanyID { get; set; }
        public int PType { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        [DataType(DataType.MultilineText)]
        public string Remark { get; set; }
        public bool IsActive { get; set; }
        public bool IsCompanyAdmin { get; set; }
        [Display(Name = "Date of Birth")]
        public string DOB { get; set; }
        [Display(Name = "Guardian Name")]
        public string GuardianName { get; set; }
        [Display(Name = "Guardian Contact")]
        public string GuardianContact { get; set; }
        [Display(Name = "Emergency Contact")]
        public string EmergencyContact { get; set; }
        public string Notes { get; set; }
        [Display(Name = "Personal Email")]
        [EmailAddress]
        public string PersonalEmail { get; set; }
        [Display(Name = "Skype ID")]
        public string Skype { get; set; }
        [Display(Name = "Personal Contact Number")]
        public string PersonalContactNumber { get; set; }
        public int StateID { get; set; }
        public int PostcodeId { get; set; }
        [Display(Name = "Skype Password")]
        public string SkypePassword { get; set; }
        public string DOJ { get; set; }
        public string InActiveDate { get; set; }
         [DisplayFormat(DataFormatString = "{0:0.#}", ApplyFormatInEditMode = true)]
        public decimal CasualLeave { get; set; }
         [DisplayFormat(DataFormatString = "{0:0.#}", ApplyFormatInEditMode = true)]
        public decimal SickLeave { get; set; }
         [DisplayFormat(DataFormatString = "{0:0.#}", ApplyFormatInEditMode = true)]
        public decimal SpecialLeave { get; set; }
        public bool Status { get; set; }
        public string StatusName { get; set; }
        /// <summary>
        /// Logical field
        /// it is used to count the number of row during paging
        /// </summary>
        public int RowNumber { get; set; }

        /// <summary>
        /// Logical field
        /// it fetach city name based on countryId and cityId
        /// </summary>
        [Display(Name = "City Name")]
        public string CityName { get; set; }

        /// <summary>
        /// Logical field
        /// it use get the department name based on departmentId
        /// </summary>
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }

        /// <summary>
        ///  Logical field
        ///  it use get the role name based on roleId
        /// </summary>
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        [Display(Name = "Remember on this computer")]
        public bool Remember { get; set; }

        /// <summary>
        ///  Logical field
        ///  it use get the Designation name based on DesignationId
        /// </summary>
        [Display(Name = "Designation Name")]
        public string DesignationName { get; set; }

        /// <summary>
        /// Logical field
        /// it fetach country name based on countryId
        /// </summary>
        [Display(Name = "Country Name")]
        public string CountryName { get; set; }

        /// <summary>
        /// Logical field
        /// it use in taking new password from user
        /// </summary>
        [DataType(DataType.Password)]        
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        /// <summary>
        /// Logical field
        /// it use to take the confirm password based on new password, both new password should match confirm password
        /// while create/updating the user password
        /// </summary>
        [DataType(DataType.Password)]        
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and re-type new password do not match.")]
        public string ConfirmPassword { get; set; }

        /// <summary>
        ///  Logical field
        ///  it use to get the user fullname based on Firstname and Lastname
        /// </summary>
        [Display(Name = "FullName")]
        public string FullName { get; set; }

        /// <summary>
        /// Logical field
        /// it fetch Isactive in string format "Active"/"Deactive"
        /// </summary>
        public string UserStatus { get; set; }

        /// <summary>
        /// Logical field
        /// it fetch state name based on countryId
        /// </summary>
        /// 
        [Display(Name = "State Name")]
        public string StateName { get; set; }

        /// <summary>
        /// Logical field
        /// it fetch Postcode based on countryId
        /// </summary>     
        [Display(Name = "Postcode")]
        public string Postcode { get; set; }

        /// <summary>
        /// Logical field
        /// it is to used to check the user is normal user or projectmanager as user
        /// </summary>
        public Boolean IsProjectManager { get; set; }         

        public List<MapMenuUser> MenuList { get; set; }

        /// <summary>
        /// Logical fields 
        /// here, in Projects section, Users List will be populated
        ///  /// </summary>
        public string ProjectManagerName { get; set; }
        public int ProjectManagerID { get; set; }


        /// <summary>
        /// <Logical fields : These fields are used in Project list edit section>
        /// </summary>
        public bool IsTeamLead { get; set; }
        public bool IsTeamMember { get; set; }
        
        /// <summary>
        /// Logical field
        /// it used for bind the default image when ever it found blank from database end
        /// </summary>
        public string NoImagePath
        {
            get
            {
                string NoprofileImagePath = "/Images/blank-profile.png";
                return NoprofileImagePath;
            }
        }
        
        /// <summary>
        /// <Logical field: need to use in job edit part to populate the checklist of users>
        /// </summary>
        public long JobID { get; set; }

    }
}
