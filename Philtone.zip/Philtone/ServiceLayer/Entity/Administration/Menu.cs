﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Administration
{
    public class Menu
    {
        public int MenuID { get; set; }

       // [Required(ErrorMessage = "Menu name is required.")]
        [Display(Name="Page Name")]
        public string MenuName { get; set; }

        public int ModuleID { get; set; }
       // [Required(ErrorMessage = "Module name is required.")]
        [Display(Name = "Module Name")]
        public string ModuleName { get; set; }

       // [Required(ErrorMessage = "Page url is required.")]
        [Display(Name = "Page URL")]
        public string MenuUrl { get; set; }

        [Display(Name = "Parent Menu")]
        public int ParentMenuCount { get; set; }

        public string MenuIcon { get; set; }
        public int DisplayOrder { get; set; }
        public int ParentMenuID { get; set; }

       //  [Required(ErrorMessage = "Parent menu name is required.")]
        [Display(Name="Menu Name")]
        public string ParentMenu { get; set; }
        public bool CanView { get; set; }
        public string Module { get; set; }
        public bool IsModule { get; set; }
        public bool IsParent { get; set; }
        public bool IsPage { get; set; }
        public bool IsActive { get; set; }
        public int RowNumber { get; set; }
        //Pagination and column sorting related fields
        public int startRowIndex { get; set; }
        public int maximumRows { get; set; }
        public string SortBy { get; set; }
        public bool SortAscending { get; set; }      
    }
}
