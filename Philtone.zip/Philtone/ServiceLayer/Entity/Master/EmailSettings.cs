﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Master
{
    public class EmailSettings
    {
        public int ID { get; set; }
        public string ProviderName { get; set; }
        public string FromEmail { get; set; }
        public string FromDisplayName { get; set; }
        public string SmtpHost { get; set; }
        public int SmptPort { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public string CredentialUserName { get; set; }
        public string CredentialPassword { get; set; }
        public bool EnableSsl { get; set; }
        public bool IsActive { get; set; }
        public string IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }        
    }
}
