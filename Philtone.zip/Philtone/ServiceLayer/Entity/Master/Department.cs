﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ServiceLayer.Entity.Master
{
   public class Department
    {
        public Int32 DepartmentID { get; set; }
        
        [Required(ErrorMessage = "Department name is required.")]
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }

      
        [Display(Name = "Department Description")]
        public string DepartmentDescription { get; set; }

        [Display(Name = "Status")]
        public string DepartmentStatus { get; set; }

        public Int32 CreatedBy { get; set; }
        public Int32 ModifiedBy { get; set; }
        public int RowNumber { get; set; }
        //Pagination and column sorting related fields
        public int startRowIndex { get; set; }
        public int maximumRows { get; set; }
        public string SortBy { get; set; }
        public bool SortAscending { get; set; }
    }
}
