﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Master
{
  public class FileUploadSettings
  {
    public int ID { get; set; }
    public string Path { get; set; }
    public string FolderName { get; set; }
    public string Domain { get; set; }
    public int Port { get; set; }
    public int Type { get; set; }
    public string Username { get; set; }
    //[DataType(DataType.Password)]
    public string Password { get; set; }
    public bool SSLEnable { get; set; }
    public bool IsActive { get; set; }
    public int CreatedBy { get; set; }
    public int ModifiedBy { get; set; }

  }
}
