﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Master
{
    public enum MenuType
    {
        Module,
        Menu,
        Page
    }
    public class Menu
    {
        public int MenuID { get; set; }
        public string MenuName { get; set; }
        public bool IsThirdParty { get; set; }
        public string MenuUrl { get; set; }
        public string MenuIcon { get; set; }
        public int ParentMenuID { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }

        public bool IsModule { get; set; }
        public bool IsParent { get; set; }
        /// <summary>
        /// Action Parameter which contains the type of menu send for action insert/update
        /// </summary>
        public MenuType MenuType { get; set; }
        /// <summary>
        /// Action Parameter if its in edit mode then it will be populated with the MenuID 
        /// </summary>
        public int EditID { get; set; }
        /// <summary>
        /// Action Parameter if its in edit mode then it will be populated with the ParentMenu Name, it is applicable if
        /// menu fetched is page or menu
        /// </summary>
        public string ParentMenuName { get; set; }
        /// <summary>
        /// Action Parameter if its in edit mode then it will be populated with the ParentMenu Name, it is applicable if
        /// menu fetched is page
        /// </summary>
        public string ModuleName { get; set; }
        /// <summary>
        /// Action Parameter if its in edit mode then it will be populated with the ParentMenu Name, it is applicable if
        /// menu fetched is page
        /// </summary>
        public int ModuleID { get; set; }
    }
}
