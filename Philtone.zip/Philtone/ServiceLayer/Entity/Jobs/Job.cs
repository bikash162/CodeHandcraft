﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Entity.Jobs
{
  public class Job : Pagination
  {
    public long JobID { get; set; }
    public string JobCode { get; set; }
    public string JobTitle { get; set; }
    public string JobDescription { get; set; }
    public long CustomerID { get; set; }
    public int Status { get; set; }

    public int CreatedBy { get; set; }
    public DateTime? CreatedOn { get; set; }

    public int ModifiedBy { get; set; }
    public DateTime? ModifiedOn { get; set; }


    ///<Logical fields :: for display purpose>
    public string CustomerName { get; set; }
    public string StatusName { get; set; }
    
    ///<Logical fields: For insert new job information>
    public string UserIDs { get; set; }
    public string CustomerContactIDs { get; set; }
    
    /// <summary>
    /// <Logical field: need to use in the list of Job>
    /// </summary>
    public string CreatedDateFormatted { get; set; }
    /// <summary>
    /// <user full name will be populated at the time job list>
    /// </summary>
    public string FullName { get; set; }

  }
}
