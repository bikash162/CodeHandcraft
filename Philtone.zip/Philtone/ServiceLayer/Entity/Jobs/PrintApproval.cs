﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Jobs
{
  public class PrintApproval
  {
    public long ID { get; set; }
    public long JobID { get; set; }
    public long CustomerContactID { get; set; }
    public int UserID { get; set; }
    public int Type { get; set; }
    public string FilePath { get; set; }
    public bool IsApproved { get; set; }
    public int Revision { get; set; }
  }
}
