﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity
{
  public interface Sorting
  {
    int startRowIndex { get; set; }
    int maximumRows { get; set; }
    string SortBy { get; set; }
    bool SortAscending { get; set; }
    int RowNumber { get; set; }

  }
}
