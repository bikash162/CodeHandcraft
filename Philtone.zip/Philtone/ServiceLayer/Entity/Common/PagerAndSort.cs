﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Entity.Common
{
    public class PagerAndSort
    {
        public PagerAndSort(int totalItems, int? page, int pageSize, string actionname, string sortby, bool sortascending, string tablename, string formname, string controllername)
        {
            pageSize = pageSize == 0 ? 20 : pageSize;
            // calculate total, start and end pages

            var totalPages = (int)Math.Ceiling((decimal)totalItems / (decimal)pageSize);
            var currentPage = page != null ? (int)page : 1;
            var startPage = currentPage - 3;
            var endPage = currentPage + 2;
            if (startPage <= 0)
            {
                endPage -= (startPage - 1);
                startPage = 1;
            }
            if (endPage > totalPages)
            {
                endPage = totalPages;
                if (endPage > 5)
                {
                    startPage = endPage - 4;
                }
            }

            TotalItems = totalItems;
            CurrentPage = currentPage;
            PageSize = pageSize;
            TotalPages = totalPages;
            StartPage = startPage;
            EndPage = endPage;
            ActionName = actionname;
            SortBy = sortby;
            SortAscending = sortascending;
            TableName = tablename;
            FormName = formname;
            ControllerName = controllername;
        }

        public int TotalItems { get; private set; }
        public int CurrentPage { get; private set; }
        public int PageSize { get; private set; }
        public int TotalPages { get; private set; }
        public int StartPage { get; private set; }
        public int EndPage { get; private set; }
        public string ActionName { get; private set; }
        public string SortBy { get; set; }
        public bool SortAscending { get; set; }
        public string TableName { get; set; }
        public string FormName { get; set; }
        public string ControllerName { get; set; }

    }
}
