﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Entity.Customers
{
  public class Customer : Pagination
  {
    public Int64 CustomerID { get; set; }

    [Display(Name = "Customer Name")]
    public string CustomerName { get; set; }

    [Display(Name = "Email Address")]
    public string CustomerEmail { get; set; }


    [Display(Name = "Status")]
    public string CustomerStatus { get; set; }
    public bool IsActive { get; set; }

    public string PhoneNo { get; set; }
    public string MobileNo { get; set; }
    public string Address { get; set; }
    public int CountryId { get; set; }
    public string CountryName { get; set; }

    public int CityId { get; set; }
    public string CityName { get; set; }

    public string PostCode { get; set; }
    public string UserID { get; set; }
    public string UserPassword { get; set; }
    public string UserConfirmPassword { get; set; }

    public string DefaultContactName { get; set; }
    public string DefaultContactEmail { get; set; }
    public string DefaultContactPhoneNo { get; set; }
    public string DefaultContactDesignation { get; set; }


    [Display(Name = "Remarks")]
    public string Remarks { get; set; }


    public int CreatedBy { get; set; }
    public int ModifiedBy { get; set; }


  }
}
