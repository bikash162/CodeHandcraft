﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Utitlity;

namespace ServiceLayer.Entity.Customers
{
  public class CustomerContacts : Pagination
  {
    public long CustomerContactID { get; set; }
    public string CustomerContactName { get; set; }
    public string CustomerContactEmail { get; set; }
    public string CustomerContactPhoneNumber { get; set; }
    public string CustomerContactDesignation { get; set; }
    public string CustomerContactRemark { get; set; }
    public string CustomerContactStatus { get; set; }
    public int CreatedBy { get; set; }
    public int ModifiedBy { get; set; }
    public bool IsActive { get; set; }
    public string UserName { get; set; }
    public string UserPassword { get; set; }
    public bool IsPrimary { get; set; }
    /// <summary>
    /// <Logical fields>
    /// </summary>
    public long CustomerID { get; set; }

    /// <summary>
    /// <Logical field: need to use in job edit part to populate the checklist of Contacts>
    /// </summary>
    public long JobID { get; set; }



  }
}
