﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Customers;
using ServiceLayer.Entity.Jobs;
using ServiceLayer.Entity.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.ViewModel.Jobs
{
  public class JobViewModel
  {
    public List<Job> oJobsList { get; set; }
    public Job job { get; set; }
    public PagerAndSort pagerAndSort { get; set; }

    public List<Customer> CustomersList { get; set; }
    public List<CustomerContacts> CustomerContactsList { get; set; }
    public List<User> UsersList { get; set; }
  }
}
