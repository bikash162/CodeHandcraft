﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Administration;
using ServiceLayer.Entity.Master;

namespace ServiceLayer.ViewModel.Administration
{
    public class RoleViewModel
    {
        public List<Role> roleList { get; set; }
        public Role role { get; set; }
        public PagerAndSort pagerAndSort { get; set; }
        public List<Role> GetRoleList { get; set; }

        public List<Department> DepartmentList { get; set; }
    }
}
