﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;

namespace ServiceLayer.ViewModel.Administration
{
    public class MapMenuUserViewModel
    {
        public List<MapMenuUser> ModuleMenus { get; set; }
        public List<MapMenuUser> ParentMenus { get; set; }
        public MapMenuUser mapMenuUser { get; set; }
        public List<MapMenuUser> SelectListUser { get; set; }
        public List<UserGroup> SelectListUserGroup { get; set; }
    }

    public class UserGroup
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
    }
}
