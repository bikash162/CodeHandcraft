﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;
using ServiceLayer.Entity.Master;
using ServiceLayer.Entity.Common;

namespace ServiceLayer.ViewModel.Administration
{
    public class UserViewModel
    {
        #region User
        /// <summary>
        /// its will listed all users in Grid with paging
        /// </summary>
        public List<User> UserList { get; set; }

        /// <summary>
        /// its use to get the details of user based on UserID at the time of edit
        /// </summary>
        public User user { get; set; }

        /// <summary>
        /// based on user listing the pager and sort will operate
        /// </summary>
        public PagerAndSort pagerAndSort { get; set; }

        /// <summary>
        /// it will populate the Department List use in User List search and in User Details and create new user
        /// </summary>
        public List<Department> DepartmentList { get; set; }

        /// <summary>
        /// it will populate the Role list and create new user
        /// </summary>
        public List<Role> RoleList { get; set; }

        /// <summary>
        /// it will populate the country list and use in User detail and new create new user
        /// </summary>
        public List<User> CountryList { get; set; }

        /// <summary>
        /// Logical field
        /// it used for bind the default image when ever it found blank from database end
        /// </summary>
        public string NoImagePath
        {
            get
            {
                string NoprofileImagePath = "/Images/blank-profile.png";
                return NoprofileImagePath;
            }

        }
        #endregion
    }
}
