﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;

namespace ServiceLayer.ViewModel.Administration
{
    public class PrivilegeViewModel
    {
        public MapMenuRoleViewModel MapMenuRoleViewModel { get; set; }
        public MapMenuUserViewModel MapMenuUserViewModel { get; set; }
    }
}
