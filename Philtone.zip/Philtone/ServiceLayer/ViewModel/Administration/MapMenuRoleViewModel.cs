﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Administration;


namespace ServiceLayer.ViewModel.Administration
{
    public class MapMenuRoleViewModel
    {
        public List<MapMenuRole> ModuleMenus { get; set; }
        public List<MapMenuRole> ParentMenus { get; set; }
        public MapMenuRole mapMenuRole { get; set; }
        public List<MapMenuRole> SelectListRole { get; set; }
        public List<RoleGroup> SelectListRoleGroup { get; set; }
    }

    public class RoleGroup
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
    }
}
