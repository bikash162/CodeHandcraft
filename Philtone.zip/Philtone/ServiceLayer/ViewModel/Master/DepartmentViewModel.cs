﻿using ServiceLayer.Entity.Master;
using ServiceLayer.Entity.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.ViewModel.Master
{
    public class DepartmentViewModel
    {
        public List<Department> DepartmentList { get; set; }
        public Department Department { get; set; }
        public PagerAndSort pagerAndSort { get; set; }
        public List<Department> GetDepartmentList { get; set; }    
    }
}
