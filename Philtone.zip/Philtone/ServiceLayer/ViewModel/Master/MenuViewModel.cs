﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.Entity.Master;

namespace ServiceLayer.ViewModel.Master
{
    
    public class MenuViewModel
    {
        public List<Menu> Modules { get; set; }
        public List<Menu> Menus { get; set; }
        public List<Menu> PageLevelMenus { get; set; }
        public Menu menu { get; set; }
    }
}
