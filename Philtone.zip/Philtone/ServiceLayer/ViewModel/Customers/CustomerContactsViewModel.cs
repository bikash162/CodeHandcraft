﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.ViewModel.Customers
{
  public class CustomerContactsViewModel
  {
    public List<CustomerContacts> oCustomerContactsList { get; set; }
    public CustomerContacts oCustomerContacts { get; set; }
    public PagerAndSort pagerAndSort { get; set; }
  }
}
