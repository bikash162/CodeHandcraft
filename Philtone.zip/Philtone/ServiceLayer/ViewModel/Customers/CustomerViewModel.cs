﻿using ServiceLayer.Entity.Common;
using ServiceLayer.Entity.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.ViewModel.Customers
{
  public class CustomerViewModel
  {
    public List<Customer> Customers { get; set; }
    public Customer Customer { get; set; }
    public PagerAndSort pagerAndSort { get; set; }

    /// <summary>
    /// <No Entity has been created for Country or City; so, added it into customer accordingly>
    /// </summary>
    public List<Customer> CountryList { get; set; }
    public List<Customer> CityList { get; set; }
    public CustomerContactsViewModel CustomerContactsViewModel { get; set; }   
  }
}
